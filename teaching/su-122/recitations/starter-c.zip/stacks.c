/* Stacks
 * 15-122 Principles of Imperative Computation, Fall 2010
 * Frank Pfenning
 */

#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#include "xalloc.h"
#include "contracts.h"
#include "stacks.h"

/* type elem must be defined */

typedef struct list* list;
struct list {
  elem data;
  list next;
};

bool is_segment(list start, list end)
{ list p = start;
  while (p != end) {
    if (p == NULL) return false;
    p = p->next;
  }
  return true;
}

bool is_circular(list l)
{ if (l == NULL) return false;
  { list t = l;       // tortoise
    list h = l->next; // hare
    while (t != h)
      //@loop_invariant is_segment(t, h);
      { if (h == NULL || h->next == NULL) return false;
	t = t->next;
	h = h->next->next;
      }
    return true;
  }
}

struct stack {
  list top;
};

bool is_stack (stack S) {
  return is_segment(S->top, NULL);
}

bool stack_empty(stack S)
//@requires is_stack(S);
{
  return S->top == NULL;
}

stack stack_new()
//@ensures is_stack(\result);
//@ensures stack_empty(\result);
{
  stack S = alloc(struct stack);
  S->top = NULL;
  return S;
}

void push(elem x, stack S)
//@requires is_stack(S);
//@ensures !stack_empty(S);
{
  list first = alloc(struct list);
  first->data = x;
  first->next = S->top;
  S->top = first;
}

elem pop(stack S)
//@requires is_stack(S);
//@requires !stack_empty(S);
//@ensures is_stack(S);
{ assert(S->top != NULL);
  { elem x = S->top->data;
    S->top = S->top->next;
    return x;
  }
}
