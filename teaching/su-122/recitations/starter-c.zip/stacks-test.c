/* Testing generic stacks
 * 15-122 Principles of Imperative Computation, Fall 2010
 * Frank Pfenning
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "xalloc.h"
#include "contracts.h"
#include "stacks.h"

int main () {
  stack S = stack_new();
  int* x = (int*)malloc(sizeof(int));
  *x = 1;/* x is heap-allocated */
  push(S,x);
  char* s = "24247";/* s is a constant string */
  push(S,s);/* mixed-type stack; DON'T DO THIS */
  assert((char*)pop(S) == s);/* EVER! */
  assert(*(int*)pop(S) == 1);
  printf("All tests passed!\n");
  free(x);/* free x */
  assert(stack_empty(S));
  return 0;
}
