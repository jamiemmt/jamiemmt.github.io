/* C0VM bytecode instructions
 * 15-122, Fall 2010
 * William Lovas
 */

#ifndef _BYTECODES_H
#define _BYTECODES_H

/* arithmetic operations */
#define IADD        0x60
#define IAND        0x7E
#define IDIV        0x6C
#define IMUL        0x68
#define IOR         0x80
#define IREM        0x70
#define ISHL        0x78
#define ISHR        0x7A
#define ISUB        0x64
#define IXOR        0x82

/* stack operations */
#define DUP         0x59
#define POP         0x57
#define SWAP        0x5F

/* memory allocation */
#define NEWARRAY    0xBC
#define ARRAYLENGTH 0xBE
#define NEW         0xBB

/* memory access */
#define AADDF       0x62
#define AADDS       0x63
#define MLOAD       0x2E
#define MSTORE      0x4F
#define CMLOAD      0x34
#define CMSTORE     0x55

/* local variables */
#define VLOAD       0x15
#define VSTORE      0x36

/* constants */
#define ACONST_NULL 0x01
#define BIPUSH      0x10
#define ILDC        0x13
#define ALDC        0x14

/* control flow */
#define NOP         0x00
#define IF_CMPEQ    0x9F
#define IF_CMPNE    0xA0
#define IF_ICMPLT   0xA1
#define IF_ICMPGE   0xA2
#define IF_ICMPGT   0xA3
#define IF_ICMPLE   0xA4
#define GOTO        0xA7

/* function calls and returns */
#define INVOKESTATIC    0xB8
#define INVOKENATIVE    0xB7
#define RETURN          0xB0

#endif /* _BYTECODES_H */
