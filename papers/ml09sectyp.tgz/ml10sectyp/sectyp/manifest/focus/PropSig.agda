open import lib.Prelude
open import sectyp.manifest.focus.TermSig
open import sectyp.manifest.focus.ApropSig
import sectyp.manifest.focus.Terms
module sectyp.manifest.focus.PropSig where

  record PropSig : Set1 where
    field
      ASig : ApropSig
    module T' = sectyp.manifest.focus.Terms (ApropSig.TSig ASig)
    field
      principal : T'.TermSigInt.BaseType
      _≥_ : ∀ {Ω} -> (T'.Term Ω (T'.▸_ principal)) -> (T'.Term Ω (T'.▸_ principal)) -> Set
      decide≥ : {Ω : T'.ICtx} (k1 k2 : T'.Term Ω (T'.▸_ principal)) -> Maybe (k1 ≥ k2) 
  

      