
open import lib.Prelude
open List.Subset
open import lib.SumsProds
open FailureMonad
open List using (_++_)

open import sectyp.manifest.focus.PropSig
import sectyp.manifest.focus.ProverInvert

module sectyp.manifest.focus.Prover (r : PropSig) where

  open sectyp.manifest.focus.ProverInvert r
  module ProofInt = ProofsInt
  open ProofInt
  open PropInt
  open PropInt.PropSigInt
  open PropInt.ApropInt
  open PropInt.ApropInt.ApropSigInt
  open PropInt.ApropInt.TermsInt
  open PropInt.ApropInt.TermsInt.TermSigInt

  module MakeProver (extraStrings : List String) where
    mutual
      proveRight : Nat -> (θ : Ctx) -> (A : Propo Pos (ictx θ)) -> Maybe (θ ⊢R A)
      proveRight Z _ _ = None
      proveRight (S n) θ (k0 says A) = proveNeutral n (sayCtx θ k0) A >>= λ y → Some (saysR y)
      proveRight (S n) θ (∃i_{.(ictx θ)}{τ} A) = or tryterms where
        terms = allTermsGen extraStrings (ictx θ) (▸ τ)
        tryterms = List.map (λ t → map (∃R t) (proveRight n θ (substlast A t))) terms
      proveRight (S n) θ (⇣ A) = map (λ x → blurR x) (proveNeutral n θ A)
      proveRight (S n) θ (A ∨ B) = (map ∨R1 (proveRight n θ A)) || (map ∨R2 (proveRight n θ B))
      proveRight (S n) θ (A ∧ B) = proveRight n θ A >>= λ x → map (λ y → ∧R x y) (proveRight n θ B)
      proveRight (S n) θ ⊤ = Some ⊤R
      proveRight (S n) θ (a+ a) with List.In.find-in (Sums.forgetMaybe  (propEq  (a+ a)))  (Ctx-rΓ+ θ)
      proveRight (S n) θ (a+ a) | Some y with  (Sums.extract-forgotten (propEq (a+ a)) (fst  y) (snd (snd y)))
      proveRight (S n) θ (a+ a) | Some (.(a+ a) , index , _ ) | Refl = Some (init+ index)
      proveRight (S n) θ (a+ a) | None = None
      proveRight (S n) θ ⊥ = None
  
      proveLeft : Nat -> (θ : Ctx) -> (A : Propo Neg (ictx θ)) -> (B : Propo Neg (ictx θ)) -> Maybe (θ ⊢L A > B)
      proveLeft Z _ _ _ = None
      -- SUSP: Dan says: switched the order of these; seems a little better for clauses that end in negative
      -- atoms, because it makes the bad instantiations of the quantifiers fail faster
      proveLeft (S n) θ (A ⊃ B) C = (proveLeft n θ B C) >>= λ y → map (λ z → ⊃L z y) (proveRight n θ A)
      proveLeft (S n) θ (a- A) (a- A') with atomEq A A'
      proveLeft (S n) θ (a- A) (a- .A) | Some Refl = Some (init-)
      ... | None = None
      proveLeft (S n) θ (a- _) _ = None
      proveLeft (S n) θ (∀i_ {.(ictx θ)}{τ} A) B  = or tryterms where
        terms = allTermsGen extraStrings (ictx θ) (▸ τ)
        tryterms : List (Maybe (θ ⊢L ∀i A > B))
        tryterms =  List.map (\ t -> FailureMonad.map (∀L t) (proveLeft n θ (substlast A t) B)) terms 
      proveLeft (S n) θ (↑ A) B = proveNeutral n (addTrue θ A) B >>= λ x → Some (blurL x)
  
      proveByLfoc : Nat -> (θ : Ctx) -> ( a : Propo Neg (ictx θ)) -> (⇣ a) ∈ Ctx-rΓ+ θ -> (b : Propo Neg (ictx θ)) -> Maybe (θ ⊢ b)
      proveByLfoc n θ a index b = proveLeft n θ a b >>= λ y → Some (lfoc index y)
  
      proveByClaim : Nat -> (θ : Ctx) -> (a : Claim (ictx θ)) -> (a ∈ Ctx-rΔ θ) -> (b : Propo Neg (ictx θ)) -> Maybe (θ ⊢ b)
      proveByClaim n θ (k claims a) index b = (proveLeft n θ a b) >>= (\ y -> map (\ z -> claimsL index y z) (decide≥ k (Ctx-rk θ)))
  
      proveByClaims : Nat -> (θ : Ctx ) -> (b : Propo Neg (ictx θ)) -> Maybe (θ ⊢ b)
      proveByClaims n θ b = x where 
        ClaimsIndices = List.In.indices (Ctx-rΔ θ) 
        find = List.map (λ t → proveByClaim n θ (fst t) (snd t) b) ClaimsIndices
        x = or find
  
      proveByLfocs : Nat -> (θ : Ctx) (b : Propo Neg (ictx θ)) -> Maybe (θ ⊢ b)
      proveByLfocs n θ b = or comps where
        indices = List.In.indices (Ctx-rΓ+ θ)
        comps : List (Maybe (θ ⊢ b))
        comps = List.map f indices where
          f : (Σ \ A -> A ∈ (Ctx-rΓ+ θ)) -> Maybe (θ ⊢ b)
          f (⇣ A , i) = proveByLfoc n θ A i b  
          f (_ , i) = None -- a little inefficient, but whatever
  
      proveByLs : Nat -> (θ : Ctx) (b : Propo Neg (ictx θ)) -> Maybe (θ ⊢ b)
      proveByLs n θ b = proveByLfocs n θ b || proveByClaims n θ b 
  
      -- invariant : θ and C are fully inverted
      proveStable : Nat -> (θ : Ctx) (C : Propo- (ictx θ)) -> Maybe (θ ⊢ C)
      proveStable Z _ _ = None
      {-choice of l/r focus-}
      proveStable (S n) θ (↑ A) = (map rfoc (proveRight n θ A)) || proveByLs n θ (↑ A)
      {- left focus on something-}
      proveStable (S n) θ (a- a) = proveByLs n θ (a- a)
      proveStable (S n) θ _ = None -- could ensure we never call proveStable on these cases
  
      -- invariant : θ can contain invertible positives, but A should be stable
      proveInversions : Nat -> (θ : Ctx) (A : Propo Neg (ictx θ)) 
                      -> Maybe (Everywhere (\ E -> ectxToCtx E ⊢ (weakenToECtx A E)) (invertCtx θ) )
      proveInversions n θ A =  List.EW.joinEW maybes where
        maybes : Everywhere (\ E -> Maybe (ectxToCtx E ⊢ (weakenToECtx A E))) (invertCtx θ)
        maybes = List.EW.fromall (\ {E} iE -> proveStable n (ectxToCtx E) (weakenToECtx A E)) 
  
      proveNeutral : Nat -> (θ : Ctx) -> (A : Propo Neg (ictx θ)) -> Maybe (θ ⊢ A)
      proveNeutral Z _ _ = None
      proveNeutral (S n) θ (A ⊃ B) = proveNeutral n (addTrue θ A) B >>= (\ y -> Some (⊃R y))
      proveNeutral (S n) θ (∀i_ {.(ictx θ)}{τ} A) = proveNeutral n (addVar θ τ) A >>= (\ y -> Some (∀R y))
      proveNeutral (S n) θ (a- a) = proveInversions n θ (a- a) >>= \ invs -> 
                               Some (Id.subst (\ Γ -> join _ Γ (Ctx-rΔ θ) (Ctx-rk θ) ⊢ (a- a))
                                         (List.append-rh-[] (Ctx-rΓ+ θ))
                                         (invert-sound (Ctx-rΓ+ θ) [] (Ctx-rΔ θ) 
                                          (\ {Ω'} {Γ'} {Δ'} {k'} i ->  List.EW.there invs {(Ω' , Γ' , Δ' , k')} i)))  
      proveNeutral (S n) θ (↑ A) =  proveInversions n θ (↑ A) >>= \ invs -> 
                               Some (Id.subst (\ Γ -> join _ Γ (Ctx-rΔ θ) (Ctx-rk θ) ⊢ (↑ A))
                                         (List.append-rh-[] (Ctx-rΓ+ θ))
                                         (invert-sound (Ctx-rΓ+ θ) [] (Ctx-rΔ θ) 
                                          (\ {Ω'} {Γ'} {Δ'} {k'} i ->  List.EW.there invs {(Ω' , Γ' , Δ' , k')} i)))      
  
      prove : Nat -> {θ : Ctx} -> {A : Propo Neg (ictx θ)} -> Maybe (θ ⊢ A)
      prove n = proveNeutral n _ _

  -- statically we don't have any extrastrings
  open MakeProver [] public
    
-- FIXME: check where we decrement n and where we don't to make it make sense

