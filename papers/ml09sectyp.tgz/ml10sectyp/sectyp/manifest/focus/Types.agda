open import lib.Prelude

module sectyp.manifest.focus.Types (BaseType : Set) where

 data Type : Set where
   ▸_ : BaseType -> Type
   _⊗_  : Type -> Type -> Type
   unit : Type
 infixr 0 _⊗_ 
