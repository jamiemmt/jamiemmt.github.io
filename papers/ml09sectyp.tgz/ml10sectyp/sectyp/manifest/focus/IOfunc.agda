open import lib.Prelude

open import sectyp.manifest.focus.PropSig
import sectyp.manifest.focus.Prover
open List using (_++_)
open List.Subset
open List.In
import sectyp.manifest.focus.IOsig

module sectyp.manifest.focus.IOfunc (r : PropSig) (r2 : sectyp.manifest.focus.IOsig.IOsig r) where
  
  open sectyp.manifest.focus.Prover r
  open ProofInt
  open PropInt
  open PropInt.PropSigInt
  open PropInt.ApropInt
  open PropInt.ApropInt.ApropSigInt
  open PropInt.ApropInt.TermsInt
  open PropInt.ApropInt.TermsInt.TermSigInt
  open sectyp.manifest.focus.IOsig r 
  open IOsig r2

  abstract
    

    ◯ : TCtx+ [] -> (A : Set) -> (A -> TCtx+ []) -> Set
    ◯ Γ A Γ' = IO.IORef (List String) -> IO.IO A
      -- in addition to an IO monad computation, we thread through
      -- an IORef that stores the list of dynamically generated
      -- strings that need to be used to generate constants
    
    return : ∀ { Γ A} -> A -> ◯  Γ A (\ _ -> Γ)
    return {Γ} {A} x _ = IO.return x
    
    _>>=_   : ∀ {  A B Γ Γ' Γ''} -> (◯  Γ A Γ') ->
            (( x : A ) -> ◯  (Γ' x) B Γ'') -> ◯  Γ B Γ''
    _>>=_  {A} {B} {Γ} {Γ'} {Γ''} x y r = IO._>>=_  (x r) (\ x -> y x r)
    
    
    weakenPre : ∀ {A Γ Γ' Γn } -> ◯  Γ A Γ'  -> Γ ⊆ Γn -> (Good Γn -> Good Γ) -> ◯  Γn A Γ'
    weakenPre {A} {Γ} {Γ'} {Γn} x y _ r = (x r) 
    
    weakenPost : ∀ {A Γ Γ' Γn} -> ◯ Γ A Γ' -> ((x : A)  -> (Γn x ⊆ Γ' x)) ->  ((x : A) -> (Good (Γ' x) -> Good (Γn x))) -> ◯ Γ A Γn 
    weakenPost {A} {Γ} {Γ'} {Γn} x _  _ r  =  (x r) 
    
    getLine : ∀ {Γ} -> ◯ Γ String (\ _ -> Γ)
    getLine {s} _ = IO.getLine 
    
    print  : ∀ {Γ}  -> String -> ◯ Γ Unit (\ _ -> Γ)
    print {Γ} s _ = IO._>>=_ ( IO.putStr s) (\ _ -> IO.return <>)
    
    printLn  : ∀ {Γ} -> String -> ◯ Γ Unit (\ _ -> Γ)
    printLn {Γ} s _ = IO._>>=_ (IO.putStrLn  s) (\ _ -> IO.return <>)
    
    error  : {A : Set} {Γ : TCtx+ []} { Γ' : _ } -> String -> ◯ Γ A Γ'
    error {A} {Γ} {Γ'} s _ = IO.error s
    
    acquire : ∀ {A Γ Γ'} -> (Γn : TCtx+ []) -> (Good Γ -> Good (Γn ++ Γ)) ->
              ◯ (Γn ++ Γ) A Γ' ->  ◯ Γ A Γ'   -> ◯ Γ A Γ'
  {- fixme -}
    acquire {A} {Γ} {Γ'} x _ y z r =  (y r) 

    _^_ : String -> String -> String
    _^_ = String.string-append
 

    doCommand : ∀ {Γ} -> (c : Command) -> (commands c) -> (a : Command.Args c Γ )  -> 
                ∀ {Γ'} -> (Command.Postcondition c a Γ') -> ◯ Γ (Command.Result c a) Γ'
    doCommand {Γ} c _ a {Γ'} post = (λ ref →
                                IO._>>=_ (Command.body c a)
                                (λ result →
                                  IO._>>=_ (IO.readIORef ref)
                                  (λ curS →
                                    IO._>>=_ (IO.writeIORef ref (curS ++ (Command.toReg c a result)))
                                    (λ _ → IO.return result))))


    doBracketCmd : ∀ {Γ A Δ} -> (b : BracketCommand) -> (t : bracketcommands b)
                 -> (a : BracketCommand.Args b Γ) -> ∀ {Γ' Δ'} -> (BracketCommand.relPre b a Δ)
                 -> (BracketCommand.relPost b a Δ' Γ') -> ◯ Δ A Δ' -> ◯ Γ (BracketCommand.Result b a A) Γ'
    doBracketCmd b _ a _ _ c  str = IO._>>=_ (BracketCommand.before b a) (λ _ → IO._>>=_ (c str) (BracketCommand.after b a))

    
    prove/dyn : ∀ {Γ1} -> Nat -> (Θ : Ctx) (A : Propo- (Ctx-rΩ Θ)) -> ◯ Γ1 (Maybe (Θ ⊢ A)) (\ _ -> Γ1)
    prove/dyn n Θ A r = IO._>>=_ (IO.readIORef r) \ xtras -> IO.return (MakeProver.prove xtras n {Θ} {A}) 
 
    fix : {A : Set} {Γ' : _} -> (({Γ : TCtx+ []} ->  ◯ Γ A Γ' ) -> ({Γ : TCtx+ []} ->  ◯ Γ A Γ')) -> ({Γ : TCtx+ []} ->  ◯ Γ A Γ')
    fix {_}{_} f {Γ} r = IO.fix2 (λ rec → λ Γ' r' → f (λ {Γ0} → λ ref → rec Γ0 ref) {Γ'} r' ) Γ r

  acquire_/_no⇒_yes⇒_ : ∀ {Γ A Γ'} -> (Γn : TCtx+ [] ) -> (Good Γ -> Good (Γn ++ Γ))->  ◯ Γ A Γ' -> ◯  (List._++_ Γn Γ) A Γ' -> ◯  Γ A Γ'
  acquire Γn / pf no⇒ e1 yes⇒ e2 = acquire Γn pf e2 e1
  infixr 10 acquire_/_no⇒_yes⇒_

  acquire_/_yes⇒_ : ∀ {Γ A Γ'} -> (Γn : TCtx+ [] ) -> (Good Γ -> Good (Γn ++ Γ)) -> ◯ (List._++_ Γn Γ) A Γ' -> ◯ Γ A Γ'
  acquire Γ / g yes⇒ e2 = acquire Γ g e2 (error "acquire failed")

  _>>_   : ∀ {A B Γ Γ' Γ'' } -> ◯ Γ A Γ' ->  ({x : A} -> ◯ (Γ' x) B Γ'') -> ◯ Γ B Γ'' 
  _>>_  x y =   x >>= (\ _ -> y)  
  
  prompt : ∀ {Γ } -> String -> ◯  Γ String (\ _ -> Γ) 
  prompt {Γ} s = (print  s)  >> getLine 

  wknPost : ∀ {A Γ Γ' Γn} -> ((x : A) -> (Γn x ⊆ Γ' x)) -> ((x : A) -> Good (Γ' x) -> Good (Γn x)) -> ◯ Γ A Γ'  -> ◯ Γ A Γn 
  wknPost x g y = weakenPost y x g

  wknPre : ∀ {A Γ Γ' Γn} -> Γ ⊆ Γn -> (Good Γn -> Good Γ) -> ◯ Γ A Γ' -> ◯ Γn A Γ'
  wknPre x g y = weakenPre y x g
