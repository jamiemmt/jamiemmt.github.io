{-# OPTIONS --no-termination-check #-}

open import lib.Prelude
open import sectyp.manifest.focus.TermSig
import sectyp.manifest.focus.Types
open List.Subset
open FailureMonad

module sectyp.manifest.focus.Terms (r : TermSig) where
 module FOTermSigInt = TermSig r
 open FOTermSigInt 
 module TermSigInt = FlatTermSig (TermSig.flat r)
 open TermSigInt
 ICtx = List BaseType

 open sectyp.manifest.focus.Types BaseType public

 data Term : ICtx -> Type -> Set where
   ▹_ : ∀ {Ω τ} -> τ ∈ Ω -> Term Ω (▸ τ)
   ▸_ : ∀ {Ω τ} -> Const τ -> Term Ω (▸ τ)
   _,_  : ∀ {Ω τ1 τ2} -> Term Ω τ1 -> Term Ω τ2 -> Term Ω (τ1 ⊗  τ2)
   [] : ∀ {Ω} -> Term Ω unit
   _·_ : ∀ {Ω τ A} -> Func τ A -> Term Ω A -> Term Ω (▸ τ)
 infixr 0 _,_
 infixr 18 ▸_
 infixr 18 ▹_

{- Ω ⊆ Ω' means   ∀ {τ} -> τ ∈ Ω -> τ ∈ Ω'  -}
 weakenTerm :{Ω Ω' : ICtx } {τ : _} -> Term Ω τ -> Ω ⊆ Ω' -> Term Ω' τ 
 weakenTerm (▹ x) t = ▹ (t x)
 weakenTerm (▸ c) t = ▸ c
 weakenTerm (t1 , t2) t = (weakenTerm t1 t , weakenTerm t2 t)
 weakenTerm (f · t1) t = f · (weakenTerm t1 t)
 weakenTerm [] _ = []

 substTerm : ∀ {Ω τ Ω'} -> Term Ω τ ->  (∀ {τ} -> τ ∈ Ω  ->  Term Ω' (▸ τ)) -> Term Ω' τ
 substTerm (▹ x) f =  (f x)
 substTerm (▸ c) f = ▸ c
 substTerm (t1 , t2) f = (substTerm t1 f , substTerm t2 f)
 substTerm (f · t1) t = f · (substTerm t1 t)
 substTerm [] _ = []

 identity : {Ω : ICtx} -> ( ∀ {τ} -> τ ∈ Ω -> Term Ω (▸ τ))
 identity  = λ x → ▹ x
  
 substTermLast : ∀ {Ω τ τ'} -> Term (τ :: Ω) τ' -> Term Ω (▸ τ) -> Term Ω τ'
 substTermLast {Ω}{τ}a k = substTerm a sub where
    sub : ∀ {τ'} -> τ' ∈ (τ :: Ω) -> Term Ω (▸ τ')
    sub i0 = k
    sub (iS x) = identity x

 varEq : {Ω : ICtx} {τ : BaseType} -> (x y :  τ ∈ Ω) -> Maybe (Id x y)
 varEq i0 i0 = Some Refl
 varEq (iS x) (iS y) = Sums.mapMaybe (Id.substeq iS) (varEq x y)
 varEq _ _ = None

 termEq : ∀ {Ω τ} -> (T1 T2 : Term Ω τ) -> Maybe (Id T1 T2)
 termEq (▹ x) (▹ y) = Sums.mapMaybe (\ x -> Id.substeq ▹_ x) (varEq x y)
 termEq (▸ c) (▸ c') = Sums.mapMaybe (\ x -> Id.substeq ▸_ x) (constEq c c')
 termEq [] [] = Some Refl
 termEq (x1 , x2) (y1 , y2) = FailureMonad._>>=_ (termEq x1 y1)
                              (\ e1 -> Sums.mapMaybe (λ e2 → Id.substeq2 _,_ e1 e2) (termEq x2 y2)) 
 termEq (c1 · x1) (c2 · x2) with funcEq c1 c2
 ... | None = None
 termEq (c1 · x1) (.c1 · x2)   | Some (Refl , Refl , HRefl) = Sums.mapMaybe (Id.substeq (\ x -> c1 · x)) (termEq x1 x2)
 termEq _ _ = None

 allVars : (Ω : ICtx) {τ : _} -> List (τ ∈ Ω)
 allVars [] = []
 allVars (τ' :: Ω) {τ} with τ' | typeEq τ τ'
 ... | .τ | Some Refl = i0 :: (List.map iS (allVars Ω))
 ... | _  | None = (List.map iS (allVars Ω))

 -- FIXME: insist that the signature be non-recursive
 allTermsGen : List String -> (Ω : _) (A : _) -> List (Term Ω A)
 allTermsGen dynStrings Ω (▸ τ) = List.append (List.map ▸_ (allConst dynStrings)) 
                                          (List.append (List.map ▹_  (allVars _))
                                                       (List.concat
                                                         (List.map (\ c -> List.map (\ t -> (snd c) · t) (allTermsGen dynStrings Ω (fst c))) 
                                                         (allFuncs τ))))
 allTermsGen _ _ unit = []
 allTermsGen dyn Ω (A ⊗ B) = List.concat (List.map (\ x1 -> (List.map (\ x2 -> (x1 , x2)) (allTermsGen dyn Ω B))) (allTermsGen dyn Ω A))

 -- properties of weakening and subst

 IsId : ∀ {Ω} -> (Ω ⊆ Ω) -> Set
 IsId {Ω} w = {τ : BaseType} (i : τ ∈ Ω) -> Id i (w i)

 _∘_ : ∀ {Ω1 Ω2 Ω3 : ICtx} -> (w2 : Ω2 ⊆ Ω3) -> (w1 : Ω1 ⊆ Ω2) -> Ω1 ⊆ Ω3
 g ∘ f = \ x -> g (f x)

 WEq : ∀ {Ω Ω'} -> (f1 f2 : Ω ⊆ Ω') -> Set
 WEq f1 f2 = {τ : BaseType} -> (x : τ ∈ _) -> Id (f1 x) (f2 x)
 
 weakenTerm∘ : ∀ {Ω1 Ω2 Ω3 τ} -> (w2 : Ω2 ⊆ Ω3) (w1 : Ω1 ⊆ Ω2) -> (A : Term Ω1 τ) -> Id (weakenTerm A (\{_} -> w2 ∘ w1)) (weakenTerm (weakenTerm A w1) w2)
 weakenTerm∘ _ _ (▸ c) = Refl
 weakenTerm∘ w1 w2 (▹ x)  = Refl
 weakenTerm∘ w1 w2 (t1 , t2) = Id.substeq2 _,_ (weakenTerm∘ w1 w2 t1) (weakenTerm∘ w1 w2 t2)
 weakenTerm∘ w1 w2 (f · t) = Id.substeq (\ x -> f · x) (weakenTerm∘ w1 w2 t)
 weakenTerm∘ w1 w2 [] = Refl

 weakenTerm-id : ∀ {Ω} -> {w : Ω ⊆ Ω} -> IsId w -> {τ : Type} (A : Term Ω τ) -> Id (weakenTerm A w) A
 weakenTerm-id isid (▹ x)  = Id.substeq ▹_ (Id.sym (isid x))
 weakenTerm-id isid (▸ p) = Refl
 weakenTerm-id isid (t1 , t2) = Id.substeq2 _,_ (weakenTerm-id isid t1) (weakenTerm-id isid t2)
 weakenTerm-id isid (f · t) = Id.substeq (\ x -> f · x) (weakenTerm-id isid t)
 weakenTerm-id isid [] = Refl

 weakenTerm-ext : ∀ {Ω Ω'} {w1 w2 : Ω ⊆ Ω'} -> WEq w1 w2 -> 
   {τ : Type} (t : Term Ω τ) -> Id (weakenTerm t w1) (weakenTerm t w2)
 weakenTerm-ext wid (▹ x)  = Id.substeq ▹_ (wid x) 
 weakenTerm-ext wid (▸  c ) = Refl
 weakenTerm-ext wid (t1 , t2) = Id.substeq2 _,_ (weakenTerm-ext wid t1) (weakenTerm-ext wid t2)
 weakenTerm-ext wid (f · t) = Id.substeq (\ x -> f · x) (weakenTerm-ext wid t)
 weakenTerm-ext wid [] = Refl

 WHEq : ∀ {Ω Ω1' Ω2'} -> (f1 : Ω ⊆ Ω1') (f2 : Ω ⊆ Ω2') -> Set
 WHEq f1 f2 = {τ : BaseType} -> (x : τ ∈ _) -> HId (f1 x) (f2 x)

 WeakenFn : (ICtx -> Set) -> Set
 WeakenFn F = ∀{Ω Ω'} -> F Ω -> Ω ⊆ Ω' -> F Ω' 

 Weaken-Hext : (F : ICtx -> Set) -> WeakenFn F -> Set
 Weaken-Hext F weaken = ∀ {Ω Ω1' Ω2'} {w1 : Ω ⊆ Ω1'} {w2 : Ω ⊆ Ω2'} 
                   -> Id Ω1' Ω2' 
                   -> WHEq w1 w2 -> (t : F Ω) -> HId (weaken t w1) (weaken t w2)

 weakenTerm-hext : {τ : Type} -> Weaken-Hext (\ Ω -> Term Ω τ) weakenTerm
 weakenTerm-hext Refl wid (▹ x) =  Id.Het.substeq/hom ▹_ (wid x) 
 weakenTerm-hext Refl wid (▸  c ) = HRefl
 weakenTerm-hext Refl wid [] = HRefl
 weakenTerm-hext Refl wid (f · t) = Id.Het.substeq/hom (\ x -> f · x) (weakenTerm-hext Refl wid t)
 weakenTerm-hext Refl wid (t1 , t2) = Id.Het.substeq/hom2 _,_ (weakenTerm-hext Refl wid t1) (weakenTerm-hext Refl wid t2)
{-
 weaken-assoc : ∀ {Ω τ} (Ω' : _) (t : Term Ω τ) 
              -> HId (weakenTerm t (List.In.skip (List.append Ω' (τ :: []))))
                     (weakenTerm t (\ x -> List.In.skip Ω' (iS{_}{τ} x)))
 weaken-assoc [] t = HRefl
 weaken-assoc (τ :: Γ) (▹ t) = {!!}
 weaken-assoc (τ :: Γ) _ = {!weaken-assoc Γ t!}
-}
 
