open import lib.Prelude

module sectyp.manifest.focus.Tracked where

  -- FIXME: figure out how to make this abstract and have clients be able to
  -- add operations at the same time; right now it's transparent and clients
  -- have to copy and rexport

  module TrackedFunc (Larg : Set) 
                     (⊔arg : Larg -> Larg -> Larg) 
                     where
      L : Set
      L = Larg

      _⊔_ : Larg -> Larg -> Larg
      _⊔_ = ⊔arg

      Tracked : Set -> L -> Set
      Tracked A _ = A
  
  
      fmap : ∀ {A B L} -> (A -> B) -> Tracked A L -> Tracked B L
      fmap f = f
  
      _⊙_ : ∀ {A B L1 L2} -> Tracked (A -> B) L1 -> Tracked A L2 -> Tracked B (L1 ⊔ L2)
      f ⊙ x = f x
  {-
      pure : ∀ {A L} -> MayPure L -> A -> Tracked A L
      pure _ x = x
  
      out : ∀ {A L} -> MayOut L -> Tracked A L -> A
      out _ x = x
  -}

  module TrackedList (A : Set) where

    open List.Subset

    open TrackedFunc (List A) List.append {- (\ _ -> Void) (\ x -> Id x []) -} public
    