
open import lib.Prelude
open List.Subset
open FailureMonad

import sectyp.manifest.focus.Propositions
open import sectyp.manifest.focus.PropSig

module sectyp.manifest.focus.Proofs (r : PropSig ) where

  module PropInt =  sectyp.manifest.focus.Propositions r 
  open PropInt
  open PropInt.PropSigInt
  open PropInt.ApropInt
  open PropInt.ApropInt.ApropSigInt
  open PropInt.ApropInt.TermsInt
  open PropInt.ApropInt.TermsInt.TermSigInt



  -- Ω ; Γ , Δ  |-^k  C  
  -- written (join Ω Γ Δ k) ⊢ C
  --         |____________|
  --               θ

  module Contexts where
    data Claim : ICtx -> Set where
      _claims_ : ∀ {Ω} -> Term Ω (▸ principal) -> Propo- Ω -> Claim Ω
    infixr 14 _claims_  -- looser than everyone

    -- Δ
    CCtx : ICtx -> Set  
    CCtx Ω = List (Claim Ω)
  
    -- Γ+
    TCtx+ :  ICtx -> Set
    TCtx+ Ω = List (Propo Pos Ω)

    record Ctx : Set where
      field
        rΩ : ICtx
        rΓ+ : TCtx+ rΩ
        rΔ : CCtx rΩ 
        rk : Term rΩ (▸ principal)
    {- fixme : workaround for scoping in prover-}
    Ctx-rΩ :  (k : Ctx) -> ICtx
    Ctx-rΩ = Ctx.rΩ
    Ctx-rΓ+ : (θ : Ctx ) -> TCtx+ (Ctx.rΩ θ)
    Ctx-rΓ+ = Ctx.rΓ+
    Ctx-rΔ : (θ : Ctx ) -> CCtx  (Ctx.rΩ θ)
    Ctx-rΔ = Ctx.rΔ
    Ctx-rk :  (θ : Ctx) -> Term (Ctx.rΩ θ) (▸ principal)
    Ctx-rk = Ctx.rk

    join : (Ω : ICtx) -> (Γ+ : TCtx+ Ω) -> (Δ : CCtx Ω) -> (k : Term Ω (▸ principal)) -> Ctx
    join Ω Γ+ Δ k = record { rΩ = Ω ; rΓ+ = Γ+ ; rΔ = Δ ; rk = k}
  
    ictx : Ctx -> ICtx
    ictx t = Ctx.rΩ t
    
    tctx : (Θ : Ctx) -> TCtx+ (Ctx.rΩ Θ)
    tctx Θ = Ctx.rΓ+ Θ

    cctx : (Θ : Ctx) -> CCtx (Ctx.rΩ Θ)
    cctx Θ = Ctx.rΔ Θ

    weakenClaim : ∀ {Ω Ω'} -> Claim Ω -> ( Ω ⊆ Ω') -> Claim Ω'
    weakenClaim (k claims A) w = (weakenTerm k w) claims (weakenP A w)

    weakenT+ : ∀ {Ω Ω'} -> TCtx+ Ω -> ( Ω ⊆ Ω') -> TCtx+ ( Ω')
    weakenT+ Γ w = List.map (\ A -> weakenP A w) Γ
   
    weakenC : ∀ {Ω Ω'} -> (Γ : CCtx Ω) -> (Ω ⊆ Ω') -> CCtx (Ω')
    weakenC Γ w = List.map (\ c -> weakenClaim c w) Γ

    substClaimLast : ∀ {Ω τ} -> Claim (τ :: Ω) -> Term Ω (▸ τ) -> Claim Ω
    substClaimLast (k claims A) t = (substTermLast k t) claims (substlast A t)

    substCLast : ∀ {Ω τ} -> CCtx (τ :: Ω) -> Term Ω (▸ τ) -> CCtx Ω
    substCLast Δ t = List.map (\ c -> substClaimLast c t) Δ
   
    -- θ ⊢ (k claims A)  iff  sayCtx θ k ⊢ A
    sayCtx : (θ : Ctx) -> (k : Term (Ctx.rΩ θ) (▸ principal)) -> Ctx
    sayCtx θ k = (record {rΩ = Ctx.rΩ θ ; rΓ+ = [] ; rΔ = Ctx.rΔ θ ; rk = k})
    
    addTrue : (θ : Ctx) -> (A : Propo Pos (ictx θ)) -> Ctx
    addTrue θ A = (record {rΩ = Ctx.rΩ θ ; rΓ+ = A :: (Ctx.rΓ+ θ) ; rΔ = Ctx.rΔ θ ; rk = Ctx.rk θ})
  
    addClaim : (θ : Ctx) -> (t : Claim (ictx θ)) -> Ctx
    addClaim θ c = record {rΩ = Ctx.rΩ θ ; rΓ+ =  Ctx.rΓ+ θ ; rΔ = c :: Ctx.rΔ θ ; rk = Ctx.rk θ}
  
    addVar : (θ : Ctx) -> (A : BaseType) -> Ctx
    addVar θ τ = record {rΩ  = (τ :: Ctx.rΩ θ) ;
                         rΓ+ = (weakenT+ (Ctx.rΓ+ θ) iS) ;
                         rΔ  = (weakenC (Ctx.rΔ θ) iS) ; 
                         rk  = (weakenTerm (Ctx.rk θ) iS)}

    unclaims : ∀ {Ω} -> Claim Ω -> Term Ω (▸ principal) × Propo- Ω
    unclaims (k claims A) = (k , A)
     
  open Contexts public

  -- θ ⊢L A- > C-  (left focus on A-)
  -- θ ⊢R A+       (right focus on A+)
  -- θ ⊢I A+ > C-  (one step of left inversion on A+)
  -- θ ⊢ C-        (neutral)

  mutual 
    data _⊢L_>_ : (θ : Ctx)-> Propo- (ictx θ) -> Propo- (ictx θ) -> Set where
      init- : ∀ {θ p} 
            -> θ ⊢L (a- p) > (a- p)
      ⊃L    : ∀ {θ A B C} 
            -> θ ⊢R A  ->  θ ⊢L B > C 
            -> θ ⊢L (A ⊃ B) > C
      ∀L    : ∀ {θ τ A B } 
            -> (t : Term (ictx θ) (▸ τ))  ->  θ ⊢L (substlast A t) > B 
            -> θ ⊢L ∀i_ {Ctx.rΩ θ}{τ} A > B
      blurL : ∀ {θ A B} 
            -> (addTrue θ A) ⊢ B  
            -> θ ⊢L ↑ A > B

    data _⊢I_>_ : (θ : Ctx) -> (Propo+ (ictx θ)) -> Propo- (ictx θ) -> Set where
      ∨L : ∀ {θ A B C}  
         -> (addTrue θ A) ⊢ C  ->  (addTrue θ B) ⊢ C 
         -> θ ⊢I (A ∨ B) > C          
      ∧L : ∀ {θ A B C} 
         -> (addTrue (addTrue θ B) A) ⊢ C 
         -> θ ⊢I (A ∧ B) > C         
      ∃L : ∀ {θ  τ A C} 
         -> (addTrue (addVar θ τ) A) ⊢ (weakenP C iS)
         -> θ ⊢I (∃e τ · A) > C        
      saysL : ∀ {θ k A C} 
            -> addClaim θ (k claims A) ⊢ C
            -> θ ⊢I (k says A) > C
      ⊥L : ∀ {θ C} 
         -> θ ⊢I ⊥ > C
      ⊤L : ∀ {θ C} 
         -> θ ⊢ C -> θ ⊢I ⊤ > C

    data _⊢R_ : (θ : Ctx) -> Propo+ (ictx θ) -> Set where
      init+ : ∀ {θ A} 
            -> (a+ A) ∈ Ctx.rΓ+ θ 
            -> θ ⊢R (a+ A)
      ⊤R : ∀ {θ} 
         -> θ ⊢R ⊤ 
      ∧R : ∀ {θ A B} 
         -> θ ⊢R A  ->  θ ⊢R B 
         -> θ ⊢R (A ∧ B)
      ∨R1 : ∀ {θ A B} 
          -> θ ⊢R A 
          -> θ ⊢R (A ∨ B)
      ∨R2 : ∀ {θ A B} 
          -> θ ⊢R B 
          -> θ ⊢R (A ∨ B)
      ∃R : ∀ {θ τ A}  
         -> (t : (Term (ictx θ) (▸ τ)))  ->  θ ⊢R  (substlast A t) 
         -> θ ⊢R (∃e τ · A)
      saysR : ∀ {θ k0 A} 
            -> (sayCtx θ k0) ⊢ A 
            -> θ ⊢R (k0 says A)
      blurR : ∀ {θ A} 
            -> θ ⊢ A 
            -> θ ⊢R ⇣ A

    data _⊢_ :  (θ : Ctx) -> Propo- (ictx θ) -> Set where
      ⊃R : ∀ {θ A B} 
         -> (addTrue θ A) ⊢ B 
         -> θ ⊢ (A ⊃ B)
      ∀R : ∀ {θ τ A} 
         -> (addVar θ τ) ⊢ A 
         -> θ ⊢ (∀e τ · A)
      rfoc : ∀ {θ A } 
           -> θ ⊢R A 
           -> θ ⊢ ↑ A
      lfoc : ∀ {θ A B} 
           -> ((⇣ A) ∈ Ctx.rΓ+ θ)  ->  θ ⊢L A > B 
           -> θ ⊢ B 
      claimsL : ∀ {θ k A B} 
              -> (k claims A) ∈ Ctx.rΔ θ 
              -> θ ⊢L A > B  ->   k ≥ (Ctx.rk θ)
              -> θ ⊢ B
      linv : ∀ {θ A B} 
           -> (A ∈ Ctx.rΓ+ θ)  ->  θ ⊢I A > B 
           -> θ ⊢ B 

  module Weaken where

   weaken-subsetΓ : ∀ {Ω τ} (Γ Γ' : TCtx+ Ω) -> Γ ⊆ Γ' -> (weakenT+ {Ω} {τ :: Ω} Γ iS) ⊆ (weakenT+ {Ω} {τ :: Ω} Γ' iS)
   weaken-subsetΓ Γ Γ' w i with List.In.in-map2 Γ (\A -> weakenP A iS) i 
   weaken-subsetΓ Γ Γ' w i    | (Aorig , iorig , Refl) = List.In.in-map (w iorig)

   weaken-subsetΔ : ∀ {Ω τ} (Δ Δ' : CCtx Ω) -> Δ ⊆ Δ' -> (weakenC {Ω} {τ :: Ω} Δ iS) ⊆ (weakenC {Ω} {τ :: Ω} Δ' iS)
   weaken-subsetΔ Δ Δ' w i with List.In.in-map2 Δ (\c -> weakenClaim c iS) i 
   weaken-subsetΔ Δ Δ' w i    | (Aorig , iorig , Refl) = List.In.in-map (w iorig)

   mutual
     weakenΓ+R : ∀ {Ω Γ+ Δ k Γ+' A} -> Γ+ ⊆ Γ+' -> (join Ω Γ+ Δ k) ⊢R A -> (join Ω Γ+' Δ k) ⊢R A
     weakenΓ+R l (init+ k) = init+ (l k)
     weakenΓ+R l ⊤R = ⊤R
     weakenΓ+R l (∧R p1 p2) = ∧R (weakenΓ+R l p1) (weakenΓ+R l p2)
     weakenΓ+R l (∨R1 p) = ∨R1 (weakenΓ+R l p)
     weakenΓ+R l (∨R2 p) = ∨R2 (weakenΓ+R l p)
     weakenΓ+R l (saysR p) = saysR p
     weakenΓ+R l (∃R t p) = ∃R t (weakenΓ+R l p)
     weakenΓ+R l (blurR p) = blurR (weakenΓ+N l p)
  
     weakenΓ+N : ∀ {Ω Γ+ Δ k Γ+' A} -> Γ+ ⊆ Γ+' -> (join Ω Γ+ Δ k) ⊢ A -> (join Ω  Γ+' Δ k) ⊢ A
     weakenΓ+N l (lfoc index lpr) = lfoc (l index) (weakenΓ+L l lpr)
     weakenΓ+N l (linv index lpr) = linv (l index) (weakenΓ+I l lpr)
     weakenΓ+N l (rfoc p) = rfoc (weakenΓ+R l p)
     weakenΓ+N l (⊃R p) = ⊃R (weakenΓ+N (⊆-::-cong l) p)
     weakenΓ+N {Γ+ = Γ+} {Γ+' = Γ+'} l (∀R p) = ∀R (weakenΓ+N (weaken-subsetΓ Γ+ Γ+' l) p)
     weakenΓ+N l (claimsL p ind lt) = claimsL p (weakenΓ+L l ind) lt

     weakenΓ+L : ∀ {Ω Γ+ Δ k Γ+' A B} -> Γ+ ⊆ Γ+' -> (join Ω  Γ+  Δ k) ⊢L A > B ->
              (join Ω  Γ+'  Δ k) ⊢L A > B
     weakenΓ+L l init- = init-
     weakenΓ+L l (⊃L p pk) = ⊃L (weakenΓ+R l p) (weakenΓ+L l pk)
     weakenΓ+L l (∀L t pk) = ∀L t (weakenΓ+L l pk)
     weakenΓ+L l (blurL t) =  blurL (weakenΓ+N (⊆-::-cong l) t)

     weakenΓ+I : ∀ {Ω Γ+ Δ k Γ+' A B} -> Γ+ ⊆ Γ+' -> (join Ω Γ+ Δ  k) ⊢I A > B -> (join Ω Γ+' Δ  k) ⊢I A > B
     weakenΓ+I l (∧L p)  = ∧L (weakenΓ+N (⊆-::-cong (⊆-::-cong l)) p)  
     weakenΓ+I l (∨L p1 p2) = ∨L (weakenΓ+N (⊆-::-cong l) p1) (weakenΓ+N (⊆-::-cong l) p2)
     weakenΓ+I {Γ+ = Γ+} {Γ+' = Γ+'} l (∃L p) = ∃L (weakenΓ+N (⊆-::-cong (weaken-subsetΓ _ _ l)) p)
     weakenΓ+I l (saysL p)  = saysL (weakenΓ+N l p)
     weakenΓ+I l (⊤L p) = (⊤L (weakenΓ+N l p) )
     weakenΓ+I l ⊥L  = ⊥L

     weakenΔL : ∀ {Ω Γ+ Δ k Δ' A B} -> Δ ⊆ Δ' -> (join Ω Γ+ Δ k) ⊢L A > B ->
                (join Ω Γ+ Δ' k) ⊢L A > B
     weakenΔL l init- = init-
     weakenΔL l (⊃L p pk) = ⊃L (weakenΔR l p) (weakenΔL l pk)
     weakenΔL l (∀L t p) = ∀L t (weakenΔL l p)
     weakenΔL l (blurL p) = blurL (weakenΔN l p)

     weakenΔR :  ∀ {Ω Γ+ Δ k Δ' B} -> Δ ⊆ Δ' -> (join Ω Γ+ Δ k) ⊢R B ->
                 (join Ω Γ+ Δ' k) ⊢R B
     weakenΔR l (init+ k) = init+ k
     weakenΔR l ⊤R = ⊤R

     weakenΔR l (∧R p1 p2) = ∧R (weakenΔR l p1) (weakenΔR l p2)
     weakenΔR l (∨R1 p) = ∨R1 (weakenΔR l p)
     weakenΔR l (∨R2 p) = ∨R2 (weakenΔR l p)
     weakenΔR l (saysR p) = saysR (weakenΔN l p)
     weakenΔR l (∃R t p) = ∃R t (weakenΔR l p)
     weakenΔR l (blurR p) = blurR (weakenΔN l p)

     weakenΔN :  ∀ {Ω Γ+ Δ k Δ' B} -> Δ ⊆ Δ' -> (join Ω Γ+ Δ k) ⊢ B ->
                 (join Ω Γ+ Δ' k) ⊢ B
     weakenΔN l (lfoc index lpr) = lfoc index (weakenΔL l lpr)
     weakenΔN l (linv index lpr) = linv index (weakenΔI l lpr)
     weakenΔN l (rfoc p) = rfoc (weakenΔR l p)
     weakenΔN l (⊃R p) = ⊃R (weakenΔN l p)
     weakenΔN {Δ = Δ} {Δ' = Δ'} l (∀R p) = ∀R (weakenΔN (weaken-subsetΔ Δ Δ' l) p)
     weakenΔN l (claimsL p ind lt) = claimsL (l p) (weakenΔL l ind) lt

     weakenΔI :  ∀ {Ω Γ+ Δ k Δ' A B} -> Δ ⊆ Δ' -> (join Ω Γ+ Δ k) ⊢I A > B ->
                (join Ω Γ+ Δ' k) ⊢I A > B
     weakenΔI l (∧L p)  = ∧L (weakenΔN l p)  
     weakenΔI l (∨L p1 p2) = ∨L (weakenΔN l p1) (weakenΔN l p2)
     weakenΔI {Δ = Δ} {Δ' = Δ'} l (∃L p) = ∃L (weakenΔN (weaken-subsetΔ _ _ l) p)
     weakenΔI l (saysL p)  = saysL (weakenΔN (⊆-::-cong l) p)
     weakenΔI l (⊤L p) = (⊤L (weakenΔN l p) )
     weakenΔI l ⊥L  = ⊥L