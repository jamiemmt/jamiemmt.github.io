open import lib.Prelude
open List.Subset
open List.ListOP
open FailureMonad


import sectyp.manifest.focus.Aprop
open import sectyp.manifest.focus.PropSig


module sectyp.manifest.focus.Propositions (r : PropSig) where

  module PropSigInt = PropSig r 
  open PropSigInt


  module ApropInt =  sectyp.manifest.focus.Aprop ASig 
  open ApropInt
  open ApropInt.ApropSigInt
  open ApropInt.TermsInt
  open ApropInt.TermsInt.TermSigInt

  data Polarity : Set where
    Pos : Polarity
    Neg : Polarity

  mutual 
    Propo+ = Propo Pos
    Propo- = Propo Neg

    data Propo : Polarity -> ICtx -> Set where
      _⊃_ : ∀ {Ω} -> Propo+ Ω -> Propo- Ω -> Propo- Ω
      ∀i_ : ∀ {Ω τ} -> Propo- (τ :: Ω) -> Propo- Ω  -- because τ is an implicit argument, write (∀i A)
      a-  : ∀ {Ω} -> Aprop Ω -> Propo- Ω
      ↑   : ∀ {Ω} -> Propo+ Ω -> Propo- Ω

      _∨_ : ∀ {Ω} -> Propo+ Ω -> Propo+ Ω -> Propo+ Ω
      _∧_ : ∀ {Ω} -> Propo+ Ω -> Propo+ Ω -> Propo+ Ω
      ⊥ : ∀ {Ω} -> Propo+ Ω
      ⊤ : ∀ {Ω} -> Propo+ Ω
      ∃i_ : ∀ {Ω τ} -> Propo+ (τ :: Ω) -> Propo+ Ω
      _says_ : ∀ {Ω} -> Term Ω (▸ principal) -> Propo- Ω -> Propo+ Ω
      a+ : ∀ {Ω} -> Aprop Ω -> Propo+ Ω
      ⇣  : ∀ {Ω} -> Propo- Ω -> Propo+ Ω



  -- application seems to be 20
  infix  99 a+  -- should bind as tightly as possible
  infix  99 a-
  infixr 15 _⊃_ -- implication binds looser than prods and sums
  infixr 16 _∧_ -- products tighter than sums
  infixr 17 _∨_
  infixr 14 _says_  -- looser than everyone
  infix  1 ∀i_ -- so they extend as far to the right as possible
  infix  1 ∃i_
  infix  1 ∀e_·_ 
  infix  1 ∃e_·_

  ∀e_·_ : ∀ {Ω} (τ : BaseType) -> Propo- (τ :: Ω) -> Propo- Ω
  ∀e_·_ τ A = ∀i A

  ∃e_·_ : ∀ {Ω} (τ : BaseType) -> Propo+ (τ :: Ω) -> Propo+ Ω
  ∃e_·_ τ A = ∃i A

  extendWkn : ∀ {Ω Ω'} -> {τ : BaseType} -> Ω ⊆ Ω' -> (τ :: Ω) ⊆ (τ :: Ω') 
  extendWkn SS i0  = i0
  extendWkn SS (iS x) = iS (SS x)

  weakenP : ∀ {Ω Ω' p} -> Propo p Ω -> Ω ⊆ Ω' -> Propo p Ω'
  weakenP  (a ∧ b) F = (weakenP a F) ∧ (weakenP b F)
  weakenP  (a ∨ b) F = (weakenP a F) ∨ (weakenP b F) 
  weakenP (a ⊃ b) F = (weakenP a F) ⊃ (weakenP b F)
  weakenP ⊤ F = ⊤
  weakenP ⊥ F = ⊥
  weakenP (∀i_{Ω}{τ} a) F =  ∀i  (weakenP a (extendWkn F))
  weakenP (∃i_{Ω}{τ} a) F = ∃i (weakenP a (extendWkn F))
  weakenP (k says a) F  = (weakenTerm k F) says (weakenP a F)
  weakenP (a+ a) F = a+ (weakenAP a F)
  weakenP (a- a) F = a- (weakenAP a F)
  weakenP (↑ a) F = ↑ (weakenP a F)
  weakenP (⇣ a) F = ⇣ (weakenP a F)

  extendSub : ∀ {Ω Ω'} -> ( ∀ {τ} -> τ ∈ Ω  ->  Term Ω' (▸ τ)) -> (τ1 : BaseType) ->
           ( ∀ {τ} -> τ ∈ (τ1 :: Ω)  ->  Term (τ1 :: Ω') (▸ τ)) 
  extendSub Fn τ i0 = (▹ i0)
  extendSub Fn τ (iS x) =  weakenTerm (Fn x) (λ x' → iS x') 
   
  substP : ∀ {Ω Ω' p} -> Propo p Ω -> ( ∀ {τ} -> τ ∈ Ω  ->  Term Ω' (▸ τ)) ->  Propo p Ω'
  substP (a ∧ b) F = (substP a F) ∧ (substP b F) 
  substP (a ∨ b) F = (substP a F) ∨ (substP b F)
  substP (a ⊃ b) F = (substP a F) ⊃ (substP b F)
  substP ⊤ F = ⊤
  substP ⊥ F = ⊥
  substP (p says a) F = (substTerm p F) says substP a F
  substP (∀i_ {Ω}{τ} a) F  = ∀i substP a (extendSub F τ)
  substP (∃i_ {Ω}{τ} a) F = ∃i substP a (extendSub F τ)
  substP (a+ a) F = a+ (substAP a F)
  substP (a- a) F = a- (substAP a F)
  substP (⇣ a) F = ⇣ (substP a F)
  substP (↑ a) F = ↑ (substP a F)

  substlast : ∀ {p} -> {Ω : ICtx} {τ : BaseType}  -> Propo p (τ :: Ω) -> Term Ω (▸ τ) -> Propo p Ω
  substlast {p}{Ω}{τ}a k = substP a sub where
    sub : ∀ {τ'} -> τ' ∈ (τ :: Ω) -> Term Ω (▸ τ')
    sub i0 = k
    sub (iS x) = identity x

  propEq : ∀ {p} -> {Ω : ICtx} -> (A : Propo p Ω) -> (B : Propo p Ω) -> Maybe (Id A B)
  propEq (a+ a) (a+ a') = map (λ x → Id.substeq a+ x) (atomEq a a')
  propEq (a- a) (a- a') = map (λ x → Id.substeq a- x) (atomEq a a')
  propEq (⇣ a) (⇣ a') = map (\ x -> Id.substeq ⇣ x) (propEq a a')
  propEq (↑ a) (↑ a') = map (\ x -> Id.substeq ↑ x) (propEq a a')
  propEq (a ∨ b) (a' ∨ b') = ( (propEq a a')) >>= (\ y -> map (\ z -> Id.substeq2 (\ f g -> f ∨ g) y z) (propEq b b'))
  propEq (a ∧ b) (a' ∧ b') =  ( (propEq a a')) >>= (\ y -> map (\ z -> Id.substeq2 (\ f g -> f ∧ g) y z) (propEq b b'))
  propEq (k says a) (k' says a') = ( (termEq k k')) >>= (\ y -> map (\ z -> Id.substeq2 (\ f g -> f says g) y z) (propEq a a'))
  propEq (∃i_{Ω}{τ}  a) (∃i_{.Ω}{τ'} a') with typeEq(τ)(τ') 
  propEq (∃i_ {Ω}{τ} a) (∃i_{.Ω}{.τ} a')      | (Some Refl) = map (λ x → Id.substeq (λ y → ∃i y) x) (propEq a a')
  propEq (∃i_ {Ω}{τ} a) (∃i_{.Ω}{τ'} a')      | None = None
  propEq (∀i_{Ω}{τ}  a) (∀i_{.Ω}{τ'} a') with typeEq(τ)(τ')
  propEq (∀i_ {Ω}{τ} a) (∀i_{.Ω}{.τ} a')      | Some Refl =  map (λ x → Id.substeq (λ y → ∀i y) x) (propEq a a')
  propEq (∀i_ {Ω}{τ} a) (∀i_{.Ω}{τ'} a')      | None = None
  propEq ⊤ ⊤ = Some Refl
  propEq ⊥ ⊥ = Some Refl
  propEq (a ⊃ b) (a' ⊃ b') = ( (propEq a a')) >>= (\ y -> map (\ z -> Id.substeq2 (\ f g -> f ⊃ g) y z) (propEq b b'))
  propEq _ _ = None

  propEq/dec : ∀ {p} -> {Ω : ICtx} -> (A : Propo p Ω) -> (B : Propo p Ω) -> Either (Id A B) (Id A B -> Void)
  propEq/dec a b with propEq a b
  propEq/dec a .a | Some Refl = Inl Refl
  propEq/dec a b | None = Inr fixmecertifyfail where
    postulate
      fixmecertifyfail : _

  propEqB :  ∀ {p} -> {Ω : ICtx} -> (A : Propo p Ω) -> (B : Propo p Ω) -> Bool
  propEqB a b with (propEq a b)
  ... | Some _ = True
  ... | None = False

  -- properties of weakening and subst

  extendWkn-id : ∀ {Ω} -> {τ : BaseType} -> {w : Ω ⊆ Ω} -> IsId w -> IsId (extendWkn {_}{_}{τ} w)
  extendWkn-id p i0 = Refl
  extendWkn-id p (iS i) = Id.substeq iS (p i)
  
  weakenP-id : ∀ {Ω} -> {w : Ω ⊆ Ω} -> IsId w -> {p : Polarity} (A : Propo p Ω) -> Id (weakenP A w) A
  weakenP-id F (a ∧ b) = Id.substeq2 _∧_ (weakenP-id F a) (weakenP-id F b)
  weakenP-id F (a ∨ b) = Id.substeq2 _∨_ (weakenP-id F a) (weakenP-id F b)
  weakenP-id F (a ⊃ b) = Id.substeq2 _⊃_ (weakenP-id F a) (weakenP-id F b)
  weakenP-id F ⊤ = Refl
  weakenP-id F ⊥ = Refl
  weakenP-id F (↑ a) = Id.substeq ↑ (weakenP-id F a)
  weakenP-id F (⇣ a) = Id.substeq ⇣ (weakenP-id F a)
  weakenP-id F (k says a)  = Id.substeq2 _says_ (weakenTerm-id F k) (weakenP-id F a)
  weakenP-id F (a+ a) = Id.substeq a+ (weakenAP-id F a) 
  weakenP-id F (a- a) = Id.substeq a- (weakenAP-id F a) 
  weakenP-id F (∀i a) = Id.substeq ∀i_ (weakenP-id (extendWkn-id F) a)
  weakenP-id F (∃i a) = Id.substeq ∃i_ (weakenP-id (extendWkn-id F) a)

  extendWkn-ext : ∀ {Ω Ω' τ} -> {w1 w2 : Ω ⊆ Ω'} -> WEq w1 w2 -> WEq (extendWkn{_}{_}{τ} w1) (extendWkn w2)
  extendWkn-ext wid i0 = Refl
  extendWkn-ext wid (iS i) = Id.substeq iS (wid i)

  extendWkn-hext : ∀ {Ω Ω1' Ω2' τ} -> {w1 : Ω ⊆ Ω1'} {w2 : Ω ⊆ Ω2'} 
                 -> Id Ω1' Ω2' 
                 -> WHEq w1 w2 -> WHEq (extendWkn{_}{_}{τ} w1) (extendWkn w2)
  extendWkn-hext Refl p i0 = HRefl
  extendWkn-hext Refl p (iS i) = Id.Het.substeq/hom iS (p i)

  weakenP-ext : ∀ {Ω Ω'} {w1 w2 : Ω ⊆ Ω'} -> WEq w1 w2 -> {p : Polarity} (t : Propo p Ω) -> Id (weakenP t w1) (weakenP t w2)
  weakenP-ext wid (a ∧ b) = Id.substeq2 _∧_ (weakenP-ext wid a) (weakenP-ext wid b)
  weakenP-ext wid (a ∨ b) = Id.substeq2 _∨_ (weakenP-ext wid a) (weakenP-ext wid b)
  weakenP-ext wid (a ⊃ b) = Id.substeq2 _⊃_ (weakenP-ext wid a) (weakenP-ext wid b)
  weakenP-ext wid ⊤ = Refl
  weakenP-ext wid ⊥ = Refl
  weakenP-ext wid (↑ a) = Id.substeq ↑ (weakenP-ext wid a)
  weakenP-ext wid (⇣ a) = Id.substeq ⇣ (weakenP-ext wid a)
  weakenP-ext wid (k says a)  = Id.substeq2 _says_ (weakenTerm-ext wid k) (weakenP-ext wid a)
  weakenP-ext wid (a+ a) = Id.substeq a+ (weakenAP-ext wid a) 
  weakenP-ext wid (a- a) = Id.substeq a- (weakenAP-ext wid a) 
  weakenP-ext wid (∀i a) = Id.substeq ∀i_ (weakenP-ext (extendWkn-ext wid) a) 
  weakenP-ext wid (∃i a) = Id.substeq ∃i_ (weakenP-ext (extendWkn-ext wid) a) 

  weakenP-hext : ∀ {p} -> Weaken-Hext (Propo p) weakenP
  weakenP-hext Refl wid (a ∧ b) = Id.Het.substeq/hom2 _∧_ (weakenP-hext Refl wid a) (weakenP-hext Refl wid b)
  weakenP-hext Refl wid (a ∨ b) = Id.Het.substeq/hom2 _∨_ (weakenP-hext Refl wid a) (weakenP-hext Refl wid b)
  weakenP-hext Refl wid (a ⊃ b) = Id.Het.substeq/hom2 _⊃_ (weakenP-hext Refl wid a) (weakenP-hext Refl wid b)
  weakenP-hext Refl wid ⊤ = HRefl
  weakenP-hext Refl wid ⊥ = HRefl
  weakenP-hext Refl wid (↑ a) = Id.Het.substeq/hom ↑ (weakenP-hext Refl wid a)
  weakenP-hext Refl wid (⇣ a) = Id.Het.substeq/hom ⇣ (weakenP-hext Refl wid a)
  weakenP-hext Refl wid (k says a)  = Id.Het.substeq/hom2 _says_ (weakenTerm-hext Refl wid k) (weakenP-hext Refl wid a)
  weakenP-hext Refl wid (a+ a) = Id.Het.substeq/hom a+ (weakenAP-hext Refl wid a) 
  weakenP-hext Refl wid (a- a) = Id.Het.substeq/hom a- (weakenAP-hext Refl wid a) 
  weakenP-hext Refl wid (∀i a) = Id.Het.substeq/hom ∀i_ (weakenP-hext Refl (extendWkn-hext Refl wid) a) 
  weakenP-hext Refl wid (∃i a) = Id.Het.substeq/hom ∃i_ (weakenP-hext Refl (extendWkn-hext Refl wid) a) 

  extend-compose : ∀ {Ω1 Ω2 Ω3 τ} -> {w2 : Ω2 ⊆ Ω3} {w1 : Ω1 ⊆ Ω2} 
                  -> WEq (extendWkn{_}{_}{τ} (w2 ∘ w1)) ((extendWkn w2) ∘ (extendWkn w1))
  extend-compose i0 = Refl
  extend-compose (iS i) = Refl

  weakenP∘ : ∀ {Ω1 Ω2 Ω3} -> (w2 : Ω2 ⊆ Ω3) (w1 : Ω1 ⊆ Ω2) -> {p : Polarity} (A : Propo p Ω1) -> Id (weakenP A (\{_} -> w2 ∘ w1)) (weakenP (weakenP A w1) w2)
  weakenP∘ W1 W2 (a ∧ b) = Id.substeq2 _∧_ (weakenP∘ W1 W2 a) (weakenP∘ W1 W2 b)
  weakenP∘ W1 W2 (a ∨ b) = Id.substeq2 _∨_ (weakenP∘ W1 W2 a) (weakenP∘ W1 W2 b)
  weakenP∘ W1 W2 (a ⊃ b) = Id.substeq2 _⊃_ (weakenP∘ W1 W2 a) (weakenP∘ W1 W2 b)
  weakenP∘ W1 W2 ⊤ = Refl
  weakenP∘ W1 W2 ⊥ = Refl
  weakenP∘ W1 W2 (↑ a) = Id.substeq ↑ (weakenP∘ W1 W2 a)
  weakenP∘ W1 W2 (⇣ a) = Id.substeq ⇣ (weakenP∘ W1 W2 a)
  weakenP∘ W1 W2 (k says a)  = Id.substeq2 _says_ (weakenTerm∘ W1 W2 k) (weakenP∘ W1 W2 a)
  weakenP∘ W1 W2 (a+ a) = Id.substeq a+ (weakenAP∘ W1 W2 a) 
  weakenP∘ W1 W2 (a- a) = Id.substeq a- (weakenAP∘ W1 W2 a) 
  weakenP∘ W1 W2 (∀i a) = Id.substeq ∀i_ ( Id.trans (weakenP-ext extend-compose a) (weakenP∘ (extendWkn W1) (extendWkn W2) a) )
  weakenP∘ W1 W2 (∃i a) = Id.substeq ∃i_ ( Id.trans (weakenP-ext extend-compose a) (weakenP∘ (extendWkn W1) (extendWkn W2) a) )

