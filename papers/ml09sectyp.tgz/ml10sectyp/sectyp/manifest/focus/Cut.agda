open import lib.Prelude
open List.Subset
open Backtrack

open import sectyp.manifest.focus.Terms
open import sectyp.manifest.focus.Aprop
open import sectyp.manifest.focus.Accessibility 
open import sectyp.manifest.focus.Propositions
open import sectyp.manifest.focus.Proofs
open Contexts
open Weaken

module sectyp.manifest.focus.Cut where
  mutual
    cal1 : ∀ {θ A B} -> θ ⊢R A -> θ ⊢I A > B -> θ ⊢ B
    cal1 ⊤R (⊤L pB) = pB
    cal1 (∧R p1 p2) (∧L pnb) = cal3 (cal3 pnb i0 (weakenΓ+R (λ x → iS x) p1))  i0 p2
    cal1 (∨R1 p1) (∨L pnb1 pnb2) = cal3 pnb1 i0 p1
    cal1 (∨R2 p2) (∨L pnb1 pnb2) = cal3 pnb2 i0 p2
    cal1 (saysR psay) (saysL psb) = calsayN psb i0 psay
    cal1 (∃R t ep) (∃L pIb) = {!!}
    cal1 (blurR a) ()
    cal1 (init+ a) ()
    

    lfoclemma : ∀ {θ A B C} -> θ ⊢L A > B -> θ ⊢L B > C -> θ ⊢L A > C
    lfoclemma init- init- = init-
    lfoclemma (⊃L pa pbtoc) x = ⊃L pa (lfoclemma pbtoc x)
    lfoclemma (∀L t psub) x = ∀L t (lfoclemma psub x)
    lfoclemma (blurL pn) x = blurL (cal2 pn (weakenΓ+L (λ x' → iS x') x))
    
    linvlemma : ∀ {θ A B C} -> θ ⊢I A > B -> θ ⊢L B > C -> θ ⊢I A > C
    linvlemma (⊤L p) x = ⊤L (cal2 p x)
    linvlemma ⊥L x = ⊥L
    linvlemma (∧L p) x = ∧L (cal2 p (weakenΓ+L (λ x' → iS (iS x')) x))
    linvlemma (∨L p1 p2) x = ∨L (cal2 p1 (weakenΓ+L (λ x' → iS x') x)) (cal2 p2 (weakenΓ+L (λ x' → iS x') x))
    linvlemma (saysL ps) x = saysL (cal2 ps (weakenΔL (λ x' → iS x') x))
    linvlemma (∃L s ) x = {! ∃L s !}
    
    cal2 : ∀ {θ A C} -> θ ⊢ A -> θ ⊢L A > C  -> θ ⊢ C
    cal2 (lfoc index lpr) x = lfoc index (lfoclemma lpr x)
    cal2 (linv index lpr) x = linv index (linvlemma lpr x)
    cal2 (rfoc rpr) (blurL pn) = cal3 pn i0 rpr
    cal2 (⊃R atob) (⊃L pa pbtoc) = cal2 (cal3 atob i0 pa) pbtoc
    cal2 (∀R ext) (∀L t psub) = {!!}
    cal2 (claimsL index lpr lt) x = claimsL index (lfoclemma lpr x) lt
  
    cal3 : ∀ {Ω Γ+ Δ k A B} -> (join Ω Γ+ Δ k) ⊢ B -> (t : A ∈ Γ+) ->  
               (join Ω  (List.In.remove  Γ+ t) Δ k ) ⊢R A -> (join Ω  (List.In.remove  Γ+ t) Δ k ) ⊢ B 

    cal3 (lfoc index lpr) i x = {!!}
    cal3 (linv index lpr) i x = cal2 {!!} {!!}
    cal3 (rfoc rpr) i x = {!!}
    cal3 (⊃R atob) i x = ⊃R (cal3 atob (iS i) (weakenΓ+R (λ x' → iS x') x))
    cal3 (∀R ext) i x = ∀R {!cal3 ? ? ?!}
    cal3 (claimsL index lpr lt) i x = claimsL index {!!} lt


    calsayN : ∀ {Ω Γ+ Δ k k0 A B} -> (join Ω Γ+ Δ k) ⊢ B -> (t : (k0 claims A) ∈ Δ) ->
             (join Ω [] (List.In.remove Δ t) k0) ⊢ A ->
             (join Ω Γ+ (List.In.remove Δ t) k) ⊢ B
    calsayN (lfoc index lpr) ptr pempty = lfoc index (calsayL lpr ptr pempty)
    calsayN (linv index lpr) ptr pempty = linv index (calsayI lpr ptr pempty)
    calsayN (rfoc rpr) ptr pempty = rfoc {!!}
    calsayN (⊃R atob) ptr pempty = ⊃R (calsayN atob ptr pempty)
    calsayN (∀R ext0) ptr pempty = ∀R {!calsayN ext0 ? pempty!}
    calsayN (claimsL index lpr lt) ptr pempty = claimsL {!!} (calsayL lpr ptr pempty) lt


    calsayL : ∀ {Ω Γ+ Δ k k0 A B C} -> (join Ω Γ+ Δ k) ⊢L A > B -> (t : (k0 claims C) ∈ Δ) ->
             (join Ω [] (List.In.remove Δ t) k0) ⊢ C ->
             (join Ω Γ+ (List.In.remove Δ t) k) ⊢L A > B
    calsayL = {!!}

    calsayI :  ∀ {Ω Γ+ Δ k k0 A B C} -> (join Ω Γ+ Δ k) ⊢I A > B -> (t : (k0 claims C) ∈ Δ) ->
             (join Ω [] (List.In.remove Δ t) k0) ⊢ C ->
             (join Ω Γ+ (List.In.remove Δ t) k) ⊢I A > B
    calsayI = {!!}
