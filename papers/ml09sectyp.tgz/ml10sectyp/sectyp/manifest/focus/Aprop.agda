open import lib.Prelude
open List.Subset
open FailureMonad

open import sectyp.manifest.focus.ApropSig
import sectyp.manifest.focus.Terms

module sectyp.manifest.focus.Aprop (r : ApropSig)  where
  module ApropSigInt =  ApropSig r
  open ApropSigInt

  module TermsInt = sectyp.manifest.focus.Terms TSig
  open TermsInt

  data Aprop : ICtx -> Set where
    _·_ : ∀ {Ω τ} -> PConst τ -> Term Ω τ -> Aprop Ω
  infix 0 _·_  
  
  weakenAP : ∀ {Ω Ω'} -> Aprop Ω -> Ω ⊆ Ω' -> Aprop Ω'
  weakenAP (p · t) SS = p · (weakenTerm t SS)

  substAP : ∀ {Ω Ω'} -> Aprop Ω -> ( ∀ {τ} -> τ ∈ Ω  ->  Term Ω' (▸ τ)) ->  Aprop Ω'
  substAP (p · t) SS = p · (substTerm t SS)

  atomEq : ∀ {Ω} -> (A : Aprop Ω) -> (B : Aprop Ω) -> Maybe (Id A B)
  atomEq (p · t) (p' · t') with (pconstEq p p')
  ... | None = None
  atomEq (p · t) (.p · t') | Some ( Refl , HRefl) with (termEq t t')
  atomEq (p · t) (.p · .t) | Some ( Refl , HRefl) | Some Refl = Some Refl
  atomEq (p · t) (.p · t') | Some ( Refl , HRefl) | None = None



  -- lemmas about weakening and subst

  weakenAP-id : ∀ {Ω} -> {w : Ω ⊆ Ω} -> IsId w -> (A : Aprop Ω) -> Id (weakenAP A w) A
  weakenAP-id isid (p · t)  = Id.substeq (\ x -> p · x) (weakenTerm-id isid t)



  weakenAP∘ : ∀ {Ω1 Ω2 Ω3} -> (w2 : Ω2 ⊆ Ω3) (w1 : Ω1 ⊆ Ω2) -> (A : Aprop Ω1) -> 
            Id (weakenAP A (\{_} -> w2 ∘ w1)) (weakenAP (weakenAP A w1) w2)
  weakenAP∘ w1 w2 (p · t) = Id.substeq (\ x -> p · x) (weakenTerm∘ w1 w2 t) 


  weakenAP-ext : ∀ {Ω Ω'} {w1 w2 : Ω ⊆ Ω'} -> WEq w1 w2 -> (t : Aprop Ω) -> Id (weakenAP t w1) (weakenAP t w2)
  weakenAP-ext wid (p · t) = Id.substeq (\ x -> p · x) (weakenTerm-ext wid t)


  weakenAP-hext : Weaken-Hext Aprop weakenAP
  weakenAP-hext Refl wid (p · t) =
    Id.Het.substeq/hom (λ x → p · x) (weakenTerm-hext Refl wid t)

