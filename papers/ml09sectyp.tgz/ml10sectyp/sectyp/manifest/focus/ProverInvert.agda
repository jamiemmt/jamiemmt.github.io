{-# OPTIONS --no-termination-check #-}

open import lib.Prelude
open List.Subset
open import lib.SumsProds
open FailureMonad
open List using (_++_)


open import sectyp.manifest.focus.PropSig
import sectyp.manifest.focus.Proofs


module sectyp.manifest.focus.ProverInvert (r : PropSig) where
 
 module ProofsInt =  sectyp.manifest.focus.Proofs r 
 open ProofsInt
 open PropInt
 open PropInt.PropSigInt
 open PropInt.ApropInt
 open PropInt.ApropInt.ApropSigInt
 open PropInt.ApropInt.TermsInt
 open PropInt.ApropInt.TermsInt.TermSigInt

 open Weaken



 


 rassoc : (P : ICtx -> Set) (Ω1 Ω2 Ω3 : ICtx) -> P ((Ω1 ++ Ω2) ++ Ω3) -> P (Ω1 ++ (Ω2 ++ Ω3))
 rassoc P Ω1 Ω2 Ω3 e = Id.subst P (List.append-assoc {_} {Ω1} {Ω2} {Ω3} ) e 

 lassoc : (P : ICtx -> Set) (Ω1 Ω2 Ω3 : ICtx) -> P (Ω1 ++ (Ω2 ++ Ω3)) -> P ((Ω1 ++ Ω2) ++ Ω3)
 lassoc P Ω1 Ω2 Ω3 e = Id.subst P (Id.sym (List.append-assoc {_} {Ω1} {Ω2} {Ω3} )) e 

 CtxGuts : ICtx -> Set
 CtxGuts Ω = TCtx+ Ω × CCtx Ω × Term Ω (▸ principal)

 gutsToCtx : ∀ {Ω} ->  (A : CtxGuts Ω) -> (Ctx)
 gutsToCtx {Ω} triple = join Ω (fst triple) (fst (snd triple)) (snd (snd triple))

 -- context in an extended context 
 ECtx : ICtx -> Set
 ECtx Ω = Σ \ Ω' -> CtxGuts (Ω' ++ Ω)

 bindτ : ∀ {τ Ω} -> ECtx (τ :: Ω) -> ECtx Ω
 bindτ {τ} {Ω} (Ω' , Γ' , Δ' , k) = 
       (Ω' ++ [ τ ]) , lassoc TCtx+ Ω' [ τ ] Ω Γ' , lassoc CCtx Ω' [ τ ] Ω Δ' , lassoc (\ x -> Term x (▸ principal)) Ω' [ τ ] Ω  k

 weakenGuts : ∀ {Ω Ω'} -> Ω ⊆ Ω' -> CtxGuts Ω -> CtxGuts Ω' 
 weakenGuts w (Γ , Δ , k) = (weakenT+ Γ w , weakenC Δ w , weakenTerm k w)

 {- invariant : the Γ of Gstab is only non-invertible stuff  -}
 invert : ∀ {Ω} -> (Γinv : TCtx+ Ω) -> (Gstab : CtxGuts Ω) -> List (ECtx Ω)
 invert [] Gstab = [ [] , Gstab ]
 invert ((A ∧ B) :: Γ) Gstab = invert (A :: B :: Γ) Gstab
 invert ((A ∨ B) :: Γ) Gstab = invert (A :: Γ) Gstab ++ invert (B :: Γ) Gstab
 invert (⊤ :: Γ) Gstab = invert Γ Gstab
 invert (⊥ :: Γ) Gstab = []
 invert ((∃i_ {_}{τ} A) :: Γ) Gstab = List.map bindτ (invert (A :: (weakenT+ Γ iS)) (weakenGuts iS Gstab))
 invert (⇣ A :: Γ) (Γs , Δ , k) = invert Γ (⇣ A :: Γs , Δ , k)
 invert (a+ p :: Γ) (Γs , Δ , k) = invert Γ (a+ p :: Γs , Δ , k)
 invert ((k0 says A) :: Γ) (Γs , Δ , k) = invert Γ (Γs , (k0 claims A) :: Δ , k)

 weakenToECtx : ∀ {Ω p} -> Propo p Ω -> (G : ECtx Ω) -> Propo p (fst G ++ Ω)
 weakenToECtx A X = weakenP A (List.In.skip (fst X))

 ectxToCtx : ∀ {Ω} -> ECtx Ω -> Ctx
 ectxToCtx E = gutsToCtx (snd E)

 -- the wrapper to use from the outside
 invertCtx : (θ : Ctx) -> List (ECtx (ictx θ))
 invertCtx θ = invert  (Ctx-rΓ+ θ) ([] , Ctx-rΔ θ , Ctx-rk θ)

 moveToFront : ∀ {Ω A} {Γ2 : TCtx+ Ω} (Γ1 : TCtx+ Ω) -> (Γ1 ++ (A :: Γ2)) ⊆ (A :: (Γ1 ++ Γ2))
 moveToFront Γ1 i with List.In.splitappend Γ1 _ i
 ... | Inl i' = iS (List.In.skip/right Γ1 i')
 ... | Inr i0 = i0
 ... | Inr (iS i') = iS (List.In.skip Γ1 i')

 addSecond : ∀ {Ω A C} {Γ : TCtx+ Ω} -> (A :: Γ) ⊆ (A :: C :: Γ)
 addSecond i0     = i0
 addSecond (iS i) = iS (iS i)

 invert-sound : ∀ {Ω} {A : Propo- Ω}
              -> (Γ : TCtx+ Ω)
              -> (Γstab : TCtx+ Ω) (Δstab : CCtx Ω) {kstab : Term Ω (▸ principal)} 
              -> (∀ {Ω' Γ' Δ' k'} 
                    -> (Ω' , (Γ' , Δ' , k')) ∈ invert Γ (Γstab , Δstab , kstab) 
                    -> (join _ Γ' Δ' k') ⊢ weakenP A (\ x -> List.In.skip Ω' x)) 
              -> (join Ω (Γ ++ Γstab) Δstab kstab) ⊢ A
 invert-sound [] Γstab Δstab {kstab} f = 
   Id.subst (\ C -> join _ Γstab Δstab kstab ⊢ C) (weakenP-id (\ _ -> Refl) _) (f i0)
 invert-sound ((A ∨ B) :: Γ) Γstab Δstab f = 
   linv i0 (∨L (weakenΓ+N addSecond (invert-sound (A :: Γ) Γstab Δstab
                                  (\ {Ω'} {Γ'} i -> f (List.In.skip/right (invert (A :: Γ) _) i))))
               ((weakenΓ+N addSecond (invert-sound (B :: Γ) Γstab Δstab
                                   (\ {Ω'} {Γ'} i -> f (List.In.skip (invert (A :: Γ) _) i))))))
 invert-sound ((A ∧ B) :: Γ) Γstab Δstab f = linv i0 (∧L (weakenΓ+N w (invert-sound (A :: B :: Γ) Γstab Δstab f))) where
   w : (A :: B :: (Γ ++ Γstab)) ⊆ (A :: B :: (A ∧ B) :: (Γ ++ Γstab))
   w i0      = i0
   w (iS i0) = iS i0
   w (iS (iS i))  = iS (iS (iS i)) 
 invert-sound ((k says A) :: Γ) Γstab Δstab f = linv i0 (saysL (weakenΓ+N iS (invert-sound Γ Γstab ((k claims A) :: Δstab) f)))
 invert-sound (a+ p :: Γ) Γstab Δstab f = weakenΓ+N (moveToFront Γ) (invert-sound Γ (a+ p :: Γstab) Δstab f)
 invert-sound (⇣ A :: Γ) Γstab Δstab f = weakenΓ+N (moveToFront Γ) (invert-sound Γ (⇣ A :: Γstab) Δstab f)
 invert-sound (⊥ :: Γ) Γstab Δstab f = linv i0 ⊥L
 invert-sound (⊤ :: Γ) Γstab Δstab f = linv i0 (⊤L (weakenΓ+N iS (invert-sound Γ Γstab Δstab f)))
 invert-sound {Ω} {C} ((∃i_ {.Ω}{τ} A) :: Γ) Γstab Δstab {kstab} f = linv i0 (∃L (weakenΓ+N addSecond r')) where
   unstick : ∀ {Ω Ω'} {Γ : TCtx+ Ω} {Δ : CCtx Ω} (id : Id Ω Ω') {J : _} {k : _}
     -> join _ (Id.subst TCtx+ id Γ) (Id.subst CCtx id Δ) (Id.subst (\ x -> Term x (▸ principal)) id k) ⊢ J
     -> join _ Γ Δ k ⊢ (Id.subst Propo- (Id.sym id) J)
   unstick Refl e = e

   hid-wknings : ∀ {Ω Ω'} -> ({τ' : BaseType} (x : τ' ∈ Ω) → HId (List.In.iSmany Ω (Ω' ++ (τ :: [])) x) (List.In.iSmany (τ :: Ω) Ω' (iS x)))
   hid-wknings {Ω} {[]} x = HRefl
   hid-wknings {Ω} {τ0' :: Ω'} {τ'} x =
     Id.Het.substeq/ind {ICtx}
                        (\ {Ωarg : ICtx} (x : τ' ∈ Ωarg)-> iS {_} {τ0'} x)
                        {(Ω' ++ [ τ ]) ++ Ω}
                        {Ω' ++ (τ :: Ω)}
                        (Id.Het.fromHom ((List.append-assoc {_}{Ω'}{[ τ ]}{Ω})))
                        {(List.In.iSmany Ω (Ω' ++ (τ :: [])) x)}
                        {(List.In.iSmany (τ :: Ω) Ω' (iS x))}
                        (hid-wknings {Ω} {Ω'} x) 

   f' : (∀ {Ω' Γ' Δ' k'} -> (Ω' , (Γ' , Δ' , k')) ∈ invert (A :: weakenT+ Γ iS) (weakenGuts iS _) -> join _ Γ' Δ' k' ⊢ _)
   f' {Ω'} {Γ'} {Δ'} {k'} i = fixgoal where
      callf = (f {(Ω' ++ [ τ ])} {lassoc TCtx+ Ω' [ τ ] Ω Γ'} {lassoc CCtx Ω' [ τ ] Ω Δ'} {lassoc (\ x -> Term x (▸ principal)) Ω' [ τ ] Ω k'} (List.In.in-map i))
      fixctxs = unstick (Id.sym (List.append-assoc {_} {Ω'} {[ τ ]} {Ω})) callf
      fixctxs' =  Id.subst (\ A -> join _ Γ' Δ' k' ⊢ A) 
                           ( ( (Id.Het.toHom {ICtx}{Propo-}{(Ω' ++ [ τ ]) ++ Ω}{Ω' ++ (τ :: Ω)}
                                             {weakenP C (List.In.skip (Ω' ++ [ τ ]))}
                                             {weakenP {Ω} {Ω' ++ (τ :: Ω)} C (\ {_} x -> ((List.In.skip Ω') (iS x)))}
                                             (Id.sym (Id.sym (List.append-assoc {_}{Ω'}{[ τ ]}{Ω})))
                                             (weakenP-hext (List.append-assoc{_}{Ω'}{[ τ ]}{Ω}) 
                                               (hid-wknings{_}{Ω'}) C)) ) )
                           fixctxs  
      fixgoal = Id.subst (\ A -> join _ Γ' Δ' k' ⊢ A)
                ( (weakenP∘ {Ω} {(τ :: Ω)} {(Ω' ++ (τ :: Ω))} (List.In.skip Ω') iS _) )
                fixctxs'

   r' : join _ (A :: (weakenT+ (List.append Γ Γstab) iS)) (weakenC Δstab iS) (weakenTerm kstab iS) ⊢ weakenP C iS
   r' = Id.subst (\ Γ -> (join _ (A :: Γ) (weakenC Δstab iS) (weakenTerm kstab iS)) ⊢ (weakenP C iS) ) 
               (List.append-maps Γ Γstab) 
               (invert-sound (A :: weakenT+ Γ iS) 
                             (weakenT+  Γstab iS) 
                             (weakenC Δstab iS)
                             f')