\ignore{
\begin{code}

open import lib.Prelude
open List.Subset
open import lib.SumsProds
open List using (_++_)
open Sums using (solve)

open import sectyp.manifest.focus.newexamples.FileSig
open import sectyp.manifest.focus.newexamples.FileIO
open Uninvariant

open import lib.List

open List.In

module sectyp.manifest.focus.newexamples.ReadDeleg where
\end{code}
}

The above policy is rendered in Agda as the first element of the
following context (list of propositions):

\begin{code}
 Γpolicy = 
  (▸ Prin "Admin" says
   (∀e principal · ∀e principal · ∀e filename ·
       let owner = ▹ (iS (iS i0))
           reader = ▹ (iS i0)
           file = ▹ i0 in 
    ( (  (▸ Prin "HR"  says  (a- (Employee · reader)))
       ∧ (▸ Prin "System" says (a- (Owner · (owner , file))))
       ∧ (owner says (a- (Mayread · (reader , file)))))
     ⊃ 
      (a- (Mayread · (reader , file))))))  :: 
  (▸ Prin "Admin" says
   (∀e principal ·
    ∀e filename ·
     (▸ Prin "System" says (a- (Owner · (▹ iS i0 , ▹ i0))))
    ⊃ 
     (a- (MayChown · (▹ iS i0 , ▹ i0)))))  :: 
    []
\end{code}

Similarly, the second clause expresses a policy that an owner of a file
may change its ownership.  Variables are represented as de Bruijn
indices (\ttt{i0}, \ttt{iS}), constants are represented as injections of
strings (\ttt{Prin "Admin"}), and atomic propositions are tagged with a
\emph{polarity} (\ttt{a+} or \ttt{a-}), which can be thought of as a
hint to the theorem prover. Quantifiers are written \ttt{∀e τ · A},
where τ is the domain of quantification and \ttt{A} is the body of the
quantifier.  Atomic propositions are written \ttt{p · t}, where \ttt{p}
is a proposition constant such as \ttt{Mayread} and \ttt{t} is a term
(see Section~\ref{logic} for details).

Next, we define a context representing a particular file system state.
This context includes all the employee, ownership, and read facts
mentioned above, with one additional clause saying that \ttt{Dan} may
\ttt{su} as \ttt{Jamie}.

\begin{code}
 Γstate = 
     (▸ Prin "System" says 
        (a- (Owner · (▸ Prin "Jamie" , ▸ File "secret·txt")))) 
  :: (▸ Prin "HR" says  (a- (Employee · (▸ Prin "Dan")))) 
  :: (▸ Prin "HR" says  (a- (Employee · (▸ Prin "Jamie")))) 
  :: (▸ Prin "Jamie"  says 
        (a-(Mayread · (▸ Prin "Dan" , ▸ File "secret·txt"))))
  :: (▸ Prin "Jamie"  says  
        (a-(Mayread · (▸ Prin "Jamie" , ▸ File "secret·txt"))))
  :: (▸ Prin "Admin" says 
        (a- (MaySu · (▸ Prin "Dan" , ▸ Prin "Jamie"))))
  :: []

 Γall = Γpolicy ++ Γstate
\end{code} 
\ignore{
\begin{code}
 module DemoProver where
\end{code}}
Finally, we let \ttt{Γall} stand for the append of \ttt{Γpolicy} and
\ttt{Γstate}.

\subsubsection{Compile-time Theorem Proving}

We now explain the use of our theorem prover:
\begin{code}
  goal = a-(Mayread · (▸ Prin "Dan" , ▸ File "secret·txt"))
 
  proof? : Maybe (pfCtx Γall ⊢ goal)
  proof?  = prove 15 
 
  theProof : pfCtx Γall ⊢ goal
  theProof = solve proof?
\end{code}
%
The term \ttt{proof?} sets up a call to the theorem prover, attempting
to prove $\mayread(\dsd{Dan},\dsd{secret.txt})$ using the policy
specified by \ttt{Γall}.  Proofs are represented by the Agda type \ttt{θ
⊢ A}, where θ is a context and \ttt{A} is a proposition.  The function
\ttt{pfCtx : TCtx+ [] → Ctx} coerces a list of propositions (abbreviated
\ttt{TCtx+ []}) such as \ttt{Γall} into a context (see
Section~\ref{logic} for more on the context structure of the logic).
The context and proposition arguments to \ttt{prove} can be inferred by
Agda, and so are left as implicit arguments. The term \ttt{theProof}
checks that the theorem prover succeeds \emph{at compile-time} in this
instance: the function \ttt{solve} has type \ttt{Maybe A → A}, provided
that the \ttt{Maybe A} is known to be of the form \ttt{Some x}.  The
term \ttt{proof?} is (definitionally) equal to \ttt{Some p} in Agda; in
general, a call to the theorem prover on a context and a proposition
that has no free Agda variables will always be equal to either \ttt{Some
p} or to \ttt{None}.

\subsubsection{Computations}

We present a monadic interface for file operations in
Figure~\ref{fig:fileio-sig}.  This figure shows both the generic IO
operations, as well as three file-specific operations for reading,
creating, and changing the owner of a file.  The type \ttt{◯ Γ A Γ'}
represents a computation with precondition Γ and postcondition Γ'.  The
postcondition is a function from \ttt{A}'s to contexts, modelling the
fact that the postcondition can depend on the result of the computation
(see \ttt{create} below).  The generic operations are typed as follows:
The postcondition of \ttt{return} is the same as its precondition,
because it does not modify the state of the world.  Bind (\verb|>>=|)
chains together two computations, where the postcondition of the first
is the precondition of the second, for all results of the computation.
Both pre- and postconditions can be weakened to larger and smaller
contexts, respectively; the \ttt{Good} predicate can be ignored until
Section~\ref{sec:file-invariants} below.  In this interface, primitives
like \ttt{getLine} (reading a line of input) and \ttt{print} do not
change the state and do not require proofs.  The postcondition of
\ttt{error} can be arbitrary, as it will never be reached.  The
remaining computations are defined as follows:

\paragraph{Read} The function \ttt{read} takes a principal \ttt{k} and a
file \ttt{f}, along with a proof that the principal may read the file
(\ttt{Mayread(k,f)}) and that the computation is running as the
principal (\ttt{As(k)}).  the proof must be given in the context Γ that
is the precondition of the computation, ensuring that the proof is valid
in the current state of the world.  \ttt{read} returns a \ttt{String},
and leaves the state unchanged.  The proof argument ensures that
well-typed programs adhere to the authorization policy.  Additionally,
these proofs may be logged for later audit by system
administrators~\citep{aura}.

\ignore{
\begin{code}
 module Read where

 \end{code}}

An example call to \ttt{read} looks like this:

\begin{code}
 jread : ◯ (Γall as "Jamie") String (λ _ → (Γall as "Jamie"))
 jread = read (▸ Prin "Jamie") (▸ File "secret·txt") 
              (solve (prove 17))
 
 jreadprint : ◯ (Γall as "Jamie") Unit (λ _ → (Γall as "Jamie"))
 jreadprint = jread >>= λ x → 
              print ("the secret is: " ^ x)
\end{code}
%
The function call \ttt{Γall as k} is shorthand for adding the proposition
\ttt{As(k)} to the context \ttt{Γall}.  The computation \ttt{jread} reads the
file \ttt{secret.txt} as principal \ttt{Jamie}; the proof argument is
supplied by a call to the theorem prover, which ensures at compile-time
that the required fact is derivable from the policy.  The computation
\ttt{jreadprint} first reads the file and then prints the result.

\paragraph{Create}
The type of create is similar to \ttt{read}, in that it takes a
principal and a proof that the principal can create a file (in this
case, the fact that the principal is a registered user is deemed
sufficient).  It returns a \ttt{String}, the name of the created file,
and illustrates why postconditions must be allowed to depend on the
return value of the computation: the postcondition says that the
principal is the owner of the newly created file. Thus, after 
a call to \ttt{create(k)}, the postconditions signify 
\ttt{System says Owner(k,f)}, where \ttt{f} is the name of the new file.

\paragraph{Chown}

To specify \ttt{chown}, we use a type \ttt{Replace x y Γ Δ}, which means
that Δ is the result of replacing exactly one occurrence of \ttt{x} in Γ
with \ttt{y}.  \ttt{Replace} (whose definition is not shown) is defined
by saying that (1) there is a de Bruijn index \ttt{i} showing that
\ttt{x} is in \ttt{Γ} and (2) \ttt{Δ} is equal to the output of the
function \ttt{replace y i}, which recurs on the index \ttt{i} and
replaces the indicated element by \ttt{y}.  The type of \ttt{chown}
should be read as follows: if the principal \ttt{k} as whom the
computation is running has the authority to change the owner of a file,
and replacing \ttt{owns(k,f)} with \ttt{owns(k', f)} in Γ produces Δ,
then we can produce a computation which changes the owner of \ttt{f} from
\ttt{k} to \ttt{k'}, leaving the remaining context unchanged.


\ignore{
\begin{code}
 mutual
\end{code}}

For an example call to \ttt{chown}, we define a context \ttt{Γstate'}
that is the result of replacing the fact that \ttt{Jamie} owns
\ttt{secret.txt} with \ttt{Dan} owning that file.  Next, we do a call to
\ttt{chown} that, running as \ttt{Dan}, changes the owner of the file
from \ttt{Dan} to \ttt{Jamie}, and then we do a computation as \ttt{Dan}
named \ttt{dreadprint} that reads the file.  \ttt{dreadprint} is defined
below. \ttt{proveReplace} is a tactic for proving  that
Γ' is Γ with the ownership of \ttt{secret.txt} changed. 
\ttt{solve (prove 15)} calls the theorem prover (at compile-time) to prove
the current user has permission to \ttt{chown secret.txt}. 

\begin{code}
  Γstate' =  replace {_} {Γstate}
    (▸ Prin "System" says  
      (a- (Owner · (▸ Prin "Dan" , ▸ File "secret·txt")))) 
    i0
  
  Γall' = Γpolicy ++ Γstate'
  
  dchown : ◯ (Γall' as "Dan") Unit (λ _ → Γall as "Dan")
  dchown = chown (▸ Prin "Dan") (▸ Prin "Dan") (▸ Prin "Jamie") 
            (▸ File "secret·txt") 
            (solve proveReplace) (solve (prove 15)) 
           >> dreadprint

\end{code}

\paragraph{Sudo} 
  We now give a well-typed version of the Unix command \ttt{sudo},
  which allows a principal to run a computation as another principal.
  A first cut for the type of sudo is as follows:
\noagda \begin{code}
  sudo1 :  ∀ { Γ A Γ'} → (k1 k2 : _) 
  → (Proof Γ (a- (MaySu · (k1 ,  k2)))) 
  → ◯ ((a+ (As · k2)) :: Γ) A (λ _ → (a+ (As · k2)) :: Γ') 
  → ◯ ((a+ (As · k1)) :: Γ) A (λ _ → (a+ (As · k1)) :: Γ') 
\end{code}
%
If there is a proof that \ttt{k1} may sudo as \ttt{k2} (e.g., a password
was provided), and \ttt{As(k1)} is in the precondition, then it is
permissible to run a subcomputation as \ttt{k2}.  This subcomputation
have a postcondition saying that it leaves the state running as
\ttt{k2}, and then the overall computation returns to running as
\ttt{k1}.  However, since our contexts are ordered
(represented as lists rather than sets), \ttt{sudo} has the type in Figure~\ref{fig:fileio-sig},
which allows the \ttt{As} facts to occur anywhere in the context.
\ttt{sudo}'s type may be read: if replacing \ttt{As(k1)} with
\ttt{As(k2)} in Γ equals Δ, and if replacing \ttt{As(k2)} with
\ttt{As(k1)} in Δ' equals Γ', and \ttt{k2} has permission to \ttt{su} as
\ttt{k1}, then a computation with preconditions Δ and postconditions Δ'
can produce a computation with preconditions Γ and postconditions
Γ'. 

The following example call to \ttt{sudo} defines a computation as
\ttt{Dan} that \ttt{su}'s as \ttt{Jamie} to run the computation
\ttt{jreadprint} defined above:

\begin{code} 
  dreadprint : ◯ (Γall as "Dan") Unit (λ _ → Γall as "Dan")
  dreadprint = sudo (▸ Prin "Dan" ) (▸ Prin "Jamie") 
               (solve proveReplace) 
               (λ _ → solve proveReplace) 
               (solve (prove 15)) 
               jreadprint 
\end{code}
This requires proving that \ttt{Γstate as "Jamie"} and \ttt{Γstate as "Dan"}
are related by replacing replacing \ttt{As(Prin "Jamie")} with
\ttt{As(Prin "Dan")} (in both directions).  Our tactic
\ttt{proveReplace} proves of these equalities. Additionally, a call to
the theorem prover (\ttt{solve(prove 15)}) proves \ttt{MaySu · (Prin
"Dan" , Prin "Jamie")}.

\paragraph{Acquire}

The function \ttt{acquire} allows a program to check whether a
proposition is true in the state of the world. For example, a call to
\ttt{acquire} might check to see if \ttt{System says owns(Prin "Jamie" ,
File "secret.txt")}. The function \ttt{acquire} takes two continuations:
one to run if the check is successful, whose precondition is extended
with the proposition, and an error handler, whose precondition is the
current context, to run if the check fails.  In fact, we allow
\ttt{acquire} to test an entire context at once: given a context
\ttt{Γn}, a computation with preconditions Γ extended with \ttt{Γn} (the
success continuation), and a computation with preconditions Γ (the error
continuation), \ttt{acquire} returns a computation with preconditions Γ.
We use the notation \ttt{acquire Γn / \_ no⇒ s yes⇒ f} to write a call to
\ttt{acquire} in a pattern-matching style.  The \ttt{\_} elides a
\ttt{Good} argument, which is explained below.

\begin{code} 
  main : ◯ [] Unit (λ _ → []) 
  main = acquire (Γall as "Jamie") / _
          no⇒ print "acquiring policy failed"
          yes⇒ weakenPost jreadprint (λ _ ()) _
\end{code}
%
This example call begins and ends in the empty context.  The call to
\ttt{acquire} examines the system state to check the truth of each of
the propositions in \ttt{Γall as "Jamie"}.  If all of these are true,
then we run \ttt{jreadprint} and use weakening to forget the
postconditions we would know to be true after running
\ttt{jreadprint}. If some proposition cannot be verified, then
\ttt{main} calls \ttt{error}.

\subsubsection{Verifying Policy Invariants}
\label{sec:file-invariants}

When authoring the above monadic signature for file IO, the programmer
may have in mind some invariants about which contexts Γ should be
allowed.  For example, the above type for \ttt{chown} would have
unexpected consequences if there ever were more than one owner of a
file, or more than one copy of \ttt{System says owns(k,f)} in the Γ
(only one copy would be replaced, leaving a file with two owners in the
postcondition).  Our interface permits programmers to specify context
invariants using the predicate \ttt{Good Γ}.  The intended invariant of
the interface is that a monadic computation \ttt{◯ Γ A Γ'} should have
the property that Γ' is good if Γ is.  To achieve this, the weakening
operations and \ttt{acquire} require preconditions that certain contexts
are \ttt{Good}, and the programmer must verify that operations such as
\ttt{read}, \ttt{chown}, and \ttt{sudo} preserve goodness.  This
establishes that all computations provided by the interface preserve
goodness, so it is not necessary to make each monadic operation require
a proof that the precondition is \ttt{Good}---when writing a particular
program, the programmer needs only to verify that the initial policy and
those in calls to weakening and \ttt{acquite} satisfy the invariants.

In the above examples, we took \ttt{Good} to be the trivially true
invariant, so the proofs could be elided with an $\_$.
A simple but nontrivial invariant that one may wish to enforce is that for every file \ttt{f} there
is at most one statement of the form \ttt{System says Owner(\_ , f)}
in the context. This is defined in Agda as follows:
\noagda \begin{code}
Good : TCtx+ [] → Set
Good Γ = ∀ {k k' : _} {f : _} 
 → (a : (▸ Prin "System" says (a- (Owner · (k , f)))) ∈ Γ) 
 → (b : (▸ Prin "System" says (a- (Owner · (k' , f)))) ∈ Γ) 
 → Equal a b
\end{code}

Then we may prove that the postcondition of each operation is \ttt{Good}
if the precondition is; e.g.
\noagda \begin{code}
ChownPreservesGood : {Γ Δ : _} (k1 k2 : _) (f : _)  
  (pfRep : (Replace (▸ Prin "System" says (a-(Owner · (k1 , f))))
                    (▸ Prin "System" says (a-(Owner · (k2 , f)))) 
                    Γ Δ))
  → Good Γ → Good Δ 
\end{code}
%
In the companion code, we revise the above examples so that they maintain this invariant, 
using a tactic to generate the proofs of goodness.