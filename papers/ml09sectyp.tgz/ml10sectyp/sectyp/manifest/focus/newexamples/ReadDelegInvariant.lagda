\ignore{
\begin{code}

open import lib.Prelude
open List.Subset
open import lib.SumsProds
open List using (_++_)
open Sums using (solve)

open import sectyp.manifest.focus.newexamples.FileSig
open import sectyp.manifest.focus.newexamples.FileIO
open Invariant

open import lib.List

open List.In

module sectyp.manifest.focus.newexamples.ReadDelegInvariant where

 Γpolicy = 
  (▸ Prin "Admin" says
   (∀e principal · ∀e principal · ∀e filename ·
       let owner = ▹ (iS (iS i0))
           reader = ▹ (iS i0)
           file = ▹ i0 in 
    ( (  (▸ Prin "HR"  says  (a- (Employee · reader)))
       ∧ (▸ Prin "System" says (a- (Owner · (owner , file))))
       ∧ (owner says (a- (Mayread · (reader , file)))))
     ⊃ 
      (a- (Mayread · (reader , file))))))  :: 
  (▸ Prin "Admin" says
   (∀e principal ·
    ∀e filename ·
     (▸ Prin "System" says (a- (Owner · (▹ iS i0 , ▹ i0))))
    ⊃ 
     (a- (MayChown · (▹ iS i0 , ▹ i0)))))  :: 
    []

 Γstate = 
     (▸ Prin "System" says 
        (a- (Owner · (▸ Prin "Jamie" , ▸ File "secret·txt")))) 
  :: (▸ Prin "HR" says  (a- (Employee · (▸ Prin "Dan")))) 
  :: (▸ Prin "HR" says  (a- (Employee · (▸ Prin "Jamie")))) 
  :: (▸ Prin "Jamie"  says 
        (a-(Mayread · (▸ Prin "Dan" , ▸ File "secret·txt"))))
  :: (▸ Prin "Jamie"  says  
        (a-(Mayread · (▸ Prin "Jamie" , ▸ File "secret·txt"))))
  :: (▸ Prin "Admin" says 
        (a- (MaySu · (▸ Prin "Dan" , ▸ Prin "Jamie"))))
  :: []

 Γall = Γpolicy ++ Γstate

 module Read where

 jread : ◯ (Γall as "Jamie") String (λ _ → (Γall as "Jamie"))
 jread = read (▸ Prin "Jamie") (▸ File "secret·txt") 
              (solve (prove 17))
 
 jreadprint : ◯ (Γall as "Jamie") Unit (λ _ → (Γall as "Jamie"))
 jreadprint = jread >>= λ x → 
              print ("the secret is: " ^ x)
 mutual

  Γstate' =  replace {_} {Γstate}
    (▸ Prin "System" says  
      (a- (Owner · (▸ Prin "Dan" , ▸ File "secret·txt")))) 
    i0
  
  Γall' = Γpolicy ++ Γstate'
  
  dchown : ◯ (Γall' as "Dan") Unit (λ _ → Γall as "Dan")
  dchown = chown (▸ Prin "Dan") (▸ Prin "Dan") (▸ Prin "Jamie") 
            (▸ File "secret·txt") 
            (solve proveReplace) (solve (prove 15)) 
           >> dreadprint

  dreadprint : ◯ (Γall as "Dan") Unit (λ _ → Γall as "Dan")
  dreadprint = sudo (▸ Prin "Dan" ) (▸ Prin "Jamie") 
               (solve proveReplace) 
               (λ _ → solve proveReplace) 
               (solve (prove 15)) 
               jreadprint 

  main : ◯ [] Unit (λ _ → []) 
  main = acquire (Γall as "Jamie") / (λ _ → solve proveGood)
          no⇒ print "acquiring policy failed"
          yes⇒ weakenPost jreadprint (λ _ ()) (\ _ _ -> solve proveGood)
