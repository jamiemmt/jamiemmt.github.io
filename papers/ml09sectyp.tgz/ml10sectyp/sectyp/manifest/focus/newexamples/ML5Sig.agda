open import lib.Prelude

open import sectyp.manifest.focus.TermSig
import sectyp.manifest.focus.Terms 
import sectyp.manifest.focus.Aprop
open import sectyp.manifest.focus.ApropSig
import sectyp.manifest.focus.Propositions
open import sectyp.manifest.focus.PropSig
import sectyp.manifest.focus.Proofs
import sectyp.manifest.focus.Prover
open import sectyp.manifest.focus.Tracked

module sectyp.manifest.focus.newexamples.ML5Sig where

  data BaseType : Set where
   filename : BaseType 
   principal : BaseType
   world : BaseType

  {- FIXME : CHECK THAT STRINGS ARE IN ALL CONST LIST BELOW-}
  data Const : BaseType -> Set where
    Prin : String -> Const principal
    File : String -> Const filename
    client : Const world
    server : Const world
    
  typeEq : (A : BaseType) -> (B : BaseType) -> (Maybe (Id A B))
  typeEq filename filename = Some Refl
  typeEq world world = Some Refl
  typeEq principal principal = Some Refl
  typeEq _ _ = None
  
  constEq : ∀ {A : BaseType} -> (C : Const A) -> (C' : Const A) -> Maybe (Id C C')
  constEq (Prin p1) (Prin p2) = FailureMonad.map (λ x → Id.substeq Prin x) (String.equal/id p1 p2)
  constEq (File f1) (File f2) = FailureMonad.map (λ x → Id.substeq File x) (String.equal/id f1 f2)
  constEq client client = Some Refl
  constEq server server = Some Refl
  constEq _ _ = None

  allPrins = ( "Admin" :: "Dan" :: "Jamie" :: "HR" :: "System" :: "Public"  :: [] )
  allFile = ("secret·txt" :: "paper25·pdf" :: "paper09·pdf" :: "reviewers·txt" :: "reviewer-assignments·txt" :: [])
  allConst : List String -> {A : BaseType} -> List (Const A)
  allConst extras {principal} = List.map Prin (List.append allPrins extras)
  allConst extras {filename} = List.map File (List.append allFile extras)
  allConst extras {world} = client :: server :: []
  
  TSig : TermSig 
  TSig = trivialFOTerm (record { BaseType = BaseType ; Const = Const ; constEq = constEq; typeEq = typeEq ; allConst = allConst})

  open sectyp.manifest.focus.Terms TSig public

  data AP : Type -> Set where
    Employee : AP (▸ principal) 
    Mayread :  AP ((▸ principal) ⊗ (▸ filename))
    Maywrite : AP ((▸ principal) ⊗ (▸ filename))
    Owner :  AP ((▸ principal) ⊗ (▸ filename))
    MaySu :  AP ((▸ principal) ⊗ (▸ principal))
    MayChown : AP ((▸ principal) ⊗ (▸ filename))
    MayFlow  : AP ((▸ filename) ⊗ (▸ filename))
    As : AP (▸ principal)
    At : AP (▸ world)

  apEq : ∀ {A B} -> (C1 : AP A) -> (C2 : AP B) -> Maybe (Id A B × HId C1 C2) 
  apEq Employee Employee = Some (Refl , HRefl)
  apEq Mayread Mayread = Some (Refl , HRefl)
  apEq Owner Owner = Some (Refl , HRefl)    
  apEq MaySu MaySu = Some (Refl , HRefl)    
  apEq MayChown MayChown = Some (Refl , HRefl)    
  apEq MayFlow MayFlow = Some (Refl , HRefl)    
  apEq Maywrite Maywrite = Some (Refl , HRefl)    
  apEq As As = Some (Refl , HRefl)
  apEq At At = Some (Refl , HRefl)
  apEq _ _ = None

  ASig : ApropSig
  ASig = record { PConst = AP ; pconstEq = apEq}

  data _≥_ {Ω : ICtx} : Term Ω (▸ principal) ->  Term Ω (▸ principal)  -> Set where
    ≥Refl  : ∀ {k} -> k ≥ k
    ≥Trans : ∀ {k1 k2 k3} -> k1 ≥ k2 -> k2 ≥ k3 -> k1 ≥ k3
    DJ : (▸ (Prin "Dan")) ≥ (▸ (Prin "Jamie"))
    Ad : ∀ {j} -> (▸ (Prin "Admin")) ≥ j

  {- fixme : actually decide me -}
  decide≥ : {Ω : ICtx} (k1 k2 : Term Ω (▸ principal)) -> Maybe (k1 ≥ k2) 
  decide≥ (▸ (Prin k1)) (▸ (Prin k2)) with (String.equal/id k1 k2)
  decide≥ (▸ (Prin k1)) (▸ (Prin .k1))  | Some Refl = Some ≥Refl 
  decide≥ (▸ (Prin "Admin")) (▸ (Prin _)) | None = Some Ad 
  decide≥ (▸ (Prin "Dan")) (▸ (Prin "Jamie")) | None = Some DJ 
  decide≥ (▸ (Prin _)) (▸ (Prin _)) | None = None
  decide≥ _ _ = None 

  theSig : PropSig
  theSig = record { ASig = ASig ; principal = principal ; _≥_ = _≥_ ;  decide≥ =  decide≥ }

  open sectyp.manifest.focus.Prover theSig public
  open ProofInt public
  open PropInt public
  open ApropInt public
  -- TermsInt is already open

  pfCtx : (Γ : TCtx+ []) -> Ctx
  pfCtx Γ = join [] Γ [] (▸ Prin "Admin")
  
  Proof :  (TCtx+ []) ->  (Propo- [])  -> Set 
  Proof Γ A = (pfCtx Γ ⊢ A)      

  Proof⁻ :  (TCtx+ []) ->  (Aprop [])  -> Set 
  Proof⁻ Γ p = (pfCtx Γ ⊢ (a- p))      

  Proof⁺ :  (TCtx+ []) ->  (Aprop [])  -> Set 
  Proof⁺ Γ p = (pfCtx Γ ⊢ (↑ (a+ p)))

  _as_ : TCtx+ [] -> String -> TCtx+ [] 
  Γ as s = (a+ (As · ▸ Prin s)) :: Γ

  MayAllFlow : List (Term [] (▸ filename)) -> (Term [] (▸ filename)) -> Propo+ []
  MayAllFlow [] to = ⊤
  MayAllFlow (s :: ss) to = ⇣ (a- (MayFlow · (s , to))) ∧ MayAllFlow ss to

  joinWorlds : Term [] (▸ world) -> Term [] (▸ world) -> Term [] (▸ world)
  joinWorlds (▸ server) (▸ server) = (▸ server)
  joinWorlds _ _ = (▸ client)
