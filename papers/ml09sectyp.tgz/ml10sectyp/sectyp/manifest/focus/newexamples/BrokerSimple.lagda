
\ignore{
\begin{code}
open import lib.Prelude
open List.Subset
open import lib.SumsProds
open List using (_++_)


open import sectyp.manifest.focus.newexamples.BrokerSig


module sectyp.manifest.focus.newexamples.BrokerSimple where
  --open PrincipaledIO
\end{code}}

\begin{code}
  Γpolicy : TCtx+ []  
  Γpolicy = 
      (▸ Prin "UBS"    says  a-(Owns · (▸ Prin "Jamie" , ▸ Com "Monet"))) :: 
      (▸ Prin "UBS"    says  a-(Owns · (▸ Prin "Dan" ,  ▸ Com "Picasso"))) ::
      (▸ Prin "Jamie"  says  a-(WillTrade · (▸ Prin "Jamie" , ▸ Prin "Dan" , ▸ Com "Monet" , ▸ Com "Picasso"))) ::
      (▸ Prin "Dan"    says  a-(WillTrade · (▸ Prin "Dan" , ▸ Prin "Jamie" , ▸ Com "Picasso" , ▸ Com "Monet"))) ::
      (▸ Prin "Admin" says
            (∀e principal · 
             ∀e principal · 
             ∀e commodity · 
             ∀e commodity · 
              let 
                trader1 = ▹ (iS (iS (iS i0)))
                trader2 = ▹ (iS (iS i0))
                com1 = ▹ (iS i0)
                com2 = ▹ i0
              in 
              ((▸ Prin "UBS" says a-(Owns · (trader1 , com1))) ∧
               (▸ Prin "UBS" says a-(Owns · (trader2 , com2))) ∧
               ( trader1  says a-(WillTrade · (trader1 , trader2 , com1 , com2))) ∧
               ( trader2  says a-(WillTrade · (trader2 , trader1 , com2 , com1))))
              ⊃ 
              a-(MayTrade · (trader1 , trader2 , com1 , com2))))      ::
      []

  policy = join [] Γpolicy [] (▸ Prin "Admin")
  goal : Maybe (policy ⊢ a-(MayTrade · (▸ Prin "Jamie" , ▸ Prin "Dan" , ▸ Com "Monet" , ▸ Com "Picasso")))
  goal = proveNeutral 16 _ _

  
{-  trade : ∀ {k k' c c' Γ} -> (Proof Γ (a- (MayTrade (Prin k) (Prin k') c c'))) -> ◯ k Γ [] Unit
  {- do stateful stuff here-}
  trade pf = {!!}-}

{- Some
(linv i0
 (saysL
  (linv (iS i0)
   (saysL
    (linv (iS (iS i0))
     (saysL
      (linv (iS (iS (iS i0)))
       (saysL
        (linv (iS (iS (iS (iS i0))))
         (saysL
          (claimsL i0
           (∀L (Prin Jamie)
            (∀L (Prin Dan)
             (∀L (Com Monet)
              (∀L (Com Picasso)
               (⊃L
                (∧R (saysR (claimsL (iS (iS (iS (iS i0)))) init- ≥Refl))
                 (∧R (saysR (claimsL (iS (iS (iS i0))) init- ≥Refl))
                  (∧R (saysR (claimsL (iS (iS i0)) init- ≥Refl))
                   (saysR (claimsL (iS i0) init- ≥Refl)))))
                init-)))))
           Ad)))))))))))-}


\end{code}
