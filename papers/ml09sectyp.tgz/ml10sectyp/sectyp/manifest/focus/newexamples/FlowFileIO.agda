open import lib.Prelude
open import lib.List
open List.Subset
open List.In
open import sectyp.manifest.focus.PropSig 
import sectyp.manifest.focus.IOsig
import sectyp.manifest.focus.IOfunc
open import sectyp.manifest.focus.Tracked
open import sectyp.manifest.focus.newexamples.FlowFileSig


module sectyp.manifest.focus.newexamples.FlowFileIO  where


  open sectyp.manifest.focus.IOsig theSig

  private 
   module Local where
    module T = TrackedList (Term [] (▸ filename))
    
    Tracked : Set -> T.L -> Set
    Tracked A x = T.Tracked A x

    fmap : ∀ {A B L} -> (A -> B) -> Tracked A L -> Tracked B L
    fmap {A}{B}{L} f = T.fmap{A}{B}{L}  f

    _⊙_ : ∀ {A B L1 L2} -> Tracked (A -> B) L1 -> Tracked A L2 -> Tracked B (T._⊔_ L1 L2)
    _⊙_ {A}{B}{L1}{L2} f x = T._⊙_ {A}{B}{L1}{L2}  f x

    readSig : Command 
    readSig = record {Args = \ g -> Σ \ k -> Σ \ f -> Proof g (↑ (⇣ (a- (Mayread · (k ,  f))) ∧ (a+ (As · k))));
                  Result = λ a → Tracked String [ (fst (snd a)) ];
                  Postcondition = (λ {Γ} → λ a → \ Γ' ->  Id Γ' (\ _ -> Γ));
                  body = \ l -> IO.readFile (fts (fst (snd l)));
                  toReg = \ _ -> \ _ -> []}

    writeSig : Command 
    writeSig = record {Args = \ g  -> Σ \ provs -> Σ \ (str : Tracked String provs)
                              -> Σ \ k -> Σ \ f -> Proof g (↑ (⇣ (a- (Maywrite · (k ,  f))) ∧ (a+ (As · k)) ∧ (MayAllFlow provs f)));
                  Result = \ _ -> Unit ;
                  Postcondition = (λ {Γ} → λ a → \ Γ' ->  Id Γ' (\ _ -> Γ));
                  body = \ l -> IO.return <> ; -- fixme
                  toReg = \ _ -> \ _ -> []}
    
    data commands : Command -> Set where
      r : commands readSig
      w : commands writeSig

  open sectyp.manifest.focus.IOfunc theSig record {commands = Local.commands ; bracketcommands = \ _ -> Void ; Good = \ _ -> Unit } public
  
  abstract
    Tracked = Local.Tracked
    fmap : ∀ {A B L} -> (A -> B) -> Tracked A L -> Tracked B L
    fmap {A}{B}{L} = Local.fmap {A}{B}{L}

    _⊙_ : ∀ {A B L1 L2} -> Tracked (A -> B) L1 -> Tracked A L2 -> Tracked B (Local.T._⊔_ L1 L2)
    _⊙_ {A}{B}{L1}{L2} = Local._⊙_ {A}{B}{L1}{L2}

    read  : ∀ {Γ} (k : _) (file : _)
                  -> Proof Γ (↑ (⇣ (a- (Mayread · (k ,  file))) ∧ (a+ (As · k))))
                  -> ◯ Γ (Tracked String [ file ]) (λ _ → Γ) 
    read k f mayrd  = doCommand Local.readSig Local.r (k , f , mayrd) Refl 
    
    write  : ∀ {Γ provs} (k : _) (file : _)
                  -> Tracked String provs
                  -> Proof Γ (↑ (⇣ (a- (Maywrite · (k ,  file))) ∧ (a+ (As · k)) ∧  (MayAllFlow provs file)))
                  -> ◯ Γ Unit (λ _ → Γ) 
    write k f s pf = doCommand Local.writeSig Local.w (_ , s , k , f , pf) Refl
  