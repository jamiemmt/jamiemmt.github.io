open import lib.Prelude
open import sectyp.manifest.focus.TermSig
import sectyp.manifest.focus.Terms 
import sectyp.manifest.focus.Aprop
open import sectyp.manifest.focus.ApropSig
import sectyp.manifest.focus.Propositions
open import sectyp.manifest.focus.PropSig
import sectyp.manifest.focus.Proofs
import sectyp.manifest.focus.Prover


module sectyp.manifest.focus.newexamples.BrokerSig where

  data BaseType : Set where
   commodity : BaseType 
   principal : BaseType

  {- FIXME : CHECK THAT STRINGS ARE IN ALL CONST LIST BELOW-}
  data Const : BaseType -> Set where
    Prin : String -> Const principal
    Com : String -> Const commodity
  
  typeEq : (A : BaseType) -> (B : BaseType) -> (Maybe (Id A B))
  typeEq commodity commodity = Some Refl
  typeEq principal principal = Some Refl
  typeEq _ _ = None
  
  constEq : ∀ {A : BaseType} -> (C : Const A) -> (C' : Const A) -> Maybe (Id C C')
  constEq (Prin p1) (Prin p2) = FailureMonad.map (λ x → Id.substeq Prin x) (String.equal/id p1 p2)
  constEq (Com f1) (Com f2) = FailureMonad.map (λ x → Id.substeq Com x) (String.equal/id f1 f2)
  
  staticStrings : BaseType -> List String
  staticStrings principal = ( "Admin" :: "Dan" :: "Jamie"  :: "UBS" :: [] )
  staticStrings commodity = ("Monet" :: "Picasso" :: [])

  allConst : List String -> {A : BaseType} -> List (Const A)
  allConst e {principal} = List.map Prin (List.append (staticStrings principal) e)   
  allConst e {commodity} = List.map Com  (List.append (staticStrings commodity) e)
  
  TSig : TermSig 
  TSig = trivialFOTerm (record { BaseType = BaseType ; Const = Const ; constEq = constEq; typeEq = typeEq ; allConst = allConst})

  open sectyp.manifest.focus.Terms TSig 

  data Pconst : Type -> Set where
    Owns :  Pconst ((▸ principal) ⊗ (▸ commodity))
    WillTrade :  Pconst ((▸ principal) ⊗ (▸ principal) ⊗ (▸ commodity) ⊗ (▸ commodity))
    MayTrade :  Pconst ((▸ principal) ⊗ (▸ principal) ⊗ (▸ commodity) ⊗ (▸ commodity))

  pconstEq : ∀ {A B} -> (C1 : Pconst A) -> (C2 : Pconst B) -> Maybe (Id A B × HId C1 C2) 
  pconstEq MayTrade MayTrade = Some (Refl , HRefl)
  pconstEq Owns Owns = Some (Refl , HRefl)
  pconstEq WillTrade WillTrade = Some (Refl , HRefl)    
  pconstEq _ _ = None


  ASig : ApropSig
  ASig = record { PConst = Pconst ; pconstEq = pconstEq}


  data _≥_ {Ω : ICtx} : Term Ω (▸ principal) ->  Term Ω (▸ principal)  -> Set where
    ≥Refl  : ∀ {k} -> k ≥ k
    ≥Trans : ∀ {k1 k2 k3} -> k1 ≥ k2 -> k2 ≥ k3 -> k1 ≥ k3
    DJ : (▸ (Prin "Dan")) ≥ (▸ (Prin "Jamie"))
    Ad : ∀ {j} -> (▸ (Prin "Admin")) ≥ j

  {- fixme : actually decide me -}
  decide≥ : {Ω : ICtx} (k1 k2 : Term Ω (▸ principal)) -> Maybe (k1 ≥ k2) 
  decide≥ (▸ (Prin k1)) (▸ (Prin k2)) with (String.equal/id k1 k2)
  decide≥ (▸ (Prin k1)) (▸ (Prin .k1))  | Some Refl = Some ≥Refl 
  decide≥ (▸ (Prin "Admin")) (▸ (Prin _)) | None = Some Ad 
  decide≥ (▸ (Prin "Dan")) (▸ (Prin "Jamie")) | None = Some DJ 
  decide≥ (▸ (Prin _)) (▸ (Prin _)) | None = None
  decide≥ _ _ = None 

  theSig : PropSig
  theSig = record { ASig = ASig ; principal = principal ; _≥_ = _≥_ ;  decide≥ =  decide≥ }


  open sectyp.manifest.focus.Prover theSig public
  open ProofInt public
  open PropInt public
  open ApropInt public
  open TermsInt public
  
  

