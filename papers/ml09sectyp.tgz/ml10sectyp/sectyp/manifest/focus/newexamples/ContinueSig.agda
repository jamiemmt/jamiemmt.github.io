open import lib.Prelude
open import sectyp.manifest.focus.TermSig
import sectyp.manifest.focus.Terms 
import sectyp.manifest.focus.Types
import sectyp.manifest.focus.Aprop
open import sectyp.manifest.focus.ApropSig
import sectyp.manifest.focus.Propositions
open import sectyp.manifest.focus.PropSig
import sectyp.manifest.focus.Proofs
import sectyp.manifest.focus.Prover


module sectyp.manifest.focus.newexamples.ContinueSig where

  data BaseType : Set where
    string paper role action phase principal : BaseType 

  {- FIXME : CHECK THAT STRINGS ARE IN ALL CONST LIST BELOW-}
  data Const : BaseType -> Set where
    Prin  : String -> Const principal
    Paper : String -> Const paper
    Str   : String -> Const string
    PCChair Reviewer Author Public : Const role
    Init Presubmission Submission Bidding Assignment Reviewing Notification Discussion Done : Const phase

  module Local where
    private
      open sectyp.manifest.focus.Types BaseType
  
    data Func : BaseType -> Type -> Set where
      Submit : Func action     (▸ string) {-- string is name of paper, not yet registered-}
      Review BeAssigned Readscore Read : Func action (▸ paper)
      Progress  : Func action  (▸ phase ⊗ ▸ phase)

    allFuncs : (τ : BaseType) -> List (Σ (\ (A : Type) -> Func τ A))
    allFuncs action = (_ , Submit) :: (_ , Review) :: (_ , BeAssigned) :: (_ , Readscore) :: (_ , Read) :: (_ , Progress) :: []
    allFuncs _ = []

    funcEq : ∀ {τ1 τ2 : BaseType} {A1 A2 : Type}
              -> (C1 : Func τ1 A1) -> (C2 : Func τ2 A2) 
              -> Maybe (Id τ1 τ2 × Id A1 A2 × HId C1 C2)
    funcEq Submit Submit =         Some (Refl , Refl , HRefl)
    funcEq Review Review =         Some (Refl , Refl , HRefl)
    funcEq BeAssigned BeAssigned = Some (Refl , Refl , HRefl)
    funcEq Readscore Readscore =   Some (Refl , Refl , HRefl)
    funcEq Read Read =             Some (Refl , Refl , HRefl)
    funcEq Progress Progress =     Some (Refl , Refl , HRefl) 
    funcEq _ _ = None
  open Local public

  typeEq : (A : BaseType) -> (B : BaseType) -> (Maybe (Id A B))
  typeEq paper paper = Some Refl
  typeEq principal principal = Some Refl
  typeEq phase phase = Some Refl
  typeEq role role = Some Refl
  typeEq action action = Some Refl
  typeEq _ _ = None
  
  constEq : ∀ {A : BaseType} -> (C : Const A) -> (C' : Const A) -> Maybe (Id C C')
  constEq (Prin p1) (Prin p2) = FailureMonad.map (λ x → Id.substeq Prin x) (String.equal/id p1 p2)
  constEq (Paper f1) (Paper f2) = FailureMonad.map (λ x → Id.substeq Paper x) (String.equal/id f1 f2)
  constEq (Str f1) (Str f2) = FailureMonad.map (λ x → Id.substeq Str x) (String.equal/id f1 f2)
  constEq PCChair PCChair = Some Refl
  constEq Author Author = Some Refl
  constEq Public Public = Some Refl
  constEq Reviewer Reviewer = Some Refl
  constEq Init Init = Some Refl
  constEq Presubmission Presubmission  = Some Refl
  constEq Submission Submission  = Some Refl
  constEq Bidding Bidding = Some Refl
  constEq Assignment Assignment  = Some Refl
  constEq Reviewing Reviewing  = Some Refl
  constEq Notification Notification = Some Refl
  constEq Discussion Discussion = Some Refl
  constEq Done Done = Some Refl
  constEq _ _ = None
  
  staticStrings : BaseType -> List String
  staticStrings principal = ( "Admin" :: "Dan" :: "Jamie" :: [] )
  staticStrings paper = ("secret·txt" :: "paper25·pdf" :: "paper09·pdf" :: [])
  staticStrings string = [] -- FIXME
  staticStrings _ = []

  allConst : List String -> ({A : BaseType} -> List (Const A))
  allConst extras {principal} = List.map Prin (List.append extras (staticStrings principal))
  allConst extras {paper} =  List.map Paper (List.append extras (staticStrings paper))
  allConst extras {string} = List.map Str extras
  allConst _ {role} = (PCChair :: Reviewer :: Public :: Author :: [])
  allConst _ {phase} = (Init :: Presubmission  :: Submission  :: Bidding  :: Assignment ::  Reviewing  :: Notification  ::  Discussion :: Done :: [])
  allConst _ {action} = []

  TSig : TermSig 
  TSig = record {flat = record { BaseType = BaseType ; Const = Const ; constEq = constEq; typeEq = typeEq ; allConst = allConst } ;
                 Func = Func;
                 funcEq = funcEq;
                 allFuncs = allFuncs}

  open sectyp.manifest.focus.Terms TSig 

  data Pconst : Type -> Set where
    InRole : Pconst (▸ principal ⊗ ▸ role)
    InPhase : Pconst ( ▸ phase)
    Submitted : Pconst (▸ paper)
    Assigned Reviewed Author : Pconst (▸ principal ⊗ ▸ paper)
    May :  Pconst (▸ principal ⊗ ▸ action)
    MaySu : Pconst (▸ principal ⊗ ▸ principal)
    As : Pconst (▸ principal)
    NextPhase : Pconst (▸ phase ⊗ ▸ phase) 

  pconstEq : ∀ {A B} -> (C1 : Pconst A) -> (C2 : Pconst B) -> Maybe (Id A B × HId C1 C2) 
  pconstEq InRole  InRole = Some (Refl , HRefl)
  pconstEq InPhase InPhase = Some (Refl , HRefl)
  pconstEq Submitted Submitted = Some (Refl , HRefl)
  pconstEq Reviewed Reviewed = Some (Refl , HRefl)    
  pconstEq Assigned Assigned = Some (Refl , HRefl)    
  pconstEq Author Author = Some (Refl , HRefl)    
  pconstEq May May = Some (Refl , HRefl)    
  pconstEq MaySu MaySu = Some (Refl , HRefl)    
  pconstEq As As = Some (Refl , HRefl)  
  pconstEq NextPhase NextPhase = Some (Refl , HRefl)
  pconstEq _ _ = None

  ASig : ApropSig
  ASig = record { PConst = Pconst ; pconstEq = pconstEq}

  data _≥_ {Ω : ICtx} : Term Ω (▸ principal) ->  Term Ω (▸ principal)  -> Set where
    ≥Refl  : ∀ {k} -> k ≥ k
    ≥Trans : ∀ {k1 k2 k3} -> k1 ≥ k2 -> k2 ≥ k3 -> k1 ≥ k3
    DJ : (▸ (Prin "Dan")) ≥ (▸ (Prin "Jamie"))
    PC : ∀ {j} -> (▸ (Prin "PCChair")) ≥ j

  {- fixme : actually decide me -}
  decide≥ : {Ω : ICtx} (k1 k2 : Term Ω (▸ principal)) -> Maybe (k1 ≥ k2) 
  decide≥ (▸ (Prin k1)) (▸ (Prin k2)) with (String.equal/id k1 k2)
  decide≥ (▸ (Prin k1)) (▸ (Prin .k1))  | Some Refl = Some ≥Refl 
  decide≥ (▸ (Prin "PCChair")) (▸ (Prin _)) | None = Some PC
  decide≥ (▸ (Prin "Dan")) (▸ (Prin "Jamie")) | None = Some DJ 
  decide≥ (▸ (Prin _)) (▸ (Prin _)) | None = None
  decide≥ _ _ = None 

  theSig : PropSig
  theSig = record { ASig = ASig ; principal = principal ; _≥_ = _≥_ ;  decide≥ =  decide≥ }

  open sectyp.manifest.focus.Prover theSig public
  open ProofInt public
  open PropInt public
  open ApropInt public
  open TermsInt public

  pfCtx : (Γ : TCtx+ []) -> Ctx
  pfCtx Γ = join [] Γ [] (▸ Prin "PCChair")
  
  Proof :  (TCtx+ []) ->  (Propo- [])  -> Set 
  Proof Γ A = (pfCtx Γ ⊢ A)      

  _as_ : TCtx+ [] -> String -> TCtx+ [] 
  Γ as s = (a+ (As · ▸ Prin s)) :: Γ


{-
  FIXME: goes in NextPhase
  data _⇒_  {Ω}: Term Ω (▸ phase) -> Term Ω (▸ phase) -> Set where
    Init :  (▸ Init)  ⇒  (▸ Presubmission)
    Pre :  (▸ Presubmission)  ⇒ (▸ Submission)
    Sub : (▸ Submission)  ⇒ (▸ Bidding)
    Bid : (▸ Bidding)  ⇒ (▸ Assignment)      
    Asgn : (▸ Assignment) ⇒ (▸ Reviewing)
    Rev : (▸ Reviewing)  ⇒ (▸ Notification)   
    Not : (▸ Notification)  ⇒ (▸ Discussion)   
    Dis : (▸ Discussion) ⇒ (▸ Done)
-}
