open import lib.Prelude
open import lib.List
open List.Subset
open List.In
open import sectyp.manifest.focus.PropSig 
import sectyp.manifest.focus.IOsig
import sectyp.manifest.focus.IOfunc
open import sectyp.manifest.focus.newexamples.ContinueSig

module sectyp.manifest.focus.newexamples.ContinueIO  where

  open sectyp.manifest.focus.IOsig theSig
  open List.Replace propEq public
  
  good : TCtx+ [] -> Set
  good = \ _ -> Unit
  
  ExtraArgs : TCtx+ [] -> Term [] (▸ action) -> Set
  ExtraArgs Γ (Review · _) = Term [] (▸ string)
  ExtraArgs Γ (Submit · _) = Term [] (▸ string)
  ExtraArgs Γ (Progress · (p1 , p2)) = Σ \ Δ -> Replace (⇣ (a- (InPhase ·  p1))) (⇣ (a- (InPhase ·  p2))) Γ Δ
  ExtraArgs Γ _ = Unit


  InputArgs :  Term [] (▸ action) -> Set
  InputArgs  (Review · _) = Term [] (▸ string)
  InputArgs  (Submit · _) = Term [] (▸ string)
  InputArgs  (Progress · (p1 , p2)) = Unit
  InputArgs  _ = Unit

  Result : Term [] (▸ action) -> Set
  Result (Submit · y) = Term [] (▸ paper)
  Result (Review · y) = Unit
  Result (BeAssigned · y) = Unit
  Result (Readscore · y) = String
  Result (Read · y) = String
  Result (Progress · y) = Unit
  Result (▹ ())
  Result (▸ ())

  PostCondition : (a : Term [] (▸ action)) 
                  (Γ : TCtx+ []) -> ExtraArgs Γ a -> (k : Term [] (▸ principal)) -> Result a 
                  -> TCtx+ []
  PostCondition (Submit · y)             Γ e k r    = ⇣ (a- (Submitted · r )) :: ⇣ (a- (Author · (k , r))) :: Γ 
  PostCondition (Review · y)             Γ e k r    = ⇣ (a- (Reviewed · (k , y))) :: Γ 
  PostCondition (BeAssigned · y)         Γ e k r    = ⇣ (a- (Assigned · (k , y))) :: Γ 
  PostCondition (Readscore · y)          Γ e k r    = Γ 
  PostCondition (Read · y)               Γ e k r    = Γ
  PostCondition (Progress · (ph1 , ph2)) Γ e k r    = (fst e)
  PostCondition (▹ ())                   Γ e k r
  PostCondition (▸ ())                   Γ e k r    
  
  stillIn : ∀ {x y z l} -> x ∈ l -> (Id x y -> Void) -> (i : (y ∈ l)) -> (x ∈ replace z i )
  stillIn i0 f i0 = Sums.abort (f Refl)
  stillIn i0 f (iS i) = i0
  stillIn (iS i) f i0  = iS i
  stillIn (iS i) f (iS i') = iS (stillIn i f i')

  postPreservesAs : ∀ {a Γ e k r k' } -> (a+ (As · k') ∈ Γ) -> ((a+ (As · k')) ∈ PostCondition a Γ e k r)
  postPreservesAs {▹()} _
  postPreservesAs {▸ ()} _ 
  postPreservesAs {_·_ Submit y} i = iS (iS i)
  postPreservesAs {_·_ Review y} i = iS i
  postPreservesAs {_·_ BeAssigned y} i = iS i
  postPreservesAs {_·_ Readscore y} i = i
  postPreservesAs {_·_ Read y} i = i
  postPreservesAs {_·_ Progress (p1 , p2)} {e = ._ , rep j Refl} i = stillIn i (λ ()) j

  abstract

    dobody  : ∀ {Γ} -> (k : _) -> (a : _) -> (e : (ExtraArgs Γ a)) -> IO.IO (Result a)
    dobody k (Read · (▸ Paper y)) extras  = (IO._>>=_ (IO.readFile y) (\ k -> IO.return k))
    dobody k (Review · (▸ Paper y)) (▸ Str review)  = 
                  IO._>>=_ (IO.appendFile (String.string-append "review." y) review)
                  (λ _ → IO.return <>)
    dobody k (Submit · (▸ Str name)) (▸ Str contents)  = 
      IO._>>=_ (IO.openTempFile name contents)
        (λ newname → IO.return (▸ Paper newname))
    dobody k (BeAssigned · y) extras = IO.return <>
    dobody k (Readscore · (▸ Paper p)) extras =
      IO._>>=_ (IO.readFile (String.string-append "review" p))
        (λ y → IO.return y) 
    dobody k (Progress · (ph1 , ph2)) extras = IO.return <> 
    dobody k _ _   =  IO.error "Impossible call to dobody"

    doReg :  (a : Term [] (▸ action)) -> (Result a) -> List String
    doReg (Submit · y) (▸ Paper p) = p :: [] 
    doReg _ _ = []

    anySig : Command
    anySig = record
                 {Args = λ g → Σ \ (k : Term [] (▸ principal)) -> Σ λ a → Σ \ (e : ExtraArgs g a) -> Proof g (↑ (⇣ ((a- (May · (k , a)))) ∧  (a+ (As · k)))) ;
                  Result = λ a → Result (fst (snd a)); 
                  Postcondition = (λ {Γ} a → \ Γ' ->  Id Γ' (PostCondition (fst (snd a)) Γ (fst (snd (snd a))) (fst a)));
                  body = \ {Γ} a -> 
                           let
                               k = (fst a)
                               act = (fst (snd a))
                               extra = (fst (snd (snd a)))
                               pf = (snd (snd (snd a)))
                           in
                             dobody k act extra ;
                  toReg = \ a -> (λ r → doReg (fst (snd a)) r) }

    sudoSig :   BracketCommand
    sudoSig  =  record {Args = (λ g → Σ \ k1 -> Σ \ k2 -> Proof g (a- (MaySu · (k1 , k2)))) ;
                   relPre = (λ {Γ} a → λ Δ → Replace (a+ (As · fst a)) (a+ (As · fst (snd a))) Γ Δ) ; 
                   Result = λ a → λ y → y ; 
                   relPost = λ a → λ Δ' → λ Γ' → ((x : _) -> Replace (a+ (As · fst (snd a))) (a+ (As · fst a)) (Δ' x) (Γ' x)) ; 
                   before = (\ _ -> IO.return <>) ;
                   after = λ r' → λ a → IO.return a}

    data commands : Command -> Set where
      do : commands anySig
    
    data bracketcommands : BracketCommand -> Set where
      su : bracketcommands sudoSig

    open sectyp.manifest.focus.IOfunc theSig record {commands = commands ; bracketcommands = bracketcommands ; Good = good} public

    doaction : ∀ {Γ} (k : _) (a : _) -> (e : ExtraArgs Γ a)
              -> Proof Γ (↑ (⇣ ((a- (May · (k , a)))) ∧  (a+ (As · k))))
              -> ◯ Γ (Result a) (\ r -> PostCondition a Γ e k r)
    doaction k a e pf = doCommand anySig do (k , a , e , pf) Refl 
 
    sudo : ∀ { Γ A Γ' Δ Δ'} -> (k1 k2 : _) -> Replace (a+ (As · k1)) (a+ (As · k2)) Γ Δ ->
           ((x : A) -> Replace  (a+ (As · k2)) (a+ (As · k1)) (Δ' x) (Γ' x)) ->
           (Proof Γ (a- (MaySu · (k1 ,  k2)))) ->
           ◯  Δ A Δ' ->
           ◯ Γ A Γ'
    sudo k1 k2 reppf post may comp = doBracketCmd sudoSig su (k1 , k2 , may) reppf post comp   

