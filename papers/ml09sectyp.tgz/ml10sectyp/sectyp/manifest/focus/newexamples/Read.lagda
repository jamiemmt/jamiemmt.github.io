\begin{figure}[h]
\label{readctx}

\ignore{
\begin{code}

open import lib.Prelude
open List.Subset
open import lib.SumsProds
open List using (_++_)
open Sums using (solve)

open import sectyp.manifest.focus.newexamples.FileSig
open import sectyp.manifest.focus.newexamples.FileIO
open Uninvariant

open import lib.List
open List.In


module sectyp.manifest.focus.newexamples.Read where

  Γpolicy : TCtx+ []
  Γpolicy = (▸ Prin "Admin" says
                    (∀e principal ·
                     ∀e filename ·
                       ((▸ Prin "HR"  says  (a- (Employee · (▹ iS i0))))
                         ∧ 
                        (▸ Prin "System" says (a- (Owner · (▹ iS i0 , ▹ i0))))
                      ⊃ 
                       (a- (Mayread · (▹ iS i0 , ▹ i0))))))  :: 
            (▸ Prin "Admin" says
                    (∀e principal ·
                     ∀e filename ·
                      (▸ Prin "System" says (a- (Owner · (▹ iS i0 , ▹ i0))))
                     ⊃ 
                      (a- (MayChown · (▹ iS i0 , ▹ i0)))))  :: []
  Γstate = (▸ Prin "HR" says  (a- (Employee · (▸ Prin "Jamie"))))
         :: (▸ Prin "System" says  (a- (Owner · (▸ Prin "Jamie" , ▸ File "secret·txt"))))
         :: (▸ Prin "Admin" says (a- (MaySu · (▸ Prin "Dan" , ▸ Prin "Jamie"))))
         :: []

  Γoverall = Γpolicy ++ Γstate

  module DemoProver where
    goal = a-(Mayread · (▸ Prin "Jamie" , ▸ File "secret·txt"))
  
    proof? : Maybe (pfCtx (Γoverall as "Jamie") ⊢ goal)
    proof?  = prove 15 
  
    theProof : pfCtx (Γoverall as "Jamie") ⊢ goal
    theProof = solve proof?


  module Read where
    jread : ◯ (Γoverall as "Jamie") String (\ _ -> (Γoverall as "Jamie"))
    jread = read (▸ Prin "Jamie") (▸ File "secret·txt") (solve (prove 15 ))
  
    jreadprint : ◯ (Γoverall as "Jamie") Unit (\ _ -> (Γoverall as "Jamie"))
    jreadprint = jread >>= (\ x -> print (String.string-append "the secret is: " x))
  
    dreadprint : ◯ (Γoverall as "Dan") Unit (\ _ -> Γoverall as "Dan")
    dreadprint = sudo (▸ Prin "Dan" ) (▸ Prin "Jamie") 
                 (solve proveReplace) 
                 (λ _ → solve proveReplace) 
                 (solve (prove 15)) 
                 jreadprint 
  
    main : ◯ [] Unit (\ _ -> [])
    main = acquire (Γoverall as "Jamie") _
           (weakenPost jreadprint (\ _ ()) _)
           (print "acquiring policy failed") 

  module ChOwn where
    open Read

    Γstate' =  (▸ Prin "HR" says  (a- (Employee · (▸ Prin "Jamie"))))
            :: (▸ Prin "System" says  (a- (Owner · (▸ Prin "Dan" , ▸ File "secret·txt"))))
            :: (▸ Prin "Admin" says (a- (MaySu · (▸ Prin "Dan" , ▸ Prin "Jamie"))))
            :: []
  
    Γoverall' = Γpolicy ++ Γstate'
    
    dchown : ◯ (Γoverall' as "Dan") Unit (\ _ -> Γoverall as "Dan")
    dchown = chown (▸ Prin "Dan") (▸ Prin "Dan") (▸ Prin "Jamie") (▸ File "secret·txt") 
             (solve proveReplace)
             (solve (prove 15)) >> dreadprint

    {- but if we didn't chown, it would fail:
    cant : pfCtx (Γoverall' as "Dan") ⊢ goal
    cant = solve (prove 15)
    -}

\end{code}
\end{figure}