open import lib.Prelude
open List.Subset
open import lib.SumsProds
open List using (_++_)
open Sums using (solve)

open import sectyp.manifest.focus.newexamples.FlowFileSig
open import sectyp.manifest.focus.newexamples.FlowFileIO

open import lib.List

open List.In

module sectyp.manifest.focus.newexamples.FlowReadWrite where

  Γpolicy : TCtx+ []
  Γpolicy = (▸ Prin "Admin" says
                    (∀e principal ·
                     ∀e filename ·
                       ((▸ Prin "HR"  says  (a- (Employee · (▹ iS i0))))
                         ∧ 
                        (▸ Prin "System" says (a- (Owner · (▹ iS i0 , ▹ i0))))
                      ⊃ 
                       (↑ (⇣ (a- (Mayread · (▹ iS i0 , ▹ i0))) ∧ ⇣ (a- (Maywrite · (▹ iS i0 , ▹ i0))))))))  :: 
            (▸ Prin "Admin" says
                    (∀e principal ·
                     ∀e filename ·
                      (▸ Prin "System" says (a- (Owner · (▹ iS i0 , ▹ i0))))
                     ⊃ 
                      (a- (MayChown · (▹ iS i0 , ▹ i0)))))  :: 
            (⇣ (a- (MayFlow · (▸ File "reviewers·txt" , ▸ File "secret·txt")))) ::
            (⇣ (a- (MayFlow · (▸ File "reviewer-assignments·txt" , ▸ File "secret·txt")))) ::
            []
  Γstate = (▸ Prin "HR" says  (a- (Employee · (▸ Prin "Jamie"))))
         :: (▸ Prin "System" says  (a- (Owner · (▸ Prin "Jamie" , ▸ File "secret·txt"))))
         :: (▸ Prin "System" says  (a- (Owner · (▸ Prin "Jamie" , ▸ File "reviewer-assignments·txt"))))
         :: (▸ Prin "System" says  (a- (Owner · (▸ Prin "Jamie" , ▸ File "reviewers·txt"))))
         :: (▸ Prin "Admin" says (a- (MaySu · (▸ Prin "Dan" , ▸ Prin "Jamie"))))
         :: []

  Γoverall = Γpolicy ++ Γstate

  go : ◯ (Γoverall as "Jamie") Unit (\ _ -> (Γoverall as "Jamie"))
  go =  read (▸ Prin "Jamie") (▸ File "reviewers·txt") (solve (prove 15 )) >>=
        \ s ->  write (▸ Prin "Jamie") (▸ File "secret·txt") s (solve (prove 15))


  go' :  ◯ (Γoverall as "Jamie") Unit (\ _ -> (Γoverall as "Jamie"))
  go' =  read (▸ Prin "Jamie") (▸ File "reviewers·txt") (solve (prove 15 )) >>= \ s ->
         read (▸ Prin "Jamie") (▸ File "reviewer-assignments·txt") (solve (prove 15)) >>= \ s' ->
           write (▸ Prin "Jamie") (▸ File "secret·txt") ((fmap String.string-append s) ⊙ s') (solve (prove 15)) 

