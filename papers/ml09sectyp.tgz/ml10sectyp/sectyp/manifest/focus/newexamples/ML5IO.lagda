\ignore{
\begin{code}
open import lib.Prelude
open import lib.List
open List.Subset
open List.In

open import sectyp.manifest.focus.PropSig 
import sectyp.manifest.focus.IOsig
import sectyp.manifest.focus.IOfunc
open import sectyp.manifest.focus.Tracked
open import sectyp.manifest.focus.newexamples.ML5Sig


module sectyp.manifest.focus.newexamples.ML5IO  where

 open List.Replace propEq
 open sectyp.manifest.focus.IOsig theSig

 private
  module T = TrackedFunc (Term [] (▸ world)) joinWorlds
  
 abstract

  Tracked : Set → T.L → Set
  Tracked A x = T.Tracked A x

  fmap : ∀ {A B L} → (A → B) → Tracked A L → Tracked B L
  fmap {A}{B}{L} f = T.fmap{A}{B}{L}  f

  _⊙_ : ∀ {A B L1 L2} → Tracked (A → B) L1 → Tracked A L2 → Tracked B (T._⊔_ L1 L2)
  _⊙_ {A}{B}{L1}{L2} f x = T._⊙_ {A}{B}{L1}{L2}  f x


  postulate 
    HTML : Set
    Lit : String → HTML

  getSig : BracketCommand
  getSig = record {Args = (λ g →  Term [] (▸ world) × Term [] (▸ world));
                   relPre = (λ {Γ} a → λ Δ → Replace  (a+ (At · fst a))  (a+ (At · (snd a))) Γ Δ) ; 
                   Result = λ a → λ y → y ; 
                   relPost = λ a → λ Δ' → λ Γ' → ((x : _) → Replace (a+ (At · (snd a))) (a+ (At · fst a)) (Δ' x) (Γ' x)) ; 
                   before = (\ _ → IO.return <>) ; -- fixme do something
                   after = λ r' → λ a → IO.return a}

  data bracketcommands : BracketCommand → Set where
    g : bracketcommands getSig



  open sectyp.manifest.focus.IOfunc theSig record {commands = \ _ → Void ; bracketcommands = bracketcommands ; Good = \ _ → Unit}
\end{code}}

\subsection{Spatial Distribution with Information Flow}

Next, we show how to account for spatial distribution as in
ML5~\citep{murphy08thesis}, which tracks where resources and
computations are located using modal types of the form \ttt{A @ w}.  For
example, \ttt{database.read : (key → value) @ server} says that a
function that reads from the database must be run at the server, while
\ttt{javascript.alert : (string → unit) @ client} says that a
computation that pops up a browser alert box must be run at the client.
Network communication is expressed in ML5 using an operation \ttt{get : (unit → A) @ w → A @ w'} that
(under some conditions which we elide here) goes to \ttt{w} to run the
given computation and brings the resulting value back to \ttt{w'}.  In
other work~\citep{lh10agda5}, we have shown how to build an ML5-like
type system on type of an indexed monad of computations at a place,
\ttt{◯ w A}, with a rule \ttt{get : ◯ w' A → ◯ w A}.  

Here, observe that this monad indexing can be presented using a
proposition \ttt{At(w)}, where \ttt{get} is given a type analogous to
\ttt{sudo}:

\begin{code}
  get : (w1 w2 : _) → ∀ {Γ A Γ' Δ Δ'} 
       → Replace (a+ (At · w1)) (a+ (At · w2)) Γ Δ 
       → Replace (a+ (At · w2)) (a+ (At · w1)) Δ' Γ'
       → ◯ Δ A (\ _ → Δ')
       → ◯ Γ (Tracked A w2) (\ _ → Γ')
\end{code}
%
Additionally, we combine spatial distribution with information flow,
tagging the return value of the computation with the world it is from.
Note that the postcondition must be independent of the return value, as
there is in general no coercion either way between \ttt{A} and
\ttt{Tracked A L}.

Information flow can be used in this setting to force strings to be
escaped before they are sent back to the client---e.g. to prevent SQL
injection attacks:
\ignore{
\begin{code}
  get w1 w2 rep1 rep2 c = doBracketCmd getSig g (w1 , w2 ) rep1 (λ _ → rep2) c
\end{code}}
\begin{code}
  sanitize : Tracked String (▸ client) → HTML
\end{code}
\ignore{
\begin{code}
  sanitize s = Lit s 
\end{code}}
\begin{code}
  str : Tracked String (▸ server) → HTML
\end{code}
\ignore{
\begin{code}
  str s = Lit s
\end{code}}
Strings from the client must be escaped before they can be included in
an HTML document, whereas strings from the server are assumed to be
non-malicious, and can be included directly.

Instead of (or in addition to) using information flow for \ttt{get}, we
could use the logic to restrict \ttt{get}, so that e.g. only certain
values may flow from one world to another.