open import lib.Prelude
open import lib.List
open List.Subset
open List.In.AtMostOne
open import sectyp.manifest.focus.PropSig 
import sectyp.manifest.focus.IOsig
import sectyp.manifest.focus.IOfunc
open import sectyp.manifest.focus.newexamples.FileSig

module sectyp.manifest.focus.newexamples.FileIO  where

  open sectyp.manifest.focus.IOsig theSig
  open List.Replace propEq public

  readSig : Command 
  readSig = record {Args = \ g -> Σ \ k -> Σ \ f -> Proof g (↑ (⇣ (a- (Mayread · (k ,  f))) ∧ (a+ (As · k))));
                Result = λ _ → String;
                Postcondition = (λ {Γ} → λ a → \ Γ' ->  Id Γ' (\ _ -> Γ));
                body = \ l -> IO.readFile (fts (fst (snd l)));
                toReg = \ _ -> \ _ -> []}
  
  chownSig :  Command
  chownSig = record
          {Args = λ g →
                      Σ \ k →
                        Σ \  (k1 : (Term [] (▸ principal))) → Σ (λ (k2 : (Term [] (▸ principal))) →
                          Σ λ f → Proof g (↑ ((a+ (As · k)) ∧ (⇣ (a- (MayChown · (k , f)))))));
          Result = \ a ->  Unit;
          Postcondition = λ {Γ} a → λ Γ' → 
            let
              k = (fst a)
              k1 = (fst (snd a))
              k2 = (fst (snd (snd a)))
              f = (fst (snd (snd (snd a))))
            in
              Σ (λ Δ → 
                Replace (▸ Prin "System" says (a-(Owner · (k1 , f))))
                        (▸ Prin "System" says (a-(Owner · (k2 , f))))  Γ Δ × Id Γ' (\ _ -> Δ)) ;
          body = λ a → IO._>>=_ (IO.chown (fts (fst (snd (snd (snd a))))) (pts (fst (snd (snd a)))))  
                                \ _ -> IO.return <> ; 
          toReg = (\ _ -> \ _ -> [])}


  createSig :  Command
  createSig = record
          {Args = λ g → (Term [] (▸ principal));
           Result = \ a ->  String;
           Postcondition = λ {Γ} a →
                               λ Γ' →
                                 Id Γ'
                                 (λ s → (▸ Prin "System" says a- (Owner · (a , ▸ File s))) :: Γ) ;
           body = λ a →
                     IO._>>=_ (IO.openTempFile "newfile" "")
                     (λ newname → IO.return newname) ;
           toReg = (\ a -> \ newfile ->  newfile :: []) }



  sudoSig :   BracketCommand
  sudoSig  =  record {Args = (λ g → Σ \ k1 -> Σ \ k2 -> Proof g (a- (MaySu · (k1 , k2)))) ;
                 relPre = (λ {Γ} a → λ Δ → Replace (a+ (As · fst a)) (a+ (As · fst (snd a))) Γ Δ) ; 
                 Result = λ a → λ y → y ; 
                 relPost = λ a → λ Δ' → λ Γ' → ((x : _) -> Replace (a+ (As · fst (snd a))) (a+ (As · fst a)) (Δ' x) (Γ' x)) ; 
                 before = (\ _ -> IO.return <>) ;
                 after = λ r' → λ a → IO.return a}

  data commands : Command -> Set where
    c : commands createSig
    r : commands readSig
    ch : commands chownSig
    
  data bracketcommands : BracketCommand -> Set where
    su : bracketcommands sudoSig
    
  module Invariant where
  
    goodPred : (Term [] (▸ filename)) -> (Propo+ []) -> Set
    goodPred f a =  Σ \ k -> Id a (▸ Prin "System" says (a- (Owner · (k , f))))
  
    goodPred/dec :  (f : Term [] (▸ filename)) -> Not.Decidable1 (goodPred f)
    goodPred/dec f (▸ Prin "System" says (a- (Owner · (k , f')))) with termEq f f'
    goodPred/dec f (▸ Prin "System" says (a- (Owner · (k , .f)))) | Some Refl = Inl (_ , Refl)
    ... | None = Inr FIXMEcertfail where
      postulate FIXMEcertfail : _
    goodPred/dec f _ = Inr FIXMEnegpatterns where
      postulate FIXMEnegpatterns : _
  
    good : TCtx+ [] -> Set
    good Γ =  (f : _) -> AtMostOne Γ (goodPred f)
  
    module ProveGood where
      propPred : (Γ : TCtx+ []) -> (p : Propo+ []) -> Set
      propPred Γ (▸ Prin "System" says (a- (Owner · (k , f)))) = AtMostOne Γ (goodPred f)
      propPred Γ p = Unit
    
      provePropPred : (Γ : TCtx+ []) -> (p : Propo+ []) -> Maybe (propPred Γ p)
      provePropPred Γ (▸ Prin "System" says (a- (Owner · (k , f)))) = proveAtMostOne Γ (goodPred f) (goodPred/dec f)
      provePropPred Γ  _ = Some (pleaseImplementNegationPatterns) where
        postulate pleaseImplementNegationPatterns : _
    
      proveAll : (Γ : TCtx+ []) -> (Maybe (Everywhere (propPred Γ) Γ)) 
      proveAll Γ  = List.EW.joinEW (List.EW.fromall (λ {x} _ → provePropPred Γ x))
    
      coerce : ∀ {Γ} -> (Everywhere (propPred Γ) Γ) -> (good Γ)
      coerce ew f a b (k , Refl) pb = List.EW.there ew a a b (k , Refl) pb
  
      proveGood : ∀ {Γ} -> Maybe (good Γ)
      proveGood {Γ} = Sums.mapMaybe coerce (proveAll Γ)
  
    open ProveGood public using (proveGood) 

    open sectyp.manifest.focus.IOfunc theSig record {commands = commands ; bracketcommands = bracketcommands ; Good = good} public
    
    create : ∀ {Γ} (k : _) -> ◯ Γ String (λ newfile -> (▸ Prin "System" says (a-(Owner · (k , ▸ File newfile)))) :: Γ)
    create k  = doCommand createSig c k Refl
  
    read : ∀ {Γ} (k : _) (file : _)
                -> Proof Γ (↑ (⇣ (a- (Mayread · (k ,  file))) ∧ (a+ (As · k))))
                -> ◯ Γ String (λ _ → Γ) 
    read k f pf = doCommand readSig r (k , f , pf) Refl
    
    chown : ∀ { Γ Δ} -> (k k1 k2 : _) -> (f : _) 
          -> Replace (▸ Prin "System" says (a-(Owner · (k1 , f))))
                   (▸ Prin "System" says (a-(Owner · (k2 , f))))
                   Γ Δ 
        -> (Proof Γ (↑ ((a+ (As · k)) ∧ (⇣ (a- (MayChown · (k , f)))))))
        -> ◯ Γ Unit (\ _ -> Δ) 
    chown k k1 k2 f reppf asmay = doCommand chownSig ch (k , k1 , k2 , f , asmay) (_ , reppf , Refl)
    
    sudo : ∀ { Γ A Γ' Δ Δ'} -> (k1 k2 : _) -> Replace (a+ (As · k1)) (a+ (As · k2)) Γ Δ ->
           ((x : A) -> Replace  (a+ (As · k2)) (a+ (As · k1)) (Δ' x) (Γ' x)) ->
           (Proof Γ (a- (MaySu · (k1 ,  k2)))) ->
           ◯  Δ A Δ' ->
           ◯ Γ A Γ'
    sudo k1 k2 reppf post may comp = doBracketCmd sudoSig su (k1 , k2 , may) reppf post comp
  
    -- FIXME don't hardcode the 20
    read/prove : ∀ {Γ} (k : Term [] (▸ principal)) (file : (Term [] (▸ filename)))
             -> ◯ Γ (Maybe String) (\ _ -> Γ)
    read/prove {Γ} k file = prove/dyn 20 (pfCtx Γ) (↑ (⇣ (a- (Mayread · (k ,  file))) ∧ (a+ (As · k)))) >>= docase where
      docase : Maybe _ -> _
      docase (Some p1) = read _ _ p1 >>= \ s -> (return (Some s)) 
      docase _ = return None
  
  
    sudo/id : ∀ {Γ A Δ} -> (k1 k2 : _) ->  Replace (a+ (As · k1)) (a+ (As · k2)) Γ Δ ->
              (Proof Γ (a- (MaySu · (k1 ,  k2)))) ->
              ◯ Δ A (\ _ -> Δ) ->
              ◯ Γ A (\ _ -> Γ)
    sudo/id k1 k2 reppf p comp = sudo k1 k2 reppf (\ _ -> replace-sym reppf) p comp

    ChownPreservesGood : {Γ Δ : _} (k1 k2 : _) (f : _)  
      (pfRep : (Replace (▸ Prin "System" says (a-(Owner · (k1 , f))))
                        (▸ Prin "System" says (a-(Owner · (k2 , f)))) Γ Δ))
                         → (good Γ) →  good Δ 
    ChownPreservesGood  k1 k2 frep reppf goodpf fcheck = replaceAtMostOne {goodPred fcheck} reppf  lem (goodpf fcheck) where
      lem : goodPred fcheck  (▸ Prin "System" says (a-(Owner · (k2 , frep)))) -> 
              goodPred fcheck (▸ Prin "System" says (a-(Owner · (k1 , frep)))) 
      lem  (k2' , id) with frep | id
      lem (.k2 , _ ) | .fcheck | Refl = k1 , Refl

  module Uninvariant where

    open sectyp.manifest.focus.IOfunc theSig record {commands = commands ; bracketcommands = bracketcommands ; Good = \ _ -> Unit} public
  
    
    create : ∀ {Γ} (k : _) -> ◯ Γ String (λ newfile -> (▸ Prin "System" says (a-(Owner · (k , ▸ File newfile)))) :: Γ)
    create k  = doCommand createSig c k Refl
  
    read : ∀ {Γ} (k : _) (file : _)
                -> Proof Γ (↑ (⇣ (a- (Mayread · (k ,  file))) ∧ (a+ (As · k))))
                -> ◯ Γ String (λ _ → Γ) 
    read k f pf = doCommand readSig r (k , f , pf) Refl
    
    chown : ∀ { Γ Δ} -> (k k1 k2 : _) -> (f : _) 
          -> Replace (▸ Prin "System" says (a-(Owner · (k1 , f))))
                   (▸ Prin "System" says (a-(Owner · (k2 , f))))
                   Γ Δ 
        -> (Proof Γ (↑ ((a+ (As · k)) ∧ (⇣ (a- (MayChown · (k , f)))))))
        -> ◯ Γ Unit (\ _ -> Δ) 
    chown k k1 k2 f reppf asmay = doCommand chownSig ch (k , k1 , k2 , f , asmay) (_ , reppf , Refl)
    
    sudo : ∀ { Γ A Γ' Δ Δ'} -> (k1 k2 : _) -> Replace (a+ (As · k1)) (a+ (As · k2)) Γ Δ ->
           ((x : A) -> Replace  (a+ (As · k2)) (a+ (As · k1)) (Δ' x) (Γ' x)) ->
           (Proof Γ (a- (MaySu · (k1 ,  k2)))) ->
           ◯  Δ A Δ' ->
           ◯ Γ A Γ'
    sudo k1 k2 reppf post may comp = doBracketCmd sudoSig su (k1 , k2 , may) reppf post comp
    
    -- FIXME don't hardcode the 20
    read/prove : ∀ {Γ} (k : Term [] (▸ principal)) (file : (Term [] (▸ filename)))
             -> ◯ Γ (Maybe String) (\ _ -> Γ)
    read/prove {Γ} k file = prove/dyn 20 (pfCtx Γ) (↑ (⇣ (a- (Mayread · (k ,  file))) ∧ (a+ (As · k)))) >>= docase where
      docase : Maybe _ -> _
      docase (Some p1) = read _ _ p1 >>= \ s -> (return (Some s)) 
      docase _ = return None
  
  
    sudo/id : ∀ {Γ A Δ} -> (k1 k2 : _) ->  Replace (a+ (As · k1)) (a+ (As · k2)) Γ Δ ->
              (Proof Γ (a- (MaySu · (k1 ,  k2)))) ->
              ◯ Δ A (\ _ -> Δ) ->
              ◯ Γ A (\ _ -> Γ)
    sudo/id k1 k2 reppf p comp = sudo k1 k2 reppf (\ _ -> replace-sym reppf) p comp 
