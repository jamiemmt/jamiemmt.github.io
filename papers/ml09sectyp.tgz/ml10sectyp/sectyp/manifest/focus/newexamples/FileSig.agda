open import lib.Prelude
open import sectyp.manifest.focus.TermSig
import sectyp.manifest.focus.Terms 
import sectyp.manifest.focus.Aprop
open import sectyp.manifest.focus.ApropSig
import sectyp.manifest.focus.Propositions
open import sectyp.manifest.focus.PropSig
import sectyp.manifest.focus.Proofs
import sectyp.manifest.focus.Prover


module sectyp.manifest.focus.newexamples.FileSig where

  data BaseType : Set where
   filename : BaseType 
   principal : BaseType

  {- FIXME : CHECK THAT STRINGS ARE IN ALL CONST LIST BELOW-}
  data Const : BaseType -> Set where
    Prin : String -> Const principal
    File : String -> Const filename
  
  typeEq : (A : BaseType) -> (B : BaseType) -> (Maybe (Id A B))
  typeEq filename filename = Some Refl
  typeEq principal principal = Some Refl
  typeEq _ _ = None
  
  constEq : ∀ {A : BaseType} -> (C : Const A) -> (C' : Const A) -> Maybe (Id C C')
  constEq (Prin p1) (Prin p2) = FailureMonad.map (λ x → Id.substeq Prin x) (String.equal/id p1 p2)
  constEq (File f1) (File f2) = FailureMonad.map (λ x → Id.substeq File x) (String.equal/id f1 f2)
  
  staticStrings : BaseType -> List String
  staticStrings principal = ( "Admin" :: "Dan" :: "Jamie" :: "HR" :: "System" :: "Public"  :: "PCChair" :: [] )
  staticStrings filename = ("secret·txt" :: "paper25·pdf" :: "paper09·pdf" :: "reviewers·txt" :: "reviewer-assignments·txt" :: [])

  allConst : List String -> ({A : BaseType} -> List (Const A))
  allConst extras {principal} = List.map Prin (List.append extras (staticStrings principal))
  allConst extras {filename} = List.map File (List.append extras (staticStrings filename))
  
  TSig : TermSig 
  TSig = trivialFOTerm (record { BaseType = BaseType ; Const = Const ; constEq = constEq; typeEq = typeEq ; allConst = allConst})

  open sectyp.manifest.focus.Terms TSig 

  data Pconst : Type -> Set where
    Employee : Pconst (▸ principal) 
    Mayread :  Pconst ((▸ principal) ⊗ (▸ filename))
    Owner :  Pconst ((▸ principal) ⊗ (▸ filename))
    MaySu :  Pconst ((▸ principal) ⊗ (▸ principal))
    MayChown :  Pconst ((▸ principal) ⊗ (▸ filename))
    As : Pconst (▸ principal)

  pconstEq : ∀ {A B} -> (C1 : Pconst A) -> (C2 : Pconst B) -> Maybe (Id A B × HId C1 C2) 
  pconstEq Employee Employee = Some (Refl , HRefl)
  pconstEq Mayread Mayread = Some (Refl , HRefl)
  pconstEq Owner Owner = Some (Refl , HRefl)    
  pconstEq MaySu MaySu = Some (Refl , HRefl)    
  pconstEq MayChown MayChown = Some (Refl , HRefl)    
  pconstEq As As = Some (Refl , HRefl)
  pconstEq _ _ = None
 
  fts : Term [] (▸ filename) -> String
  fts (▸ File f) = f
  fts (▹ () ) 
  fts (() · _)

  pts : Term [] (▸ principal) -> String
  pts (▸ Prin p) = p
  pts (▹ () ) 
  pts (() · _)


  ASig : ApropSig
  ASig = record { PConst = Pconst ; pconstEq = pconstEq}

  data _≥_ {Ω : ICtx} : Term Ω (▸ principal) ->  Term Ω (▸ principal)  -> Set where
    ≥Refl  : ∀ {k} -> k ≥ k
    ≥Trans : ∀ {k1 k2 k3} -> k1 ≥ k2 -> k2 ≥ k3 -> k1 ≥ k3
    DJ : (▸ (Prin "Dan")) ≥ (▸ (Prin "Jamie"))
    Ad : ∀ {j} -> (▸ (Prin "Admin")) ≥ j

  {- fixme : actually decide me -}
  decide≥ : {Ω : ICtx} (k1 k2 : Term Ω (▸ principal)) -> Maybe (k1 ≥ k2) 
  decide≥ (▸ (Prin k1)) (▸ (Prin k2)) with (String.equal/id k1 k2)
  decide≥ (▸ (Prin k1)) (▸ (Prin .k1))  | Some Refl = Some ≥Refl 
  decide≥ (▸ (Prin "Admin")) (▸ (Prin _)) | None = Some Ad 
  decide≥ (▸ (Prin "Dan")) (▸ (Prin "Jamie")) | None = Some DJ 
  decide≥ (▸ (Prin _)) (▸ (Prin _)) | None = None
  decide≥ _ _ = None 

  theSig : PropSig
  theSig = record { ASig = ASig ; principal = principal ; _≥_ = _≥_ ;  decide≥ =  decide≥ }

  open sectyp.manifest.focus.Prover theSig public
  open ProofInt public
  open PropInt public
  open ApropInt public
  open TermsInt public

  pfCtx : (Γ : TCtx+ []) -> Ctx
  pfCtx Γ = join [] Γ [] (▸ Prin "Admin")
  
  Proof :  (TCtx+ []) ->  (Propo- [])  -> Set 
  Proof Γ A = (pfCtx Γ ⊢ A)      

  _as_ : TCtx+ [] -> String -> TCtx+ [] 
  Γ as s = (a+ (As · ▸ Prin s)) :: Γ

 