\ignore{
\begin{code}
open import lib.Prelude
open import lib.List
open List.Subset
open List.In
open List using (_++_)
open Sums using (solve)
open import sectyp.manifest.focus.newexamples.ContinueSig
open import sectyp.manifest.focus.newexamples.ContinueIO

module sectyp.manifest.focus.newexamples.ContinuePolicy where
\end{code}}

\begin{code}
Γpolicy : TCtx+ []
Γpolicy = 
  (⇣ (∀e principal · ∀e string ·
       let 
         author = ▹ iS i0
         paper = ▹ i0
       in
        ((⇣ (a- (InPhase · (▸ Submission))) ∧
          (⇣ (a- ( InRole · (author  , ▸ Author)))))
         ⊃ (a- (May · (author , (Submit · paper))))))) :: 
  (⇣ (∀e principal · ∀e paper ·
     let
       reviewer = ▹ (iS i0)
       paper = ▹ i0
     in
      ((⇣ (a- (InPhase · (▸ Reviewing))) ∧
        (⇣ (a- (Assigned · (reviewer , paper)))))
       ⊃ 
       (a- (May · (reviewer , (Review · paper) )))))) :: []
\end{code}
The first proposition reads: for all authors and paper names, if the
conference is in the submission phase, and the principal is an author,
then the principal may submit a paper. The second proposition reads: for
all reviewers and papers, if the conference is in the reviewing phase
and the principal is assigned to review a paper, then they may review
the paper.

\ignore{
\begin{code}
Γsays1 : TCtx+ []
Γsays1 =
 (⇣ (∀e principal · ∀e paper ·
        let
          author = ▹ iS i0
          paper = ▹ i0
        in
        ((⇣ (a- (InPhase · (▸ Notification)))) ∧
        (⇣ (a- (Author · (author , paper ))))) ⊃ 
          (a- (May · ( author , (Readscore · (paper
          ))))))) :: []
\end{code}}

We have also begun to reformulate the policy using the \ttt{says} modality.
For example, we may describe a policy which allows
authors to share their paper scores with their coauthors:

\begin{code}
Γsays : TCtx+ []
Γsays = 
 (⇣ (∀e principal · ∀e paper · ∀e principal · 
   let
     primary = ▹ i0
     paper = ▹ (iS i0)
     coauthor = ▹ (iS (iS i0))
   in
   (( (⇣ (a- (InPhase · (▸ Notification)))) ∧
      (⇣ (a- (Author · (primary , paper) ))) ∧ 
      (primary says (a- (May · (coauthor , 
                                (Readscore · paper))))))
    ⊃ (a- (May · (coauthor , (Readscore · paper))))))) :: []
\end{code}
%
This rule states that, for any principal \ttt{author}, paper
\ttt{paper}, and principal \ttt{coathor}, if the conference is in
notification phase, and \ttt{author} is the author of \ttt{paper}, and
\ttt{author} says \ttt{coauthor} may read the scores for \ttt{paper},
then \ttt{coauthor} may read the scores for \ttt{paper}. Similarly,
using \ttt{says}, it is straightforward to specify a policy allowing PC
members to delegate reviewing assignments to subreviewers.