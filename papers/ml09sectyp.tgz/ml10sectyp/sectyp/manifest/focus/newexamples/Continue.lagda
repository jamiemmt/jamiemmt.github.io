
\ignore{
\begin{code}
open import lib.Prelude
open import lib.List
open List.Subset
open List.In
open List using (_++_)
open Sums using (solve)

open import sectyp.manifest.focus.newexamples.ContinueSig
open import sectyp.manifest.focus.newexamples.ContinueIO

module sectyp.manifest.focus.newexamples.Continue where


 open Sums using (case_None⇒_Some⇒ ; none⇒_some⇒)


 {-step : (Γ : TCtx+ []) → (a : _) → (k : _) → (e : ExtraArgs Γ a)
             → ◯ Γ Unit (λ _ → PostCondition a Γ e k _) 
 step Γ a k e = (prove/dyn 15 Γ _) >>= 
        none⇒ error "Failed to prove you can do this action"
        some⇒ (λ pfCan → doaction k a e pfCan ) -}

 parsePhase : String → Maybe  (Term [] (▸ phase))
 parsePhase "Init" = Some (▸ Init)
 parsePhase "Presubmission" = Some (▸ Presubmission)
 parsePhase "Submission" = Some (▸ Submission)
 parsePhase "Bidding" = Some (▸ Bidding)
 parsePhase "Assignement" = Some (▸ Assignment)
 parsePhase "Reviewing" = Some (▸ Reviewing)
 parsePhase "Notification" = Some (▸ Notification)
 parsePhase "Discussion" = Some (▸ Discussion)
 parsePhase "Done" = Some (▸ Done)
 parsePhase _ = None

{- parseAction : String → Maybe (Σ λ (a : Term [] (▸ action)) → ((InputArgs a ) × (Term [] (▸ principal))))
 parseAction s = answer where
   lines = String.split s (Char.equal '\n')
   pairs = List.map (λ s → String.split s (Char.equal ' ')) lines
   processPair : List _ → Maybe  (Σ λ (a : Term [] (▸ action)) →  ((InputArgs a ) × (Term [] (▸ principal))))
   processPair ("Read" :: pap :: pr :: []) = Some ((Read · (▸ Paper pap)) , <> , ▸ Prin pr ) 
   processPair ("Readscore" :: pap :: pr :: []) = Some ((Readscore · (▸ Paper pap)) , <> , ▸ Prin pr)
 {- pap is the name of the paper -}
   processPair ("Submit" ::  pap :: contents :: pr :: []) = Some ((Submit · (▸ Str pap)) , ▸ Str contents , ▸ Prin pr)
   processPair ("Assign" :: pap :: pr :: []) = Some ((BeAssigned · (▸ Paper pap)) , <> , ▸ Prin pr)
   processPair ("Review" :: pap :: review :: pr ::  []) = Some ((Review · (▸ Paper pap) ) , ▸ Str review , ▸ Prin pr)
   processPair ("Progress" :: p1 :: p2 :: pr :: []) with parsePhase p1 | parsePhase p2
   ... | Some ph1 | Some ph2 = Some ((Progress · (ph1 , ph2)) ,  <> ,  (▸ Prin pr))
   ... | _ | _ = None {- if we tried to progress to something or from something that wasn't a phase -}
   processPair _ = None
   stuff : List _
   stuff = List.filtermap processPair pairs
   reduce : List _ → _
   reduce (x :: []) = Some x
   reduce _ = None
   answer = reduce stuff
   -}

 inputToE : (a : (Term [] (▸ action))) → (Γ : TCtx+ []) → InputArgs a → Maybe (ExtraArgs Γ a)
 inputToE (Read · a)  Γ _ = Some <>
 inputToE (Submit · a) Γ s = Some s
 inputToE (Review · a) Γ s = Some s
 inputToE (BeAssigned · a) Γ _ = Some <>
 inputToE (Readscore · a) Γ  _ = Some <>
 inputToE (Progress · (p1 , p2)) Γ  _ = make-replace 
 inputToE (▹()) _ _ 
 inputToE (▸()) _ _ 

 unrep : ∀ {x y l1 l2} → Replace x y l1 l2 → Σ λ (i : x ∈ l1) → Id (replace y i) l2
 unrep (rep i p) = (i , p )

--  case_rep⇒ : ∀ {x y l1 l2} {C : Set} → Replace x y l1 l2 → ( (i : x ∈ l1) → Id (replace y i) l2 → C) → C
--  case_rep⇒ (rep i p) f = f i p

 postulate
   parseAction : String → Maybe (Σ λ (a : Term [] (▸ action)) → (InputArgs a))

 parsePrin : String → (Term [] (▸ principal))
 parsePrin s = (▸ Prin s)

 repAsPost : ∀ {k1 k2 Γ Δ} → Replace (a+ (As · k1)) (a+ (As · k2)) Γ Δ
               → ∀ {a e} 
               → ((x : Result a) → (Σ λ Γ' 
                      → Replace (a+ (As · k2)) (a+ (As · k1)) ((PostCondition a Δ e k2) x) Γ'))
 repAsPost {k1}{k2}{Γ}{Δ} (rep repI repEq){a}{e} x = 
   replace (a+ (As · k1)) (postPreservesAs {a}{Δ}{e}{k2}{x}{k2} (Id.subst (λ l → (a+ (As · k2)) ∈ l) repEq (∈replace repI))) ,
    rep (postPreservesAs {a}{Δ}{e}{k2}{x}{k2} (Id.subst (λ l → (a+ (As · k2)) ∈ l) repEq (∈replace repI))) Refl 
\end{code}}

\subsubsection{Server Main Loop}

%% FIXME could enforce that you're always running as admin
\begin{figure}
\begin{code} 
 main : ∀ {Γ} → ◯ Γ Unit (λ _ → [])
 main  = fix loop where
  loop : (∀ {Γ} → ◯ Γ Unit (λ _ → [])) → 
         (∀ {Γ} → ◯ Γ Unit (λ _ → []))
  loop rec {Γ} = 
{-1-} prompt "Enter an action:" >>= λ astr →
       case (parseAction astr) 
        None⇒ error "Unknown action"
        Some⇒ λ actionArgs → 
         let a = (fst actionArgs) 
             args = (snd actionArgs) in
{-2-}     prompt "Who are you?" >>= λ ustring → 
           let u = parsePrin ustring in
{-3-}       acquire [ (⇣ (a- (MaySu · (▸ Prin "Admin" , u)))) ] / _
             no⇒ error "Unable to su"
{-4-}        yes⇒ case make-replace
              None⇒ error "oops, not running as admin" 
              Some⇒ λ asadmin →
{-5-}          case (inputToE a _ args)
                None⇒ error "Bad input (e.g. not in phase)"
                Some⇒ λ args →
{-6-}            (sudo (▸ Prin "Admin") u  
                       (snd asadmin)
                       (\x → (snd (repAsPost (snd asadmin) {a} x)))
                       (lfoc i0 init-)
{-7-}                  (prove/dyn 15 _ _ >>= 
                         none⇒ error "Unauthorized action"
                         some⇒ λ canDoAction →
{-8-}                     doaction u a args canDoAction) )
{-9-}            >>= λ _ → rec 

\end{code}
\caption{Continue Main Loop}
\label{fig:continue}
\end{figure}
%

In Figure~\ref{fig:continue} we show the code for the main loop of the
Continue server, implemented using the interface described above.
The main loop serves request made by a principal who wishes to perform
an action. Our proof-carrying interface ensures that this code adheres
to the authorization policy described above: the action will only be
executed if the principal is authorized to do so.  The loop works by (1)
reading in an action and its arguments, (2) reading in a principal, (3)
acquiring the credentials to su as that principal, (4) computing the
precondition of the su, (5) computing the postconditions of performing
the action, (6) su-ing as the principal, (7) proving the principal may
perform the action, (8) performing the action, and (9) recurring.  The
fact that we have coalesced all of the actions into one primitive
command makes this code much more concise than it would be otherwise,
when we would have to repeat essentially this code as many times as
there are actions.

This code is rendered in Agda as follows.  First, \ttt{main} is given
the type \ttt{ ∀ \{Γ\} → ◯ Γ Unit (λ \_ → [])}: given any precondition,
the computation returns Unit and an empty postcondition (we do not
expect to run any code following \ttt{main} so it is not worthwhile to
track the postconditions). \ttt{main} is defined by taking the fixed
point of the axillary function \ttt{loop}, which is abstracted over the
recursive call. On line (1), the loop \ttt{prompt}s the user to enter an
action to perform, \ttt{parseAction} then parses the string to produce
\ttt{a : action} and \ttt{args: InputArgs}, and raises an error
otherwise.  (2) The loop prompts for a username, parses it into a
\ttt{Term [] principal}. (3) The loop attempts to acquire credentials that
\ttt{"Admin"} may su as the principal (e.g., by prompting for a password).
(4) The loop calls the functions \ttt{make-replace} to produce the
preconditions for the \ttt{su}, by replacing \ttt{ (As (Prin "Admin"))}
with \ttt{(a+ (As u)}.  (5) The loop calls \ttt{inputToE} to produce the
\ttt{ExtraArgs} for the action from the \ttt{args}; for
\ttt{Progress}, this function computes the postcondition of the action
from the current context. (6) The loop su-s as the principal. The first
\ttt{replace} argument to \ttt{su} is the result of step (4), the proof
argument is the assumption acquired in step (3), the second
\ttt{replace} argument is discussed below.  (7) The loop calls the
theorem prover at run-time to prove the principal may perform the
requested action. (8) The loop calls \ttt{doaction} and (9) recurs.

The second \ttt{replace} argument to \ttt{su} is generated using a proof 
that \ttt{As} is preserved in the \ttt{PostCondition} of an action:
\noagda \begin{code}
postPreservesAs : ∀ {a Γ e k r k' } 
                -> (a+ (As · k') ∈ Γ)
                -> ((a+ (As · k')) ∈ PostCondition a Γ e k r)
\end{code}
This is another example of using Agda to verify invariants of the pre-
and post-conditions, as in Section~\ref{sec:file-invariants}.

\subsubsection{Dynamic Policy Acquisition}

Here we describe an example of dynamic policy acquisition: we read the
reviewers' paper assignments from a database, parse the result into a
context, acquire the context, and start the main server loop with those
preconditions (see Figure ~\ref{fig:dynamicPolicy}).  This is simple in
a dependently typed language because \emph{contexts themselves are
data}.  The function \ttt{getReviewerAsgn} takes a string, representing
a path to the database, and returns the list of list of reviewers for
each paper. The function \ttt{parseReviewers} then turns each of these
lists into lists of propositions, each stating the parsed reviewer is a
reviewer of the paper.  The actual Continue implementation would read a
variety of other propositions from the database as well (which papers
have been submitted, reviewed, etc.)  The computation \ttt{mkPolicy}
calls \ttt{getReviewerAsgn} and parses the results. The computation
\ttt{start} uses \ttt{mkPolicy} to generate an initial policy, acquires
these preconditions, and starts the main sever loop.

\begin{figure}
\ignore{
\begin{code}
  postulate
\end{code}}
\begin{code}
   getReviewerAsgn : ∀ {Γ} → String → 
     ◯ Γ (List (List String)) (λ _ → Γ)

  parseReviewers : List String → TCtx+ []
\end{code}
\ignore{
\begin{code}
  parseReviewers  (pname :: reviewers) =  List.map 
    (λ r → (▸ Prin "PCChair" says 
      a-(Assigned · (▸ Prin r , ▸ Paper pname )))) reviewers 
  parseReviewers [] = []
\end{code}}
\begin{code}
  mkPolicy : ∀ {Γ} → ◯ Γ (TCtx+ []) (λ _ → Γ)
  mkPolicy =  getReviewerAsgn "papers.db" >>= λ asgn →
    return (List.fold [] (λ x → λ y → 
                      parseReviewers x ++ y) asgn)

  start = mkPolicy {[]} >>= λ ctx → 
          acquire ctx / _
            no⇒ error "policy not accepted" 
            yes⇒ main
\end{code}
\caption{Continue Policy Acquistion}
\label{fig:dynamicPolicy}
\end{figure}
