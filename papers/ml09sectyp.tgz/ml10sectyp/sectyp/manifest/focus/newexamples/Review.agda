open import lib.Prelude
open List.Subset
open import lib.SumsProds
open List using (_++_)
open Sums using (solve)
open List.In

open import sectyp.manifest.focus.newexamples.FileSig
open import sectyp.manifest.focus.newexamples.FileIO
open Uninvariant

module sectyp.manifest.focus.newexamples.Review where

    Γpolicy : TCtx+ []
    Γpolicy = 
         (▸ Prin "System"  says  a- (Owner · (▸ Prin "PCChair" , ▸ File "reviewers·txt")))
      :: (▸ Prin "System"  says  a-(Owner · (▸ Prin "PCChair" , ▸ File "reviewer-assignments·txt")))
      :: (▸ Prin "Admin"   says
                      (∀e principal · 
                       ∀e principal · 
                       ∀e filename · 
                         let owner = ▹ (iS (iS i0))
                             reader = ▹ (iS i0)
                             file   = ▹ i0
                          in
                         ((▸ Prin "System" says  (a-(Owner · (owner , file)))) ∧ 
                          (owner  says  (a-(Mayread · (reader , file)))))
                         ⊃ 
                         a-(Mayread · (reader , file))))
      :: (▸ Prin "PCChair" says (∀e principal · a-(Mayread · (▹ i0 , ▸ File "reviewers·txt"))))
      :: []

    parseReviewerPolicy : String -> TCtx+ []
    parseReviewerPolicy s = List.map (\ r -> (▸ Prin "PCChair" says a-(Mayread · (▸ Prin r , ▸ File "reviewer-assignments·txt")))) revLines where
      revLines = String.split s (Char.equal '\n')

    parsePaperPolicy : String -> TCtx+ []
    parsePaperPolicy s = List.filtermap processPair pairs where
        lines = String.split s (Char.equal '\n')
        pairs = List.map (\ s -> String.split s (Char.equal ' ')) lines

        processPair : List String -> _
        processPair (p :: rv :: []) = Some ((▸ Prin "PCChair" says a-(Mayread · (▸ Prin rv , ▸ File p))) ∧ 
                                           (▸ Prin "System"  says a-(Owner · (▸ Prin "PCChair" , ▸ File p))))
        processPair _ = None

    open Sums using (case_None⇒_Some⇒)
    
    case_Some⇒ : ∀ {A Γ C Γ'} -> (Maybe A) -> (A -> ◯ Γ C Γ') -> ◯ Γ C Γ'
    case None Some⇒ e2 = (error "case on None")
    case (Some x) Some⇒ e2 = e2 x

    main : ◯ [] Unit (\ _ -> [])
    main = acquire (Γpolicy as "Public") / _
     no⇒  error "The initial policy was rejected"
     yes⇒ read (▸ Prin "Public") (▸ File "reviewers·txt") (solve (prove 16)) >>= \ reviewerList -> 
      acquire (parseReviewerPolicy reviewerList) / _
       no⇒  error "The reviewer policy failed to parse\n"
       yes⇒ prompt "What is the reviewer's name? :" >>= \ reviewer -> 
        prompt "Which paper would you like to review? : " >>= \ paper -> 
         acquire [ ▸ Prin "Admin" says a-(MaySu · (▸ Prin "Public" , ▸ Prin reviewer)) ] / _
            no⇒ error "Bad Password for reviewer"
            yes⇒ wknPost (\ _ ()) _
                 (sudo/id (▸ Prin "Public") (▸ Prin reviewer) 
                       (rep (iS (skip (parseReviewerPolicy reviewerList) i0)) Refl)
                       (linv i0 (saysL (claimsL i0 init- ≥Refl)))
                  ((read/prove (▸ Prin reviewer) (▸ File "reviewer-assignments·txt")) >>= \ maybeAssigns -> case maybeAssigns
                   None⇒ error "Policy does not allow this principal to read the reviewer assignments"
                   Some⇒ \ paperPolicy -> 
                    acquire (parsePaperPolicy paperPolicy) / _
                     no⇒ error "The paper policy in the database was rejected" 
                     yes⇒ (read/prove (▸ Prin "reviewer") (▸ File paper)) >>= \ maybePaperContents ->
                       case maybePaperContents
                         None⇒ error "Reviewer is not authorized to access that paper, according to the reviewer database."
                         Some⇒ (\ contents ->  wknPre (skip (parsePaperPolicy paperPolicy)) _ (printLn contents) )))


{-
  -- old example commented
    main' : ◯ Public [] [] Unit
    main' = 
     -- (1) acquire the initial policy
     acquire Γpolicy 
      -- (2) read the list of reviewers from a file
      yes⇒ read reviewers·txt ( (Sums.getSome (proveNeutral 16 _ _)) ) >>= \ reviewerList -> 
       -- (3) acquire the policy for reading the paper assignments
       acquire (parseReviewerPolicy reviewerList) 
        -- (4) read and parse the reviewer and paper
        yes⇒ prompt "What is the reviewer's name? :" >>= \ r -> 
         case (parseReviewer r) Some⇒ \ reviewer -> 
          prompt "Which paper would you like to review? : " >>= \ p -> 
           case (parsePaper p)  Some⇒ \ paper ->
            -- (5) acquire the credentials to su as the reviewer
            acquire [ Prin Admin says a-(MaySu (Prin Public) (Prin reviewer)) ] 
             -- (6) su as the reviewer to
             yes⇒ sudo{reviewer} (linv i0 (saysL (claimsL i0 init- ≥Refl)))
               --(7) read the paper assignments
              (case (read/prove{reviewer}{_} reviewer-assignments·txt) Some⇒ \ rdString -> 
               rdString >>= \ paperPolicy -> 
                -- (8) acquire the policies for accessing papers
                acquire (parsePaperPolicy paperPolicy) 
                 -- (9) prove that the reviewer can access the paper 
                 yes⇒ case (read/prove paper) 
                  -- (10) print the paper
                  Some⇒ (\ contents -> contents >>= \s -> wknP (\ ()) $ printLn s))
-}