open import lib.Prelude
open import sectyp.manifest.focus.Terms
import sectyp.manifest.focus.Proofs
open import sectyp.manifest.focus.PropSig

module sectyp.manifest.focus.IOsig (r : PropSig) where

  module ProofInt = sectyp.manifest.focus.Proofs r
  open ProofInt
  open PropInt
  open PropInt.PropSigInt
  open PropInt.ApropInt
  open PropInt.ApropInt.ApropSigInt
  open PropInt.ApropInt.TermsInt
  open PropInt.ApropInt.TermsInt.TermSigInt

  record Command  : Set1 where
    field
      Args : TCtx+ [] -> Set
      Result : ∀ {Γ} -> (Args Γ) -> Set
      Postcondition : ∀ {Γ} -> (a : Args Γ) -> (Result a -> TCtx+ []) -> Set
      body : ∀ {Γ} -> (a : Args Γ) -> IO.IO (Result a)
      toReg : ∀ {Γ} -> (a : Args Γ) -> (Result a) -> List String

  record BracketCommand : Set1 where
    field
      Args : TCtx+ [] -> Set
      relPre : ∀ {Γ} -> (a : Args Γ) -> TCtx+ [] -> Set
      Result : ∀ {Γ} -> (Args Γ) -> Set -> Set
      relPost : ∀ {Γ A} -> (a : Args Γ) -> (A -> TCtx+ []) -> (Result a A -> TCtx+ []) -> Set
      before : ∀ {Γ} -> (a : Args Γ) -> IO.IO Unit
      after : ∀ {Γ A } -> (a : Args Γ) -> A -> IO.IO (Result a  A) 


  record IOsig : Set1 where
    field
      commands : Command -> Set
      bracketcommands : BracketCommand -> Set
      Good : TCtx+ [] -> Set
      



     
    
    
    
    


