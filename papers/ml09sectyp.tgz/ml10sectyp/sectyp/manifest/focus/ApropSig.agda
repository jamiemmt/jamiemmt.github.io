open import lib.Prelude
open import sectyp.manifest.focus.TermSig
import sectyp.manifest.focus.Terms

module sectyp.manifest.focus.ApropSig where

   record ApropSig :  Set1 where
     field 
       TSig : TermSig
     module T = sectyp.manifest.focus.Terms TSig 
     field
       PConst : T.Type  -> Set
       pconstEq : ∀ {A B} -> (C1 : PConst A) -> (C2 : PConst B) -> Maybe (Id A B × HId C1 C2)

       