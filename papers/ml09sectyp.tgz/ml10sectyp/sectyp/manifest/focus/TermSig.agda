open import lib.Prelude
import sectyp.manifest.focus.Types 

module sectyp.manifest.focus.TermSig where

   record FlatTermSig : Set1 where
     field 
       BaseType : Set
       Const : BaseType -> Set

       typeEq : (A B : BaseType) -> Maybe (Id A B)
       constEq : ∀ {A : BaseType} -> (C : Const A) -> (C' : Const A) -> Maybe (Id C C')

       -- extra strings are added as extra strings for every type
       -- whose constants are made of strings
       allConst : (extraStrings : List String) -> {A : BaseType} -> List (Const A)


   record TermSig : Set1 where
     field
       flat : FlatTermSig

     module Typ = sectyp.manifest.focus.Types (FlatTermSig.BaseType flat)

     field
       {- FIXME: signature must be non-recursive;
                  should check this here -}
       Func : (FlatTermSig.BaseType flat) -> Typ.Type -> Set
       allFuncs : (τ : FlatTermSig.BaseType flat) -> List (Σ (\ (A : Typ.Type) -> Func τ A))
       funcEq : ∀ {τ1 τ2 : FlatTermSig.BaseType flat} {A1 A2 : Typ.Type}
              -> (C1 : Func τ1 A1) -> (C2 : Func τ2 A2) 
              -> Maybe (Id τ1 τ2 × Id A1 A2 × HId C1 C2)

   trivialFOTerm : FlatTermSig -> TermSig 
   trivialFOTerm r = record {flat = r ; 
                             Func = \ _ _ -> Void ; 
                             allFuncs = \ _ -> [] ;
                             funcEq = \ _ _ -> None}