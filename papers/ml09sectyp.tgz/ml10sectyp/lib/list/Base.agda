
open import lib.SumsProds
open Sums
open Prods
open import lib.Nat
open Nat
open import lib.NatThms
open NatThms
open import lib.Id
open Id 
open import lib.Functions

module lib.list.Base where
  module ListOP where

    data List (a : Set) : Set where
      []  : List a
      _::_ : a -> List a -> List a 

    {-# COMPILED_DATA List [] [] (:) #-}
    {-# BUILTIN LIST List #-}
    {-# BUILTIN NIL [] #-}
    {-# BUILTIN CONS _::_ #-}

    infixr 99 _::_
    
    [_] : {A : Set} -> A -> List A
    [_] x  = x :: []

    -- we expand this out, rather than using (Somewhere (\x -> Id x a) l)
    -- so that we don't have to write the silly identity proof in the deBruijn index 
    data _∈_ {A : Set} : A -> List A -> Set where
      i0 : {x : A}   {xs : List A} -> x ∈ (x :: xs )
      iS : {x y : A} {xs : List A} -> y ∈ xs -> y ∈ (x :: xs)
    infix 10 _∈_

    data Everywhere {A : Set} (P : A -> Set) : List A -> Set where
      E[] : Everywhere P []
      _E::_ : forall {x xs} -> P x -> Everywhere P xs -> Everywhere P (x :: xs) 

    infixr 98 _E::_

  open ListOP public

  Lists : Set -> Set
  Lists A = List (List A)

-- FIXME: organize the theorems

  append : forall {a} -> List a -> List a -> List a
  append [] l2 = l2
  append (x :: xs) l2 = x :: (append xs l2)

  invert-append-nil : {A : Set} {l1 l2 : List A} -> Id (append l1 l2) [] -> Id l1 [] × Id l2 []
  invert-append-nil {A} {[]} id = Refl , id
  invert-append-nil {A} {x :: xs} ()

  appendmayber : forall {a} -> List a -> List a -> List a
  appendmayber l1 [] = l1
  appendmayber l1 (x :: xs) = append l1 (x :: xs)
  
  append-rh-[] : {A : Set} -> (l : List A) -> Id (append l []) l
  append-rh-[] [] = Refl
  append-rh-[] (h :: tl) with (append tl []) | append-rh-[] tl 
  ...                       | .tl            | Refl = Refl

  appendmayber-is-append : {A : Set} -> (l1 l2 : List A) -> Id (appendmayber l1 l2) (append l1 l2)
  appendmayber-is-append _ [] = Id.sym (append-rh-[] _)
  appendmayber-is-append _ (x :: xs) = Refl

  _++_ : {a : Set} -> List a -> List a -> List a
  _++_ = append
  infixr 20 _++_

  -- also see append-rh-[]
  append-unit : {A : Set} (l1 : List A){l2 : List A} -> Id (l1 ++ []) l2 -> Id l1 l2
  append-unit [] Refl = Refl
  append-unit (x :: l1) Refl with append l1 [] | append-unit l1 Refl
  ... | ._ | Refl = Refl
 
  append-assoc : {A : Set} {l1 l2 l3 : List A} -> Id ((l1 ++ l2) ++ l3) (l1 ++ (l2 ++ l3))
  append-assoc {_}{[]} {l2} {l3} = Refl
  append-assoc {_}{x1 :: l1} {l2} {l3} = Id.substeq (\xs -> x1 :: xs) (append-assoc {_} {l1} {l2} {l3})

  fold : {a b : Set} -> b -> (a -> b -> b) -> List a -> b
  fold n c [] = n
  fold n c (x :: xs) = c x (fold n c xs)

  concat : {A : Set} -> List (List A) -> List A
  concat = fold [] append

  map : {a b : Set} -> (a -> b) -> List a -> List b
  map f [] = []
  map f (x :: xs) = f x :: (map f xs)

  mapid : {A : Set} (l : List A) -> Id (map (\x -> x) l) l
  mapid [] = Refl
  mapid (x :: xs) with (map (\x -> x) xs) | mapid xs
  ...                | .xs                | Refl = Refl

  append-maps : {A B : Set} (l1 l2 : List A) {f : A -> B} -> Id ((map f l1) ++ (map f l2)) (map f (append l1 l2))
  append-maps []        l2 = Refl
  append-maps (x :: l1) l2 {f} = Id.substeq (\ l -> f x :: l)  (append-maps l1 l2)

  fuse-map : ∀ {A B C} {f : A -> B} {g : B -> C} (l : List A) -> Id (map g (map f l)) (map (\ x -> g (f x)) l) 
  fuse-map [] = Refl
  fuse-map {f = f} {g = g} (x :: xs) = Id.substeq (\ xs -> (g (f x)) :: xs) (fuse-map xs)

  map-ext : ∀ {A B} {f g : A -> B} -> ((x : A) -> Id (f x) (g x)) -> (l : List A) -> Id (map f l) (map g l)
  map-ext id [] = Refl
  map-ext id (x :: xs) = Id.substeq2 _::_ (id x) (map-ext id xs)
  
  map-compose : ∀ {A B B' C} {f : A -> B} {g : B -> C} {f' : A -> B'} {g' : B' -> C} {l : List A}
              -> ((x : A) -> Id (g (f x)) (g' (f' x))) 
              -> Id (map g (map f l)) (map g' (map f' l))
  map-compose {l = l} id = Id.trans (fuse-map l) (Id.trans (map-ext id l) (Id.sym (fuse-map l)))

  fold-map : ∀ {A B C} {f : A -> B} {n : C} {c : B -> C -> C} 
           -> (l : List A)
           -> Id (fold n c (map f l)) (fold n (\ hd r -> c (f hd) r) l)
  fold-map [] = Refl
  fold-map{f = f}{c = c} (x :: xs) = Id.substeq (\ tl -> c (f x) tl) (fold-map xs)
  
  length : forall {a} -> List a -> Nat.Nat
  length []       = Nat.Z
  length (x :: xs) = S (length xs)

  exists : {a : Set} -> (a -> Bool) -> List a -> Bool
  exists f [] = False
  exists f (x :: xs) with f x 
  ...                   | True  = True
  ...                   | False = exists f xs

  all : {a : Set} -> (a -> Bool) -> List a -> Bool
  all f [] = True
  all f (x :: xs) = (f x) andalso (all f xs)
  
  find : {a : Set} -> (a -> Bool) -> List a -> Maybe a
  find f [] = None
  find f (x :: xs) with f x 
  ...                   | True  = Some x
  ...                   | False = find f xs
  
  -- formerly appendRest
  appendNew : {a : Set}  -> ((x : a) -> (y : a) -> (Maybe (Id x y))) -> List a -> List a -> List a
  appendNew f l1 [] = l1
  appendNew f l1 (x :: xs)  with (find (Sums.forgetMaybe2 f x) l1)
  ...                          | Some k = appendNew f l1 xs
  ...                          | None = appendNew f (x :: l1) xs
    
  _+-_ : {a : Set} -> ((x : a) -> (y : a) -> (Maybe (Id x y ))) ->  List a -> List a -> List a
  _+-_ = appendNew
  infixr 20 _+-_

  findMod : {a : Set} {b : Set} -> (a -> Maybe b) -> List a -> Maybe b
  findMod f [] = None
  findMod f (x :: xs) = join1 (f x) (findMod f xs)
  
  nth : {a : Set} (n : Nat) -> (l : List a) -> Lt n (length l) -> a
  nth _ [] ()
  nth Z (x :: xs) _             = x
  nth (S n) (_ :: xs) (Lt/ss l) = nth n xs l

  filter : {a : Set} -> (f : a -> Bool) -> List a -> List a
  filter f [] = []
  filter f (x :: xs) with (f x)
  ...                   | True  = x :: (filter f xs)
  ...                   | False = filter f xs

  -- nonsense lemma for in-filter
  fire-filter : {a : Set} -> (x x' : a) -> (xs : List a) -> (f : a -> Bool) 
                -> x ∈ (filter f (x' :: xs)) -> Id True (f x') -> x ∈ x' :: (filter f xs)
  fire-filter x x' xs f i p with (f x')
  ...                          | True = i
  fire-filter _ _ _ _ _ ()   | False 

  in-filter : {a : Set} -> (x : a) -> (l : List a) -> (f : a -> Bool) -> (x ∈ filter f l) ->  ((x ∈ l) × (Id (f x) True))
  in-filter x [] f ()
  in-filter x (x' :: xs) f i with inspect (f x')
  ...                           | False with-eq p with (f x')
  in-filter x (x' :: xs) f i    | False with-eq ()   | True 
  ...                                                | False = iS (fst (in-filter x xs f i)) , snd (in-filter x xs f i)
  in-filter x (x' :: xs) f i    | True with-eq p with fire-filter _ _ _ _ i p
  in-filter x (.x :: xs) f i    | True with-eq p    | i0 = i0 , sym p 
  ...                                               | (iS i') = iS (fst (in-filter x xs f i')) , snd (in-filter x xs f i') 

  filterp : {a b : Set} -> (f : a -> Maybe b) -> List a -> List a
  filterp {a} f l =  filter f' l where
    f' : a -> Bool
    f' x with f x
    ... | Some _ = True
    ... | None = False

  filtermap : {a b : Set} -> (f : a -> Maybe b) -> List a -> List b
  filtermap f [] = []
  filtermap f (x :: xs) with (f x)
  ...                   | Some x'  = x' :: (filtermap f xs)
  ...                   | None = filtermap f xs

  unzip : {A B : Set} -> List (A × B) -> List A × List B
  unzip [] = [] , []
  unzip ((x , y) :: l) with unzip l
  ...                     | (xs , ys) = x :: xs , y :: ys

  reverse : {A : Set} -> List A -> List A
  reverse l = reverse' l [] where
    reverse' : {A : Set} -> List A -> List A -> List A
    reverse' [] l = l
    reverse' (x :: xs) ys = reverse' xs (x :: ys)

  listeq-semidec : ∀ {A} -> (Eq : ((x y : A ) -> Maybe (Id x y)))
                 (L1 L2 : List A) -> Maybe (Id L1 L2)
  listeq-semidec Eq [] [] = Some Refl
  listeq-semidec Eq (x :: xs) (y :: ys) with listeq-semidec Eq xs ys | Eq x y
  listeq-semidec Eq (x :: xs) (.x :: .xs) | Some Refl | Some Refl = Some Refl
  ... | _ | _ = None
  listeq-semidec Eq _ _ = None
