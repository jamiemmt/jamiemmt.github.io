
open import lib.SumsProds
open Sums
open Prods
open import lib.Nat
open Nat
open import lib.NatThms
open NatThms
open import lib.Id
open Id 
open import lib.Functions

open import lib.list.Base
open import lib.list.In
open import lib.list.Subset

module lib.list.OPE where


  -- conditional order-preserving embedding
  module CondOPE where
    data Embed {A : Set} (P : A -> Set) : List A -> List A -> Set where
      Done : Embed P [] []
      Keep : forall {a l l'} -> Embed P l l' -> Embed P (a :: l) (a :: l')
      Skip : {a : A} {l l' : List A} 
           -> Embed P l l'  ->   P a
           -> Embed P (a :: l) l'
  
    embedid : forall {A P} (l : List A) -> Embed P l l 
    embedid [] = Done
    embedid (a :: l) = Keep (embedid l)
  
    _comp_ : {A : Set} {P : A -> Set} {l1 l2 l3 : List A} -> Embed P l2 l3 -> Embed P l1 l2 -> Embed P l1 l3
    Done         comp Done = Done
    f            comp (Skip g sub1) = Skip (f comp g) sub1
    (Keep f)     comp (Keep g) = Keep (f comp g)
    (Skip f sub) comp (Keep g) = Skip (f comp g) sub 
  
    embed⊆ : {A : Set} {P : A -> Set} {l l' : List A} -> Embed P l l' -> Subset._⊆_ l' l
    embed⊆ Done ()
    embed⊆ (Keep em) i0 = i0
    embed⊆ (Keep em) (iS i) = iS (embed⊆ em i)
    embed⊆ (Skip em _) i = iS (embed⊆ em i)

    weaken-embed : {A : Set} {P Q : A -> Set} {l1 l2 :  List A} 
                 -> ({a : A} -> P a -> Q a) -> Embed P l1 l2 -> Embed Q l1 l2 
    weaken-embed f Done = Done
    weaken-embed f (Keep e) = Keep (weaken-embed f e)
    weaken-embed f (Skip e pf) = Skip (weaken-embed f e) (f pf) 

    embed∈ : {A : Set} {x : A} {P : A -> Set} {l l' : List A} -> (P x -> Void) -> Embed P l l' -> x ∈ l -> x ∈ l'
    embed∈ e Done ()
    embed∈ e (Keep f) i0 = i0
    embed∈ e (Keep f) (iS g) = iS (embed∈ e f g)
    embed∈ e (Skip f g) i0 = abort (e g)
    embed∈ e (Skip f g) (iS h) = embed∈ e f h



  -- Conditional property preserving embedding
  -- the extension of the bigger state satisfies some predicate

  module CondPPE where
    open Subset 

    Embed : {A : Set} (P : A -> Set) -> List A -> List A -> Set
    Embed P l l' = (∀{a} → a ∈ l → Either (a ∈ l') (P a)) × 
                   (∀{a} → a ∈ l' → a ∈ l)
                   

    embedid : forall {A P} (l : List A) -> Embed P l l 
    embedid l = (λ x → Inl x) , (λ x → x)
  
    embed⊆ : {A : Set} {P : A -> Set} {l l' : List A} -> Embed P l l' -> l' ⊆ l
    embed⊆ (x , y) = y

    weaken-embed : {A : Set} {P Q : A -> Set} {l1 l2 :  List A} 
                 -> ({a : A} -> P a -> Q a) -> Embed P l1 l2 -> Embed Q l1 l2 
    weaken-embed f (x , y) 
      = (λ x' → case (x x') (λ x0 → Inl x0) (λ x0 → Inr (f x0))) , λ x' → y x'

    embed∈ : {A : Set} {x : A} {P : A -> Set} {l l' : List A} -> (P x -> Void) -> Embed P l l' -> x ∈ l -> x ∈ l'
    embed∈ p e i = case (fst e i) (λ x → x) (λ x → abort (p x))

  -- the difference between the two sets satisfies a predicate
  module CondSet where
    Diff : {A : Set} (P : A -> Set) → List A -> List A -> Set
    Diff {A} P l l' =
      ({x : A} → x ∈ l → Either (P x) (x ∈ l')) × 
      ({x : A} → x ∈ l' → Either (P x) (x ∈ l))

    diffid : ∀ {A P} (l : List A) -> Diff P l l
    diffid l = (λ x' → Inr x') , (λ x' → Inr x')
 
    diffsymm : ∀ {A P} (l l' : List A) -> Diff P l l' -> Diff P l' l
    diffsymm l l' (A , B) = (λ x' → B x') , λ x' → A x'

    wkd-helper : {A : Set} {x : A} (P Q : A -> Set) {l :  List A} 
                 -> ({a : A} -> P a -> Q a) 
                  -> Either (P x) (x ∈ l) -> Either (Q x) (x ∈ l)
    wkd-helper P Q e (Inl y) = Inl (e y)
    wkd-helper P Q e (Inr y) = Inr y

    weaken-diff : {A : Set} {P Q : A -> Set} {l1 l2 :  List A} 
                 -> ({a : A} -> P a -> Q a) -> Diff P l1 l2 -> Diff Q l1 l2 
    weaken-diff {P = P} {Q = Q} e (f , g) = 
      (λ x' → wkd-helper P Q e (f x')) , λ x' → wkd-helper P Q e (g x')

  -- the difference between two lists satisifies a predicate
  module CondDiff where
    data Diff {A : Set} (P : A -> Set) : List A -> List A -> Set where
      Done : Diff P [] []
      Keep : forall {a l l'} -> Diff P l l' -> Diff P (a :: l) (a :: l')
      Skip : {a : A} {l l' : List A} 
           -> Diff P l l'  ->   P a
           -> Diff P (a :: l) l'
      Add : {a : A} {l l' : List A} 
           -> Diff P l l'  ->   P a
           -> Diff P l (a :: l')
  
    drefl : forall {A P} (l : List A) -> Diff P l l 
    drefl [] = Done
    drefl (a :: l) = Keep (drefl l)

    dsym : forall {A P} {l l' : List A} -> Diff P l l' -> Diff P l' l
    dsym Done = Done
    dsym (Keep f) = Keep (dsym f)
    dsym (Skip f p) = Add (dsym f) p
    dsym (Add f p) = Skip (dsym f) p
  
    _dtrans_ : {A : Set} {P : A -> Set} {l1 l2 l3 : List A} -> Diff P l2 l3 -> Diff P l1 l2 -> Diff P l1 l3
    Done         dtrans Done = Done
    f            dtrans (Skip g sub1) = Skip (f dtrans g) sub1
    (Keep f)     dtrans (Keep g) = Keep (f dtrans g)
    (Skip f sub) dtrans (Keep g) = Skip (f dtrans g) sub 
    (Add f pf)   dtrans g = Add (f dtrans g) pf 
    (Keep f)     dtrans (Add g pf) = Add (f dtrans g) pf 
    (Skip f _)   dtrans (Add g _) = f dtrans g

    fromOPE : {A : Set} {P : A -> Set} {l l' : List A} -> CondOPE.Embed P l l' -> Diff P l l'
    fromOPE CondOPE.Done = Done
    fromOPE (CondOPE.Keep f) = Keep (fromOPE f)
    fromOPE (CondOPE.Skip f pf) = Skip (fromOPE f) pf

    weaken-diff : {A : Set} {P Q : A -> Set} {l1 l2 :  List A} 
                 -> ({a : A} -> P a -> Q a) -> Diff P l1 l2 -> Diff Q l1 l2 
    weaken-diff f Done = Done
    weaken-diff f (Keep e) = Keep (weaken-diff f e)
    weaken-diff f (Skip e pf) = Skip (weaken-diff f e) (f pf) 
    weaken-diff f (Add e pf) = Add (weaken-diff f e) (f pf) 

    fromRemove : {A : Set} {P : A -> Set} {l : List A} {a : A} -> (i : a ∈ l) -> P a -> Diff P (In.remove l i) l
    fromRemove {l = []} () pf
    fromRemove {l = x :: xs} i0 pf = Add (drefl xs) pf    
    fromRemove {l = x :: xs} (iS i) pf = Keep (fromRemove i pf)

