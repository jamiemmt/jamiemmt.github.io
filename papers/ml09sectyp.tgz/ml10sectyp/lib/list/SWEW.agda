
open import lib.SumsProds
open Sums
open Prods
open import lib.Nat
open Nat
open import lib.NatThms
open NatThms
open import lib.Id
open Id 
open import lib.Functions

open import lib.list.Base
open import lib.list.In

module lib.list.SWEW where
  module SW where
  
    data Somewhere {A : Set} (P : A -> Set) : List A -> Set where
      s0 : {x : A} {xs : List A} -> P x -> Somewhere P (x :: xs)
      sS : {x : A} {xs : List A} -> Somewhere P xs -> Somewhere P (x :: xs) 

    fromin : {A : Set} {P : A -> Set} {l : List A} {a : A} -> a ∈ l -> P a -> Somewhere P l
    fromin i0 p = s0 p
    fromin (iS i) p = sS (fromin i p)

    toin : {A : Set} {P : A -> Set} {l : List A} -> Somewhere P l -> (Σ \a -> (a ∈ l) × P a)
    toin (s0 p) = _ , i0 , p
    toin (sS sw) with toin sw 
    ...             | _ , i , p = _ , iS i , p

    mapsw : {A : Set} {P : A -> Set} {Q : A -> Set} {l : List A} -> ({a : A} -> P a -> Q a) -> Somewhere P l -> Somewhere Q l
    mapsw f (s0 pf) = s0 (f pf)
    mapsw f (sS s) = sS (mapsw f s)

    here? : {A : Set} {P : A -> Set} {l : List A} {x : A} -> (i : x ∈ l) -> Somewhere P l 
          -> Either (P x) (Somewhere P (In.remove l i))
    here? i sw with toin sw
    ...           | _ , j , p with In.indeq i j
    ...                                   | Inl Refl = Inl p
    ...                                   | Inr pf2 = Inr (fromin pf2 p)

    _∈∈_ : {A : Set} -> A -> Lists A -> Set 
    a ∈∈ ls = Somewhere (\ l -> a ∈ l) ls    

  module EW where
    open In

    -- equivalent characterization of Everywhere based on universal quantification:
    fromall : {A : Set} {P : A -> Set} {l : List A} 
            -> ({a : A} -> a ∈ l -> P a) -> Everywhere P l
    fromall {l = []}      _ = E[]
    fromall {l = x :: xs} f = (f i0) E:: (fromall (\i -> f (iS i)))

    there : {A : Set} {P : A -> Set} {l : List A} -> Everywhere P l -> ({a : A} -> a ∈ l -> P a)
    there E[] ()
    there (_E::_ phere pthere) i0 = phere
    there (_E::_ phere pthere) (iS i) = there pthere i

    -- list-indexed list
    IList : {A : Set} (P : A -> Set) -> List A -> Set
    IList = Everywhere

    appendew : {A : Set} {P :  A -> Set} {l1 l2 : List A} -> Everywhere P l1 -> Everywhere P l2 -> Everywhere P (append l1 l2)
    appendew E[] e = e
    appendew (_E::_ h t) e = _E::_ h (appendew t e)
    
    splitew : {A : Set} {P :  A -> Set} (l1 l2 : List A) -> Everywhere P (append l1 l2) -> Everywhere P l1 × Everywhere P l2
    splitew [] l2 e = E[] , e
    splitew (a :: l1) l2 (_E::_ h t) with splitew l1 l2 t
    ...                              | e1 , e2 = _E::_ h e1 , e2
    
    mapew : {A : Set} {P Q :  A -> Set} {l : List A} -> ({a : A} -> P a -> Q a) -> Everywhere P l -> Everywhere Q l
    mapew f E[] = E[]
    mapew f (_E::_ h t) = _E::_ (f h) (mapew f t)

    -- allows the indices to change
    mapewi : {I1 : Set} {I2 : Set} {El1 : I1 -> Set} {El2 : I2 -> Set} 
         -> (if : I1 -> I2) -> ({i1 : I1} -> El1 i1 -> El2 (if i1)) 
         -> {is1 : List I1} -> IList El1 is1 -> IList El2 (map if is1)
    mapewi _ f E[] = E[]
    mapewi if f (x E:: xs) = f x E:: (mapewi if f xs)

    removeew : {A : Set} {P : A -> Set} {l : List A} {a : A} -> Everywhere P l -> (i : a ∈ l) 
              -> Everywhere P (remove l i)
    removeew E[] ()
    removeew (_E::_ here there) i0 = there
    removeew (_E::_ here there) (iS i) = _E::_ here (removeew there i)

    zipew : {A : Set} {P : A -> Set} {l : List A} -> Everywhere P l -> List (Σ \ a -> P a)
    zipew E[] = []
    zipew (p E:: ew) = (_ , p) :: zipew ew

    data _I∈_ {I : Set} {El : I -> Set} {i : I} (x : El i): {is : List I} -> IList El is -> Set where
      I∈0 : {is : List I} {l : IList El is} -> x I∈ (x E:: l)
      I∈S : {is : List I} {l : IList El is} {i' : I} {y : El i'}
          -> x I∈ l -> x I∈ (y E:: l)

    -- to and from check
    from-checkall : {A : Set} (l : List A) {p : A -> Bool} -> Check (all p l) -> Everywhere (\ x -> Check (p x)) l
    from-checkall [] _ = E[]
    from-checkall (x :: xs) {p} ch = (fst (check-andE{p x} ch)) E:: (from-checkall xs (snd (check-andE{p x} ch)))

    to-checkall : {A : Set} {l : List A} {p : A -> Bool} -> Everywhere (\ x -> Check (p x)) l -> Check (all p l)
    to-checkall E[] = _
    to-checkall (p E:: ps) = check-andI p (to-checkall ps)

    -- Q holds everywhere on an everywhere (= indexed list)
    data IEverywhere {I : Set} {P : I -> Set} (Q : {i : I} -> P i -> Set) : {is : List I} -> Everywhere P is -> Set where
      IE[] : IEverywhere Q E[]
      _IE::_ : {i : I} {x : P i} {is : List I} {xs : Everywhere P is} -> Q x -> IEverywhere Q xs -> IEverywhere Q (x E:: xs)

    infixr 98 _IE::_

    lookupByIn : {I : Set} {El : I -> Set} {is : List I} {i : I} 
                  -> i ∈ is -> (ls : IList El is)
                  -> Σ \(x : El i) -> x I∈ ls
    lookupByIn i0 (x E:: _) = x , I∈0
    lookupByIn (iS i) (x E:: xs) = _ , I∈S (snd (lookupByIn i xs))

    ithere : {I : Set} {El : I -> Set} {is : List I} {i : I} {x : El i} {P : {i : I} -> El i -> Set}
        -> {l : IList El is} -> x I∈ l -> IEverywhere P l -> P x
    ithere I∈0 (p IE:: _) = p
    ithere (I∈S i) (_ IE:: ps) = ithere i ps

    forget : {A : Set} {B : Set} {l : List A} -> Everywhere (\ _ -> B) l -> List B
    forget E[] = []
    forget (x E:: xs) = x :: (forget xs)

    joinEW : {A : Set} {B : A -> Set} {xs : List A}
           -> Everywhere (\ x -> Maybe (B x)) xs
           -> Maybe (Everywhere B xs)
    joinEW E[] = Some E[] 
    joinEW (Some x E:: xs) = mapMaybe (\ xs' -> x E:: xs') (joinEW xs)
    joinEW (None E:: _) = None

    module Properties where
      lookup-of-map : {I : Set} {El1 : I -> Set} {El2 : I -> Set} 
                 (f : ({i1 : I} -> El1 i1 -> El2 i1))
                 -> {is : List I} 
                 -> (xs : Everywhere El1 is)
                 -> {i : I} (ind : i ∈ is)
                 -> Id (fst (lookupByIn ind (mapew f xs))) (f (fst (lookupByIn ind xs)))
      lookup-of-map f E[] ()
      lookup-of-map f (x E:: xs) i0 = Refl
      lookup-of-map f (x E:: xs) (iS i) = lookup-of-map f xs i
  
      fuse-mapew : {I : Set} {El1 : I -> Set} {El2 : I -> Set} {El3 : I -> Set} 
                 (f : ({i1 : I} -> El2 i1 -> El3 i1))
                 (g : ({i1 : I} -> El1 i1 -> El2 i1))
                 -> {is : List I} 
                 -> (xs : Everywhere El1 is)
                 -> Id (mapew f (mapew g xs)) (mapew (\x -> f ( g x)) xs)
      fuse-mapew f g E[] = Refl 
      fuse-mapew f g (x E:: xs) = substeq (\xs -> f (g x) E:: xs) (fuse-mapew f g xs)
  
      -- this will only really be useful when El2 is a positive type
      map-eq : {I : Set} {El1 : I -> Set} {El2 : I -> Set} 
                 (f : ({i1 : I} -> El1 i1 -> El2 i1))
                 (g : ({i1 : I} -> El1 i1 -> El2 i1))
                 -> ((i : I) (x : El1 i) -> Id (f x) (g x))
                 -> {is : List I} 
                 -> (xs : Everywhere El1 is)
                 -> Id (mapew f xs) (mapew g xs)
      map-eq f g eq E[] = Refl 
      map-eq f g eq (x E:: xs) with (f x)  | eq _ x | mapew f xs    | map-eq f g eq xs
      ...                         | .(g x) | Refl   | .(mapew g xs) | Refl = Refl 
  
      map-compose-eq : {I : Set} {El1 : I -> Set} {El2 : I -> Set} {El2' : I -> Set} {El3 : I -> Set} 
                     (f : ({i1 : I} -> El1 i1 -> El2 i1))
                     (f' : ({i1 : I} -> El1 i1 -> El2' i1))
                     (g : ({i1 : I} -> El2 i1 -> El3 i1))
                     (g' : ({i1 : I} -> El2' i1 -> El3 i1))
                     -> ((i : I) (x : El1 i) -> Id (g (f x)) (g' (f' x)))
                     -> {is : List I} 
                     -> (xs : Everywhere El1 is)
                     -> Id (mapew g (mapew f xs)) (mapew g' (mapew f' xs))
      map-compose-eq f f' g g' id xs = Id.trans (Id.trans fuse1 comp) fuse2  where
        fuse1 = fuse-mapew g f xs
        fuse2 = Id.sym (fuse-mapew g' f' xs)
        comp  = map-eq _ _ id xs

      remove-map : {I : Set} {El1 : I -> Set} {El2 : I -> Set} 
                   (f : ({i1 : I} -> El1 i1 -> El2 i1))
                   {is : List I} {i : I} 
                  -> (ind : i ∈ is) -> (xs : Everywhere El1 is)
                  -> Id (removeew (mapew f xs) ind) (mapew f (removeew xs ind))
      remove-map f i0 (x E:: xs) = Refl 
      remove-map f (iS i) (x E:: xs) = substeq (\xs -> f x E:: xs) (remove-map f i xs) 

      map-id : {I : Set} {El1 : I -> Set}  
             -> {is : List I} 
             -> (xs : Everywhere El1 is)
             -> Id (mapew (\x -> x) xs) xs
      map-id E[] = Refl
      map-id (x E:: xs) = Id.substeq (\xs -> x E:: xs) (map-id xs)

  module EW2 where
    open In

    data Everywhere2 {A : Set} (P : A -> A -> Set) : List A -> List A -> Set where
      E2[] : Everywhere2 P [] []
      _E2::_ : forall {x y xs ys} -> P x y -> Everywhere2 P xs ys -> Everywhere2 P (x :: xs) (y :: ys) 

    appendew : {A : Set} {P :  A -> A -> Set} {l1 l2 l1' l2' : List A} -> Everywhere2 P l1 l1' -> Everywhere2 P l2 l2' -> Everywhere2 P (append l1 l2) (append l1' l2')
    appendew E2[] e = e
    appendew (_E2::_ h t) e = _E2::_ h (appendew t e)

    ew-[]-is-[]/left : {A : Set} (P : A -> A -> Set) {l : List A} -> Everywhere2 P [] l -> Id l []
    ew-[]-is-[]/left P {[]} E2[] = Refl
    ew-[]-is-[]/left P {(_ :: _)} ()

