
open import lib.SumsProds
open Sums
open Prods
open import lib.Nat
open Nat
open import lib.NatThms
open NatThms
open import lib.Id
open Id 
open import lib.Functions

open import lib.list.Base
open import lib.list.In
open import lib.list.SWEW

module lib.list.Subset where

  module Subset where
    open In

    _⊆_    : {A : Set} -> List A -> List A -> Set
    _⊆_ {A} f f' = ({a : A} -> a ∈ f -> a ∈ f')
      
    _∼_ : {A : Set} -> List A -> List A -> Set
    _∼_ {A} f f' = (∀{a} → a ∈ f → a ∈ f') × (∀{a} → a ∈ f' → a ∈ f)

    _⊆o_ : {A : Set} {l1 l2 l3 : List A} -> (l2 ⊆ l3) -> (l1 ⊆ l2) -> (l1 ⊆ l3)
    _⊆o_ l23 l12 inl1 = l23 (l12 inl1)
  
    ⊆[] : {A : Set} {l : List A} -> ([] ⊆ l)
    ⊆[] () 
  
    ⊆refl : {A : Set} {l : List A} -> (l ⊆ l)
    ⊆refl inl = inl 
  
    ⊆trans : {A : Set} {l1 l2 l3 : List A} -> (l1 ⊆ l2) -> (l2 ⊆ l3) -> (l1 ⊆ l3)
    ⊆trans s12 s23 in1 = s23 (s12 in1) 

    ⊆append-left : {A : Set} {l : List A} {l' : List A} (ll : List A) -> (l ⊆ l') -> (l ⊆ (ll ++ l'))
    ⊆append-left ll lell' inl = iSmany _ ll (lell' inl)
  
    ⊆append-swap : {A : Set} {l : List A} {l2 : List A} (l1 : List A) -> (l ⊆ (l1 ++ l2)) -> (l ⊆ (l2 ++ l1))
    ⊆append-swap l1 le12 inl = iswapapp _ l1 (le12 inl)
    
    ⊆append-right : {A : Set} {l' : List A} {l : List A} (ll : List A) -> (l ⊆ l') -> (l ⊆ (l' ++ ll))
    ⊆append-right ll sll' = ⊆append-swap ll (⊆append-left ll sll')
  
    ⊆append-cong : {A : Set} {l1 l1' l2 l2' : List A} -> (l1 ⊆ l1') -> (l2 ⊆ l2') -> ((l1 ++ l2) ⊆ (l1' ++ l2'))
    ⊆append-cong {A} {l1} {l1'} {l2} {l2'} s1 s2 inapp 
      with splitappend l1 _ inapp
    ...  | Inl in1 = iswapapp l1' l2' (iSmany l1' l2' (s1 in1))
    ...  | Inr in2 = iSmany l2' l1' (s2 in2)

    ⊆both : {A : Set} {l1 l2 l3 : List A} -> (l1 ⊆ l3) -> (l2 ⊆ l3) -> ((l1 ++ l2) ⊆ l3)
    ⊆both {A} {l1} {l1'} {l3} s1 s2 inapp 
      with splitappend l1 _ inapp
    ...  | Inl in1 = s1 in1  
    ...  | Inr in2 = s2 in2

    ⊆single : {A : Set} {l : List A} {b : A} -> (b ∈ l) -> ([ b ] ⊆ l) 
    ⊆single i i0 = i
    ⊆single _ (iS ())

    ⊆-::-cong : ∀ {A x} {Ω Ω' : List A} -> Ω ⊆ Ω' -> (x :: Ω ⊆ x :: Ω')
    ⊆-::-cong w i0 = i0
    ⊆-::-cong w (iS i) = iS (w i)

    extend⊆ : ∀ {A x} {Ω Ω' : List A} -> Ω ⊆ Ω' -> (x :: Ω ⊆ x :: Ω')
    extend⊆ = ⊆-::-cong

    ⊆insert-middle : {A : Set} {a' : A} (l1 : List A) ( l2 : List A) 
                     -> (l2 ++ l1) ⊆ (l2 ++ (a' :: l1))
    ⊆insert-middle l1 l2 = iS-app-right l1 l2

    ⊆remove : {a : Set} {x : a} {l : List a} -> (i : x ∈ l) -> (remove l i) ⊆ l
    ⊆remove {l = []} () _
    ⊆remove {l = x :: xs} i0 i = (iS i)
    ⊆remove {l = x :: xs} (iS i) (iS i') = iS (⊆remove i i')
    ⊆remove {l = x :: xs} (iS i) i0 = i0

    _≡set_ : {A : Set} -> List A -> List A -> Set
    l ≡set l' = l ⊆ l' × l' ⊆ l

    ≡set-refl : {A : Set} {l : List A} -> (l ≡set l)
    ≡set-refl = ((\ {_} i -> ⊆refl i) , (\ {_} i -> ⊆refl i))

    ≡set-::-cong : {A : Set} {a : A} {l l' : List A} -> l ≡set l' -> (a :: l) ≡set (a :: l')
    ≡set-::-cong {a = a} (l , g) = ((\{a'} i -> ⊆append-cong (⊆refl {_} {a :: []}) l i), 
                                    \{a'} i -> ⊆append-cong (⊆refl {_} {a :: []}) g i )

    ≡set-append-cong : {A : Set} {l1 l1' l2 l2' : List A} -> l1 ≡set l1' -> l2 ≡set l2' -> (l1 ++ l2) ≡set (l1' ++ l2')
    ≡set-append-cong (eq1 , eq1') (eq2 , eq2') = ((\{a'} i -> ⊆append-cong eq1 eq2 i) , 
                                                  (\{a'} i -> ⊆append-cong eq1' eq2' i))

    ⊆Eq : {A : Set} {Ω Ω' : List A} -> (f1 f2 : Ω ⊆ Ω') -> Set
    ⊆Eq {A}{Ω} f1 f2 = {x : A} -> (i : x ∈ Ω) -> Id (f1 i) (f2 i)

    _∘⊆_ : ∀ {A} {Ω1 Ω2 Ω3 : List A} -> (w2 : Ω2 ⊆ Ω3) -> (w1 : Ω1 ⊆ Ω2) -> Ω1 ⊆ Ω3
    g ∘⊆ f = \ x -> g (f x)

    extend⊆-ext : ∀ {A x} {Ω Ω' : List A} -> {w1 w2 : Ω ⊆ Ω'} -> ⊆Eq w1 w2 -> ⊆Eq (extend⊆{_}{x} w1) (extend⊆ w2)
    extend⊆-ext wid i0 = Refl
    extend⊆-ext wid (iS i) = Id.substeq iS (wid i)

    extend⊆-compose : ∀ {A x} {Ω1 Ω2 Ω3 : List A} -> {w2 : Ω2 ⊆ Ω3} {w1 : Ω1 ⊆ Ω2} 
                    -> ⊆Eq (extend⊆{_}{x} (w2 ∘⊆ w1)) ((extend⊆ w2) ∘⊆ (extend⊆ w1))
    extend⊆-compose i0 = Refl
    extend⊆-compose (iS i) = Refl

    ⊆-map : ∀ {A B} {Ψ Ψ' : List A} -> (f : A -> B) -> Ψ ⊆ Ψ' -> (map f Ψ) ⊆ (map f Ψ')
    ⊆-map w lt i with In.in-map2 _ _ i
    ... | (_ , oldx , Refl) = In.in-map (lt oldx)

  module Weakening {A : Set} (P : List A -> Set) where
    open Subset

    Wkn : Set
    Wkn = ∀ {Ω Ω'} -> Ω ⊆ Ω' -> P Ω -> P Ω'
    
    module Properties(wkn : Wkn) where
      Ext : Set
      Ext = ∀ {Ω Ω'} {w1 w2 : Ω ⊆ Ω'} -> ⊆Eq w1 w2 -> (t : P Ω) -> Id (wkn w1 t) (wkn w2 t)

      Compose : Set
      Compose = ∀ {Ω1 Ω2 Ω3} -> (w2 : Ω2 ⊆ Ω3) (w1 : Ω1 ⊆ Ω2) -> (A : P Ω1) -> Id (wkn (\{_} -> w2 ∘⊆ w1) A) (wkn w2 (wkn w1 A))

  module Subsets where 
    open In
    open SW
    open Subset

    -- S for Lists
    -- L for List

    _⊆SS_ : {A : Set} -> Lists A -> Lists A -> Set
    _⊆SS_ {A} f f' = ({a : A} -> a ∈∈ f -> a ∈∈ f')
    
    _⊆LS_    : {A : Set} -> List A -> Lists A -> Set
    _⊆LS_ {A} f r = ({a : A} -> a ∈ f -> a ∈∈ r)
    
    shiftwv : {A : Set} { r1 r2 : Lists A } -> r1 ⊆SS r2 -> (l : List A) -> (l :: r1) ⊆SS (l :: r2)
    shiftwv wv new (s0 inl) = s0 inl
    shiftwv wv new (sS inr1) = sS (wv inr1)
    
    ⊆SSlast : {A : Set} {l : List A} {l' : List A} {f : Lists A} -> (l ⊆ l') -> (l :: f) ⊆SS (l' :: f)
    ⊆SSlast inl' (s0 h) = s0 (inl' h) 
    ⊆SSlast inl' (sS i) = sS i
    
    ⊆SSlast-append-left : {A : Set} {l1 : List A} {l2 : List A} {f : Lists A}
                      -> (l2 :: f) ⊆SS ((l1 ++ l2) :: f)
    ⊆SSlast-append-left {_} {l1} {l2} = ⊆SSlast (iSmany l2 l1)
    
    ⊆SSlast-append-right : forall { A l1 l2 f } -> (l1 :: f) ⊆SS ((l1 ++ l2) :: f)
    ⊆SSlast-append-right {A} {l1} {l2} = ⊆SSlast help where
      help : ({a : A} -> a ∈ l1 -> a ∈ append l1 l2)
      help inl1 = iswapapp l1 l2 (iSmany l1 l2 inl1)

    ⊆SSlast-append-left-left : forall { A l0 l1 l2 f } -> ((l1 ++ l0) :: f) ⊆SS (((l2 ++ l1) ++ l0) :: f)
    ⊆SSlast-append-left-left {A} {l0} {l1} {l2} = ⊆SSlast help
      where help : ({a : A} -> a ∈ (l1 ++ l0) -> a ∈ ((l2 ++ l1) ++ l0))
            help i with In.splitappend l1 _ i
            ...       | Inl in1 = iSmany-right _ l0 (iSmany l1 l2 in1)
            ...       | Inr in0 = iSmany l0 (l2 ++ l1) in0

    ⊆SSlast-append-left-right : forall { A l0 l1 l2 f } -> ((l1 ++ l0) :: f) ⊆SS (((l1 ++ l2) ++ l0) :: f)
    ⊆SSlast-append-left-right {A} {l0} {l1} {l2} = ⊆SSlast help
      where help : ({a : A} -> a ∈ (l1 ++ l0) -> a ∈ ((l1 ++ l2) ++ l0))
            help i with In.splitappend l1 _ i
            ...       | Inl in1 = iSmany-right _ l0 (iSmany-right l1 l2 in1)
            ...       | Inr in0 = iSmany l0 (l1 ++ l2) in0
    
    ⊆LSappend : {A : Set} {f1 : List A} {f2 : List A} {r : Lists A} 
                -> f1 ⊆LS r -> f2 ⊆LS r -> (f1 ++ f2) ⊆LS r
    ⊆LSappend {_} {f1} {f2} if1 if2 inapp with splitappend f1 f2 inapp 
    ...                                      | Inl in1 = if1 in1
    ...                                      | Inr in2 = if2 in2 
