
open import lib.SumsProds
open Sums
open Prods
open import lib.Nat
open Nat
open import lib.NatThms
open NatThms
open import lib.Id
open Id 
open import lib.Functions
open import lib.Not
open Not using (Decidable1)
open import lib.list.Base

module lib.list.In where

module In where

    iSmany : {A : Set} {a : A} (orig : List A) (new : List A) -> (a ∈ orig) -> (a ∈ (new ++ orig))
    iSmany l1 [] i = i
    iSmany l1 (a' :: l2) i = iS (iSmany l1 l2 i)

    skip : {A : Set} (l1 : List A) {l2 : List A} {x : A} -> x ∈ l2 -> x ∈ (l1 ++ l2)
    skip l1 i = iSmany _ l1 i

    iSmanyi : {A : Set} {a : A} (orig : List A) {new : List A} -> (a ∈ orig) -> (a ∈ (new ++ orig))
    iSmanyi l1 {[]} i = i
    iSmanyi l1 {(a' :: l2)} i = iS (iSmanyi l1 {l2} i)
      
    i0-app-right : {A : Set} {a : A} (l1 : List A) ( l2 : List A) 
                 -> (a ∈ (l2 ++ (a :: l1)))
    i0-app-right l1 [] = i0
    i0-app-right l1 (a :: l2) = iS (i0-app-right l1 l2)
    
    iS-app-right : {A : Set} {a a' : A} (l1 : List A) ( l2 : List A) 
                 -> (a ∈ (l2 ++ l1))
                 -> (a ∈ (l2 ++ (a' :: l1)))
    iS-app-right l1 [] i = iS i
    iS-app-right l1 (a :: l2) i0 = i0
    iS-app-right l1 (a0 :: l2) (iS i) = iS (iS-app-right l1 l2 i)
    
    iswapapp : {A : Set} {a : A} (l1 : List A) ( l2 : List A) -> (a ∈ (l2 ++ l1)) -> (a ∈ (l1 ++ l2))
    iswapapp l1 [] i with append l1 [] | append-rh-[] l1
    ...                 | .l1          | Refl = i
    iswapapp l1 (a' :: l2) i0 = i0-app-right l2 l1
    iswapapp l1 (a' :: l2) (iS i) = iS-app-right l2 l1 (iswapapp l1 l2 i)

    iSmany-right : {A : Set} {a : A} (orig : List A) (new : List A) -> (a ∈ orig) -> (a ∈ (orig ++ new))
    iSmany-right l1 l2 i = iswapapp l1 l2 (iSmany l1 l2 i)

    skip/right : {A : Set} {a : A} (orig : List A) {new : List A} -> (a ∈ orig) -> (a ∈ (orig ++ new))
    skip/right orig {new} i = iSmany-right orig new i
    
    incr : {A : Set} {a : A} ( l1 : List A) ( l2 : List A) (a' : A) -> (a ∈ (l2 ++ l1)) -> (a ∈ (l2 ++ (a' :: l1)))
    incr l1 []       a' i = iS i 
    incr l1 (a2 :: l2) a' i0 = i0
    incr l1 (a2 :: l2) a' (iS i') = iS (incr l1 l2 a' i') 
    
    remove : {a : Set} {x : a} (l : List a) -> x ∈ l -> List a
    remove [] () 
    remove (x :: xs) i0 = xs
    remove (x :: xs) (iS i) = x :: (remove xs i)
  
    _-_ : {a : Set} {x : a} (l : List a) -> x ∈ l -> List a
    _-_ = remove
    
    -- ENH: the type could be more precise here:
    -- the output index actually points to the same occurrence as the input!
    splitappend : {A : Set} {a : A} -> (l1 l2 : List A) -> a ∈ (l1 ++ l2) -> Either (a ∈ l1) (a ∈ l2) 
    splitappend [] l2 i = Inr i
    splitappend (l :: l1) l2 i0 = Inl i0 
    splitappend (l :: l1) l2 (iS i') with splitappend l1 l2 i' 
    ...                                 | Inr inl2 =  Inr inl2
    ...                                 | Inl inl1 =  Inl (iS inl1)
    
    indeq : {A : Set} {a : A} {b : A} {f : List A} -> (ia : (a ∈ f)) -> (ib : (b ∈ f))
          -- lossy: only returns exactly the consequences you need below
          -- FIXME: could do better, but I can't figure out how to use heterogeneous equality
          -> Either (Id a b) (b ∈ (remove f ia))
    indeq i0 i0 = Inl Refl
    indeq i0 (iS xs) = Inr xs
    indeq (iS xs) i0 = Inr i0
    indeq {_} {a} {b} (iS i) (iS{x} i') with indeq i i' 
    ...                                    | Inl p = Inl p
    ...                                    | Inr r = Inr (iS {_} {x} r)
    
    neqEltsNeqInds : {A : Set} {a : A} {b : A} {f : List A} 
                   -> (Id a b -> Void) -> (ia : (a ∈ f)) -> (ib : (b ∈ f)) -> (a ∈ (remove f ib))
    neqEltsNeqInds ref i1 i2 with indeq i2 i1 
    ...                         | Inl typeq = abort (ref (sym typeq))
    ...                         | Inr x = x

    indices : {I : Set} (is : List I)
              -> List (Σ \i -> i ∈ is)
    indices [] = []
    indices (i :: is) = ((_ , i0) :: map (\x -> wk x) (indices is)) where
        wk : {I : Set} {is : List I} {j : I}
           -> Σ (\ i -> i ∈ is)
           -> Σ \ i -> i ∈ (j :: is)
        wk (_ , i) = (_ , iS i)

    notin[] : {A C : Set} {x : A} -> x ∈ [] -> C
    notin[] () 

    in-map : {A B : Set} {x : A} {l : List A} {f : A -> B} -> x ∈ l -> f x ∈ map f l
    in-map i0 = i0
    in-map (iS i) = iS (in-map i)

    in-map2 : {A B : Set} {y : B} (l : List A) -> (f : A -> B) -> (i : (y ∈ (map f l))) -> Σ (\ (x : A) -> (x ∈ l) × (Id (f x) y))
    in-map2 {A} {B} (l1 :: ls) f i0 = l1 , i0 , Refl
    in-map2 {A} {B} (l1 :: ls) f (iS i) = _ , iS (fst (snd (in-map2 ls f i))) , snd (snd (in-map2 ls f i))
    in-map2 [] f ()

    commute-map-remove : {A B : Set} {f : A -> B} {x : A} (l : List A) (i : x ∈ l) -> Id (map f (remove l i)) (remove (map f l) (in-map i))
    commute-map-remove [] () 
    commute-map-remove (x :: xs) i0 = Refl
    commute-map-remove {f = f} (x :: xs) (iS i) = Id.substeq (\l -> (f x) :: l) (commute-map-remove xs i)

    find-in : {A : Set} -> (p : (A -> Bool)) -> (l : List A) -> Maybe (Σ \ (x : A) -> (x ∈ l) × Check (p x))
    find-in f [] = None
    find-in f (x :: xs) with check(f x)
    ...                    | Inl c = Some (x , i0 , c)
    ...                    | Inr _ with find-in f xs
    ...                               | Some (_ , i , p) = Some (_ , iS i , p)
    ...                               | None = None

    must-find : {A : Set} -> (p : (A -> Bool)) -> (l : List A) 
                -> {x : A} -> x ∈ l -> Check (p x)
                -> Σ \ y -> Σ \ (i : y ∈ l) -> Σ \ ch -> Id (find-in p l) (Some (y , i , ch))
    must-find p [] () _
    must-find f (x :: xs) i0 ch with check(f x)  
    ...                            | Inl c    = x , i0 , c , Refl
    ...                            | Inr p    = Sums.abort (check-noncontra (f x) ch (check-id-not p))  
    must-find f (x :: xs) (iS i) ch with check(f x)
    ...                                | Inl c  = x , i0 , c , Refl
    ...                                | Inr p  with (find-in f xs)          | must-find f xs i ch 
    ...                                            | .(Some (y' , i' , ch')) | (y' , i' , ch' , Refl) = y' , iS i' , ch' , Refl 

    in-all : {A : Set} {l : List A} -> (p : (A -> Bool)) -> Check (all p l) -> ({x : A} -> x ∈ l -> Check (p x))
    in-all p ch i0 = fst (check-andE ch) 
    in-all {_} {x :: l} p ch (iS i) = in-all p (snd (check-andE{p x} ch)) i 

    every-to-checkall : {A : Set} (l : List A) -> (p : (A -> Bool)) -> ({x : A} -> x ∈ l -> Check (p x)) -> Check (all p l)
    every-to-checkall [] p ev = _ 
    every-to-checkall (x :: l) p ev = check-andI (ev i0) (every-to-checkall l p (\ x' -> ev (iS x')))

    -- analogue of Everywehre's E:: when everywhere is defined elementwise
    ::-every : forall {A y} { P : A -> Set} {l : List A} -> ({x : A} -> x ∈ l -> P x) -> P y -> ({x : A} -> x ∈ (y :: l) -> P x)
    ::-every f p i0 = p
    ::-every f p (iS i) = f i

    remove/append : ∀ {A : Set} (l1 : List A) {l2 : List A} {x : A} (i : x ∈ l2) -> Id (l1 ++ (l2 - i)) ((l1 ++ l2) - skip l1 i)
    remove/append [] l2 = Refl
    remove/append (x :: xs) l2 = Id.substeq2 _::_ Refl  (remove/append xs l2)

    remove/middle : ∀ {A : Set} (l1 : List A) {l2 : List A} {x : A} -> Id (remove (l1 ++ (x :: l2)) (skip l1 i0)) (l1 ++ l2)
    remove/middle [] = Refl
    remove/middle (y :: xs) = Id.substeq2 _::_ Refl (remove/middle xs) 

    split-at : ∀ {A} {l : List A} {x : A} (i : x ∈ l) -> List A × List A
    split-at {A} {_ :: l} i0 = l , []
    split-at {A} {x :: l} (iS i) = fst (split-at i) , x :: (snd (split-at i))
    split-at {A} {[]} ()
  
    before : ∀ {A} {l : List A} {x : A} (i : x ∈ l) -> List A 
    before i = fst (split-at i)
  
    after : ∀ {A} {l : List A} {x : A} (i : x ∈ l) -> List A 
    after i = snd (split-at i)
  
    split-at-combine : ∀ {A} {l : List A} {x : A} (i : x ∈ l) -> Id l ((snd (split-at i)) ++ (x :: (fst (split-at i))))
    split-at-combine i0 = Refl
    split-at-combine {_}{x :: _} (iS i) = Id.substeq (\ xs -> x :: xs) (split-at-combine i)
  
    split-at-remove : ∀ {A} {l : List A} {x : A} (i : x ∈ l) -> Id (remove l i) ((snd (split-at i)) ++ (fst (split-at i)))
    split-at-remove i0 = Refl
    split-at-remove{l = x' :: _} (iS i) = Id.substeq (\ xs -> x' :: xs) (split-at-remove i)
  
    split-at/map : ∀ {A B}  {l : List A} {x : A} (i : x ∈ l) {f : A -> B} -> 
                Id (map f (fst (split-at i))) (fst (split-at (in-map{_}{_}{_}{_}{f} i)))
              × Id (map f (snd (split-at i))) (snd (split-at (in-map{_}{_}{_}{_}{f} i)))
    split-at/map i0 = Refl , Refl
    split-at/map {l = x :: _} (iS i) {f} =  fst (split-at/map i) , Id.substeq (\ l -> f x :: l) (snd (split-at/map i)) 
   
    module NowhereIn where
      Nowhere : {A : Set} -> (p : A -> Set) -> (l : List A) -> Set
      Nowhere p l = ∀ {x} -> (x ∈ l) -> (p x) -> Void
      
      proveNowhere : {A : Set} {P : A -> Set} -> Decidable1 P -> (l : List A) -> Maybe (Nowhere P l)
      proveNowhere d [] = Some \ ()
      proveNowhere {A}{P} d (y :: y') with d y
      ... | Inl yes = None
      ... | Inr no with proveNowhere d y'
      ...             | Some nw = Some (\ {_} -> f) where
        f : ∀ {x} -> x ∈ (y :: y') -> P x -> Void
        f i0 p = no p
        f (iS i) p = nw i p
      ...             | None = None

    module AtMostOne where
      open NowhereIn

      AtMostOne : {A : Set} ->  (l : List A ) -> (p : A -> Set) -> Set
      AtMostOne l p = ∀ {x y} -> (a :  x ∈ l) -> (b : y ∈ l) -> p x -> p y -> (Id x y) × (HId a b) 
    
      data AtMostOneView {A : Set} (p : A -> Set) : (l : List A ) -> Set where
        []  : AtMostOneView p []
        yes : ∀ {x xs} -> (p x) -> Nowhere p xs -> AtMostOneView p (x :: xs)
        no  : ∀ {x xs} -> (p x -> Void) -> AtMostOneView p xs -> AtMostOneView p (x :: xs)
  
      nwImpliesAMO : {A : Set} -> (l : List A ) -> (p : A -> Set) -> Nowhere p l -> AtMostOne l p
      nwImpliesAMO l p nw a b pa pb = Sums.abort (nw a pa)

      hideAMO : {A : Set} -> {l : List A} -> {p : A -> Set} -> AtMostOneView p l -> AtMostOne l p
      hideAMO [] () _ _ _
      hideAMO (yes hd nw) i0 i0 pa pb = Refl , HRefl
      hideAMO (yes hd nw) i0 (iS y') pa pb = Sums.abort (nw y' pb)
      hideAMO (yes hd nw) (iS y') b pa pb = Sums.abort (nw y' pa)
      hideAMO (no hd am) i0 b pa pb = Sums.abort (hd pa) 
      hideAMO (no hd am) (iS y') i0 pa pb = Sums.abort (hd pb)
      hideAMO (no hd am) (iS y') (iS y0) pa pb with hideAMO am y' y0 pa pb
      hideAMO (no hd am) (iS y') (iS .y') pa pb   | Refl , HRefl = Refl , HRefl

      atMostOneTl : {A : Set} -> (l : List A) -> (p : A -> Set) -> (x : A) -> (AtMostOne (x :: l) p) -> (AtMostOne l p)
      atMostOneTl l p x u i1 i2 p1 p2 with (u (iS i1) (iS i2) p1 p2)
      atMostOneTl l p x u i1 .i1 p1 p2 | Refl , HRefl = Refl , HRefl

      atMostOneHd : ∀ {A z l} {p : A -> Set} -> p z -> AtMostOne (z :: l) p -> Nowhere p l
      atMostOneHd zis unique otherind otheris with unique i0 (iS otherind) zis otheris
      ... | Refl , () 

      notid : ∀ {A l} {x y : A} {b : y ∈ l} -> Id x y × HId{x ∈ (x :: l)} i0 {y ∈ (x :: l)} (iS b) -> Void
      notid (Refl , ()) 

      showAMO : {A : Set} -> {l : List A} -> {p : A -> Set} -> Decidable1 p -> AtMostOne l p -> AtMostOneView p l
      showAMO {A} {[]} d am = []
      showAMO {A} {x :: xs} d am with d x
      ... | Inl y = yes y (\ b pb -> notid (am i0 (iS b) y pb))  
      ... | Inr n = no n (showAMO d (atMostOneTl _ _ _ am))

      proveAtMostOneV : ∀ {A} -> (l : (List A)) 
                     -> (p : (A -> Set)) -> Decidable1 p 
                     -> Maybe (AtMostOneView p l)
      proveAtMostOneV [] p e = Some []      
      proveAtMostOneV (x :: xs) p dec with (dec x)
      ... | Inr n with proveAtMostOneV xs p dec 
      ...            | Some oktl = Some (no n oktl)
      ...            | None = None
      proveAtMostOneV (x :: xs) p dec | Inl y with proveNowhere dec xs 
      ...                                        | Some nwtl = Some (yes y nwtl)
      ...                                        | None = None
      
      proveAtMostOne :  ∀ {A} -> (l : (List A)) 
                     -> (p : (A -> Set)) -> Decidable1 p 
                     -> Maybe (AtMostOne l p)
      proveAtMostOne l p dec = Sums.mapMaybe hideAMO (proveAtMostOneV l p dec)