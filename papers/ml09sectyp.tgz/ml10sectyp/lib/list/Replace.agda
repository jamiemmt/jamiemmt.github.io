
open import lib.SumsProds
open Sums
open Prods
open import lib.Nat
open Nat
open import lib.NatThms
open NatThms
open import lib.Id
open Id 
open import lib.Functions

open import lib.list.Base
open import lib.list.In

module lib.list.Replace where

  module Replace {A : Set} (eq : (x y : A) -> Maybe (Id x y)) where
    open In
    open NowhereIn
    open AtMostOne

    open Functions using (_iff_)

    replace : {x : A} -> {Γ : List A} -> (y : A) -> ( x ∈ Γ ) -> (List A)
    replace {x} {.x :: Γ } y i0 = y :: Γ
    replace {x} {x' :: Γ} y (iS i) = x' :: (replace y i)
    replace {_} {[]} _ () 

    data Replace : ( x y : A) -> (L1  L2 : List A) -> Set where
      rep : ∀ {x y L1 L2} -> (i : x ∈ L1) -> (Id (replace y i) L2) -> Replace x y L1 L2 

    private
      proveReplaceTl : ∀ {l l'} -> (x y : A ) (ls ls' : List A) 
               -> Maybe (Replace x y ls ls')
               -> Maybe (Replace x y (l :: ls) (l' :: ls'))
      proveReplaceTl x y  ls ls' None = None
      proveReplaceTl {l}{l'} x y  ls ls' (Some (rep i p)) with (eq l l') 
      ... | (Some p1) = Some (rep (iS i) (Id.substeq2 _::_ p1 p))
      ... | None = None
    
      proveReplaceE : (x y : A ) (L1 L2 : List A) -> Maybe (Replace x y L1 L2)
      proveReplaceE x y  L1 [] = None
      proveReplaceE x y  [] L2 = None
      proveReplaceE x y  (l :: ls) (l' :: ls')  with (eq x l) | eq y l' 
      proveReplaceE x y  (.x :: ls) (.y :: ls') | Some Refl | Some Refl with (listeq-semidec eq ls ls')
      ...                                                          | None = proveReplaceTl x y  ls ls' (proveReplaceE x y  ls ls') 
      proveReplaceE x y  (.x :: ls) (.y :: .ls) | Some Refl | Some Refl | Some Refl = Some (rep i0 Refl)
      proveReplaceE x y  (l :: ls) (l' :: ls') | _ | _  = proveReplaceTl x y  ls ls' (proveReplaceE x y  ls ls')
    
    repNowhere : ∀ {x y l} -> (p : A -> Set) ->  (p y -> p x ) -> (i : x ∈ l) -> (Nowhere p l) -> (Nowhere p (replace y i ) )
    repNowhere p if i0 n i0 pa = n i0 (if pa)
    repNowhere p if i0 n (iS a) pa = n (iS a) pa
    repNowhere p if (iS i) n i0 pa = n i0 pa
    repNowhere p if (iS i) n (iS a) pa = repNowhere p if i (λ i' → n (iS i')) a pa
    
    repAtMostOne : ∀ {x y l} -> (p : A -> Set) -> (p y -> p x) -> (i : x ∈ l) -> (AtMostOne l p) -> (AtMostOne (replace y i ) p)
    repAtMostOne p if i0 pf i0 i0  pa pb = Refl , HRefl
    repAtMostOne {repthis} {repwith} {.repthis :: l} p if i0 pf i0 (iS i )  pa pb with  pf i0 (iS i) (if pa) pb
    repAtMostOne {repthis} {repwith} {.repthis :: l} p if i0 pf i0 (iS i )  pa pb | Refl , () 
    repAtMostOne {repthis} {repwith} {.repthis :: l} p if i0 pf  (iS i ) i0  pa pb with  pf i0 (iS i) (if pb) pa
    repAtMostOne {repthis} {repwith} {.repthis :: l} p if i0 pf (iS i ) i0  pa pb | Refl , () 
    repAtMostOne p if i0 pf (iS i) (iS i') pa pb with (atMostOneTl _ _ _ pf i i' pa pb) 
    repAtMostOne p if i0 pf (iS i) (iS .i) pa pb | Refl , HRefl = Refl , HRefl
    repAtMostOne p if (iS i) pf i0 i0 pa pb = Refl , HRefl  
    repAtMostOne {repthis} {repwith} {hd :: tl} p if (iS i) pf (iS a) i0 pa pb = Sums.abort (repNowhere p if _ (atMostOneHd pb pf) a pa) 
    repAtMostOne {repthis} {repwith} {hd :: tl} p if (iS i) pf i0 (iS b) pa pb = Sums.abort (repNowhere p if _ (atMostOneHd pa pf) b pb) 
    repAtMostOne p if (iS i) pf (iS a) (iS b) pa pb with repAtMostOne p if i (atMostOneTl _ _ _ pf) a b pa pb
    repAtMostOne p if (iS i) pf (iS a) (iS .a) pa pb | Refl , HRefl  = Refl , HRefl

    replaceAtMostOne : ∀ {p x y l l'} -> (Replace x y l l') -> (p y -> p x)  -> (AtMostOne l p) -> (AtMostOne l' p)
    replaceAtMostOne {p} (rep i Refl) if atmost = (repAtMostOne p if i atmost)

    proveReplace : {x y : A} {L1 L2 : List A} -> Maybe (Replace x y L1 L2)
    proveReplace {x} {y} {L1} {L2} = proveReplaceE x y L1 L2

    ∈replace : {y : A} {l : List A} {x : A} (i : x ∈ l) -> y ∈ (replace y i)
    ∈replace i0 = i0
    ∈replace (iS i) = iS (∈replace i)

    double-replace : {l : List A} {x y : A} (i : x ∈ l) 
                   -> Id l (replace x (∈replace{y} i))
    double-replace i0 = Refl
    double-replace (iS{x} i) = Id.substeq (\ l -> x :: l) (double-replace i) 
    
    replace-sym : ∀ {x y l1 l2} -> Replace x y l1 l2 -> Replace y x l2 l1
    replace-sym (rep i Refl) = rep (∈replace i) (Id.sym (double-replace i))
    
    forgetLemma : ∀ { x y} -> Check (Sums.forgetMaybe2 eq x y) -> Id x y
    forgetLemma {x} {y} c with (eq x y)
    ... | Some g = g
    ... | None = Sums.abort c
  
    make-replace : ∀ {x y l1} -> Maybe (Σ \ l2 -> Replace x y l1 l2 )
    make-replace {x} {y} {l1} with find-in (Sums.forgetMaybe2 eq x) l1 
    ... | None = None
    ... | Some index with (forgetLemma (snd (snd index)))
    make-replace {x} {y} {l1} | Some (.x , i , c) | Refl = Some (replace y i , rep i Refl)

