
open import lib.SumsProds
open Sums
open Prods
open import lib.Nat
open Nat
open import lib.NatThms
open NatThms
open import lib.Id
open Id 
open import lib.Functions

import lib.list.Base
import lib.list.In
import lib.list.Replace
import lib.list.SWEW
import lib.list.Subset
import lib.list.OPE

module lib.List where

module List where

  open lib.list.Base public
  open lib.list.In public
  open lib.list.Replace public
  open lib.list.Replace public
  open lib.list.SWEW public
  open lib.list.Subset public
  open lib.list.OPE public
  

