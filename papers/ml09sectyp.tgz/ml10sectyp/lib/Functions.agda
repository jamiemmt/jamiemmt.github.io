
open import lib.SumsProds
open Prods using (_×_)

module lib.Functions where

module Functions where

  module FunctionsOP where

    _$_ : ∀ {A B : Set} -> (A -> B) -> A -> B
    f $ x = f x
    infixr 11 _$_ 

  open FunctionsOP public

  _iff_ : (A B : Set) -> Set
  _iff_ A B = (A → B) × (B → A)



